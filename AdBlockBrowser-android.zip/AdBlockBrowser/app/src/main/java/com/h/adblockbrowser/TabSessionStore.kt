package com.h.adblockbrowser

/** 1 trang đã mở trong phiên làm việc hiện tại (dùng cho màn hình Đa nhiệm dạng lưới). */
data class SessionTab(val url: String, val title: String)

/** Danh sách các trang đã mở trong phiên - CHỈ LƯU TRONG RAM (không ghi ra file, tự mất khi
 *  thoát app, giữ đúng hành vi cũ của sessionHistory). Dùng chung giữa MainActivity (nơi thêm
 *  trang mới mỗi khi tải xong 1 trang) và MultitaskActivity (màn lưới đa nhiệm hiển thị/xoá). */
object TabSessionStore {
    val list: MutableList<SessionTab> = ArrayList()

    fun addOrMoveToFront(url: String, title: String) {
        if (list.isNotEmpty() && list[0].url == url) return
        list.removeAll { it.url == url }
        list.add(0, SessionTab(url, title))
        if (list.size > 40) list.removeAt(list.size - 1)
    }
}
