package com.h.adblockbrowser

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar

    // Lịch sử phiên làm việc (chỉ trong RAM, không lưu file -> tự mất khi thoát app)
    private val sessionHistory = ArrayList<String>()

    // Đánh dấu điều hướng do chính app gọi (từ thanh địa chỉ / menu đề xuất / mở lại tab)
    // để KHÔNG hỏi xác nhận, chỉ hỏi khi người dùng bấm link ngay trên trang.
    private var programmaticLoad = false

    companion object {
        const val REQ_PERMISSIONS = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        AdBlocker.init(applicationContext)
        AdBlocker.enabled = true // luôn bật, không cho tắt

        webView = findViewById(R.id.webView)
        edtUrl = findViewById(R.id.edtUrl)
        progressBar = findViewById(R.id.progressBar)

        requestAllPermissions()
        setupWebView()

        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMultitaskDialog() }
        findViewById<ImageButton>(R.id.btnShortcuts).setOnClickListener { showShortcutsDialog() }

        edtUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                loadFromInput()
                true
            } else {
                false
            }
        }

        navigateTo("https://www.google.com")
    }

    // ---------- Quyền ----------

    private fun requestAllPermissions() {
        val perms = ArrayList<String>()
        perms.add(Manifest.permission.CAMERA)
        perms.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT < 29) {
                perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        val need = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (need.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    // ---------- Điều hướng ----------

    private fun navigateTo(url: String) {
        programmaticLoad = true
        webView.loadUrl(url)
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = if (input.contains(".") && !input.contains(" ")) {
                "https://$input"
            } else {
                "https://www.google.com/search?q=" + Uri.encode(input)
            }
        }
        navigateTo(input)
    }

    // ---------- Menu "đa nhiệm" (xem / xoá lịch sử phiên) ----------

    private fun showMultitaskDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Đa nhiệm - Các trang đã mở")

        if (sessionHistory.isEmpty()) {
            builder.setMessage("Chưa có trang nào trong phiên này.")
            builder.setPositiveButton("Đóng", null)
            builder.show()
            return
        }

        val items = sessionHistory.toTypedArray()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        builder.setAdapter(adapter) { _, which ->
            navigateTo(items[which])
        }
        builder.setNeutralButton("Xoá tất cả") { _, _ -> clearAllSessionData() }
        builder.setNegativeButton("Đóng", null)
        builder.show()
    }

    private fun clearAllSessionData() {
        sessionHistory.clear()
        webView.clearHistory()
        webView.clearCache(true)
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        Toast.makeText(this, "Đã xoá toàn bộ lịch sử", Toast.LENGTH_SHORT).show()
    }

    // ---------- Menu đề xuất trang (tam giác) ----------

    private fun showShortcutsDialog() {
        val webShortcuts = linkedMapOf(
            "Google" to "https://www.google.com",
            "YouTube" to "https://www.youtube.com",
            "Facebook" to "https://www.facebook.com",
            "Zalo Web" to "https://chat.zalo.me",
            "Mail" to "https://mail.google.com",
            "Meet" to "https://meet.google.com",
            "Zoom" to "https://zoom.us",
            "Drive" to "https://drive.google.com"
        )
        val appShortcuts = listOf("Trang Camera", "Bộ sưu tập", "Trang Tệp")

        val allNames = webShortcuts.keys.toMutableList().apply { addAll(appShortcuts) }

        AlertDialog.Builder(this)
            .setTitle("Truy cập nhanh")
            .setItems(allNames.toTypedArray()) { _, which ->
                val name = allNames[which]
                when (name) {
                    "Trang Camera" -> openSystemApp(Intent.CATEGORY_APP_CAMERA, "camera")
                    "Bộ sưu tập" -> openSystemApp(Intent.CATEGORY_APP_GALLERY, "bộ sưu tập ảnh")
                    "Trang Tệp" -> openSystemApp(Intent.CATEGORY_APP_FILES, "quản lý tệp")
                    else -> navigateTo(webShortcuts[name]!!)
                }
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun openSystemApp(category: String, label: String) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Không tìm thấy ứng dụng $label trên máy", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Hộp thoại xác nhận mở liên kết ----------

    private fun confirmAndOpen(url: String) {
        AlertDialog.Builder(this)
            .setTitle("Mở liên kết?")
            .setMessage(url)
            .setPositiveButton("Mở") { _, _ -> navigateTo(url) }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    // ---------- WebView ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Chặn popup / tab mới do quảng cáo tự mở (window.open)
            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
            ): Boolean = false

            // Tự cấp quyền camera/mic cho WebView khi trang (Meet/Zoom...) yêu cầu,
            // vì quyền hệ thống đã được xin ở đầu app.
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val host = request?.url?.host
                return if (AdBlocker.isAd(host)) {
                    AdBlocker.blockedResponse()
                } else {
                    super.shouldInterceptRequest(view, request)
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                val scheme = request.url.scheme ?: ""

                // Điều hướng do chính app gọi (thanh địa chỉ, menu, mở lại tab...) -> cho qua luôn
                if (programmaticLoad) {
                    programmaticLoad = false
                    return if (scheme == "http" || scheme == "https") false else true
                }

                // Link không phải web (intent://, market://, app riêng...) -> chặn luôn,
                // không hiện hộp thoại "mở bằng ứng dụng khác"
                if (scheme != "http" && scheme != "https") {
                    return true
                }

                // Link do người dùng bấm trong trang -> luôn hỏi xác nhận trước khi mở
                confirmAndOpen(url)
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url)
                if (!programmaticLoad) {
                    // phòng trường hợp cờ chưa được reset ở lần điều hướng trước
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                edtUrl.setText(url)
                if (!url.isNullOrEmpty() && (sessionHistory.isEmpty() || sessionHistory[0] != url)) {
                    sessionHistory.remove(url)
                    sessionHistory.add(0, url)
                    if (sessionHistory.size > 40) sessionHistory.removeAt(sessionHistory.size - 1)
                }
                view?.evaluateJavascript(ZoomEnabler.JS, null)
                view?.evaluateJavascript(AdOverlayBlocker.JS, null)
                if (YoutubeAdSkipper.isYoutube(url)) {
                    view?.evaluateJavascript(YoutubeAdSkipper.JS, null)
                }
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            programmaticLoad = true
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    // Thoát app -> xoá sạch mọi dấu vết phiên làm việc
    override fun onDestroy() {
        clearAllSessionData()
        super.onDestroy()
    }
}

/**
 * Chặn quảng cáo bằng cách so khớp host của request với danh sách domain trong assets/blocklist.txt.
 * So khớp theo suffix: "ads.example.com" khớp nếu blocklist có "example.com" hoặc "ads.example.com".
 */
object AdBlocker {

    private var domains: HashSet<String> = HashSet()
    private var loaded = false
    var enabled: Boolean = true

    fun init(context: android.content.Context) {
        if (loaded) return
        try {
            context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val d = line.trim().lowercase()
                    if (d.isNotEmpty() && !d.startsWith("#")) {
                        domains.add(d)
                    }
                }
            }
            loaded = true
        } catch (e: Exception) {
            loaded = true
        }
    }

    fun isAd(host: String?): Boolean {
        if (!enabled || host.isNullOrEmpty()) return false
        val h = host.lowercase()
        if (domains.contains(h)) return true
        var idx = h.indexOf('.')
        while (idx != -1) {
            val suffix = h.substring(idx + 1)
            if (domains.contains(suffix)) return true
            idx = h.indexOf('.', idx + 1)
        }
        return false
    }

    fun blockedResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
    }

    fun blockedCount(): Int = domains.size
}

/**
 * Tự động skip/tua qua quảng cáo trên YouTube bằng JS injection, và ẩn banner
 * "Mở trong ứng dụng YouTube".
 */
object YoutubeAdSkipper {

    const val JS = """
        (function() {
            if (window.__adSkipperRunning) return;
            window.__adSkipperRunning = true;
            setInterval(function() {
                try {
                    var skipBtn = document.querySelector(
                        '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .videoAdUiSkipButton'
                    );
                    if (skipBtn) { skipBtn.click(); }

                    var video = document.querySelector('video');
                    var adShowing = document.querySelector('.ad-showing, .ad-interrupting');
                    if (adShowing && video) {
                        video.muted = true;
                        if (video.duration && isFinite(video.duration)) {
                            video.currentTime = video.duration;
                        }
                        video.playbackRate = 16;
                    }

                    var overlays = document.querySelectorAll(
                        '.ytp-ad-overlay-container, .ytp-ad-text-overlay, .ytp-ad-image-overlay, ' +
                        '.video-ads, ytd-promoted-sparkles-web-renderer, ' +
                        'ytd-display-ad-renderer, ytd-in-feed-ad-layout-renderer, ytd-ad-slot-renderer, ' +
                        'ytd-banner-promo-renderer, ytd-mealbar-promo-renderer, #open-app, .app-promo, ' +
                        'tp-yt-paper-dialog.ytd-popup-container'
                    );
                    overlays.forEach(function(el) { el.style.display = 'none'; });
                } catch (e) {}
            }, 300);
        })();
    """

    fun isYoutube(url: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        return url.contains("youtube.com") || url.contains("youtu.be")
    }
}

/**
 * Nhiều trang (như YouTube) tự đặt thẻ <meta viewport> với user-scalable=no
 * để chặn zoom trên mobile. Ghi đè lại thẻ này để cho phép pinch-to-zoom,
 * kể cả khi đang xem video.
 */
object ZoomEnabler {
    const val JS = """
        (function() {
            try {
                var content = 'width=device-width, initial-scale=1.0, maximum-scale=6.0, user-scalable=yes';
                var meta = document.querySelector('meta[name=viewport]');
                if (meta) {
                    meta.setAttribute('content', content);
                } else {
                    var m = document.createElement('meta');
                    m.name = 'viewport';
                    m.content = content;
                    document.head.appendChild(m);
                }
            } catch (e) {}
        })();
    """
}

/**
 * Chặn kiểu quảng cáo "phủ toàn màn hình vô hình" hay dùng để bẫy người dùng
 * bấm vào đâu cũng bị điều hướng sang trang khác: dò các phần tử fixed/absolute
 * phủ gần hết màn hình, có z-index cao bất thường, không phải video/nội dung
 * chính, rồi ẩn đi.
 */
object AdOverlayBlocker {
    const val JS = """
        (function() {
            if (window.__overlayBlockerRunning) return;
            window.__overlayBlockerRunning = true;
            function killOverlays() {
                try {
                    var all = document.querySelectorAll('body *');
                    for (var i = 0; i < all.length; i++) {
                        var el = all[i];
                        var tag = el.tagName;
                        if (tag === 'VIDEO' || tag === 'SCRIPT' || tag === 'STYLE') continue;
                        var style = window.getComputedStyle(el);
                        if (style.position !== 'fixed' && style.position !== 'absolute') continue;
                        var z = parseInt(style.zIndex) || 0;
                        if (z < 999) continue;
                        var rect = el.getBoundingClientRect();
                        var coversScreen = rect.width >= window.innerWidth * 0.85 &&
                                            rect.height >= window.innerHeight * 0.85;
                        if (coversScreen) {
                            el.style.setProperty('display', 'none', 'important');
                            el.style.setProperty('pointer-events', 'none', 'important');
                        }
                    }
                } catch (e) {}
            }
            setInterval(killOverlays, 700);
        })();
    """
}
