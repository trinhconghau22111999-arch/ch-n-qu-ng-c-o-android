package com.h.adblockbrowser

import android.content.res.ColorStateList
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/** Màn phát media DÙNG CHUNG cho cả video (từ Bộ sưu tập) và bản ghi âm (từ Ghi âm) - có đủ
 *  thanh trượt thời gian, nút play/pause, tua lùi/tiến 5s, và mũi tên "←" thoát ở góc trái trên -
 *  đúng như 1 trình phát media thật, thay vì trước đây video giao thẳng cho app ngoài xử lý còn
 *  bản ghi âm phát "chay" bằng MediaPlayer.start() không có nút bấm nào cả. */
class MediaPlayerActivity : AppCompatActivity() {

    private var player: MediaPlayer? = null
    private var isVideo = false
    private var prepared = false
    private var isUserSeeking = false

    private lateinit var surfaceView: SurfaceView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlayPause: TextView
    private lateinit var tvElapsed: TextView
    private lateinit var tvTotal: TextView

    private val handler = Handler(Looper.getMainLooper())

    private val progressRunnable = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && prepared && !isUserSeeking) {
                try {
                    val dur = p.duration
                    if (dur > 0) {
                        seekBar.progress = (p.currentPosition.toLong() * 100 / dur).toInt()
                    }
                    tvElapsed.text = formatTime(p.currentPosition)
                } catch (e: Exception) { }
            }
            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uriStr = intent.getStringExtra(EXTRA_URI)
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""
        isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, false)
        val uri = uriStr?.let { Uri.parse(it) }
        if (uri == null) {
            Toast.makeText(this, "Không tìm thấy tệp media", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        // ── Hàng trên: mũi tên back + tên tệp ──
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), statusBarHeight() + dp(4), dp(16), dp(8))
        }
        val tvTitle = TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            maxLines = 1
            setPadding(dp(4), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        topBar.addView(tvTitle)

        // ── Vùng giữa: khung video (SurfaceView) hoặc biểu tượng nhạc nếu là audio ──
        val mediaArea = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setBackgroundColor(0xFF000000.toInt())
        }
        if (isVideo) {
            surfaceView = SurfaceView(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            mediaArea.addView(surfaceView)
        } else {
            val icon = TextView(this).apply {
                text = "🎵"
                textSize = 96f
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
                )
            }
            mediaArea.addView(icon)
        }

        // ── Vùng dưới: thời gian + thanh trượt + play/pause + tua 5s ──
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), dp(32))
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvElapsed = TextView(this).apply {
            text = "00:00"; setTextColor(0xFFAAAAAA.toInt()); textSize = 12f
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvTotal = TextView(this).apply {
            text = "00:00"; setTextColor(0xFFAAAAAA.toInt()); textSize = 12f
        }
        timeRow.addView(tvElapsed)
        timeRow.addView(spacer)
        timeRow.addView(tvTotal)

        seekBar = SeekBar(this).apply {
            max = 100  // sẽ được set lại sau khi prepare xong
            progressTintList = ColorStateList.valueOf(0xFFC724FF.toInt())
            thumbTintList = ColorStateList.valueOf(0xFFC724FF.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val dur = player?.duration ?: 0
                        val ms = (progress.toLong() * dur / 100).toInt()
                        tvElapsed.text = formatTime(ms)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar) { isUserSeeking = true }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    isUserSeeking = false
                    val dur = player?.duration ?: 0
                    val ms = (sb.progress.toLong() * dur / 100).toInt()
                    if (prepared) player?.seekTo(ms)
                }
            })
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }
        val cellLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(14), 0, dp(14), 0) }

        val btnBack5 = TextView(this).apply {
            text = "⏪\n5s"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(20), dp(10), dp(20), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { seekBy(-5000) }
        }
        btnPlayPause = TextView(this).apply {
            text = "⏸"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFC724FF.toInt())
            setPadding(dp(30), dp(16), dp(30), dp(16))
            isClickable = true
            isFocusable = true
            setOnClickListener { togglePlayPause() }
        }
        val btnFwd5 = TextView(this).apply {
            text = "⏩\n5s"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(20), dp(10), dp(20), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { seekBy(5000) }
        }
        btnRow.addView(btnBack5, cellLp)
        btnRow.addView(btnPlayPause, cellLp)
        btnRow.addView(btnFwd5, cellLp)

        controls.addView(timeRow)
        controls.addView(seekBar)
        controls.addView(btnRow)

        root.addView(topBar)
        root.addView(mediaArea)
        root.addView(controls)
        setContentViewWithNavBar(root)

        player = MediaPlayer()
        try {
            player!!.setDataSource(this, uri)
            if (isVideo) {
                surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) {
                        player?.setDisplay(holder)
                        preparePlayer()
                    }
                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
                    override fun surfaceDestroyed(holder: SurfaceHolder) {}
                })
            } else {
                preparePlayer()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Không phát được tệp này", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun preparePlayer() {
        val p = player ?: return
        p.setOnPreparedListener { mp ->
            prepared = true
            seekBar.max = 100  // luôn dùng % 0-100
            seekBar.progress = 0
            tvTotal.text = formatTime(mp.duration)
            tvElapsed.text = "00:00"
            mp.start()
            btnPlayPause.text = "⏸"
            handler.removeCallbacks(progressRunnable)
            handler.post(progressRunnable)
        }
        p.setOnCompletionListener {
            btnPlayPause.text = "▶"
        }
        p.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Không phát được tệp này", Toast.LENGTH_SHORT).show()
            true
        }
        p.prepareAsync()
    }

    private fun togglePlayPause() {
        val p = player ?: return
        if (!prepared) return
        if (p.isPlaying) {
            p.pause()
            btnPlayPause.text = "▶"
        } else {
            p.start()
            btnPlayPause.text = "⏸"
        }
    }

    private fun seekBy(deltaMs: Int) {
        val p = player ?: return
        if (!prepared) return
        val target = (p.currentPosition + deltaMs).coerceIn(0, p.duration)
        p.seekTo(target)
        seekBar.progress = target
        tvElapsed.text = formatTime(target)
    }

    private fun formatTime(ms: Int): String {
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    override fun onPause() {
        super.onPause()
        // Video: tạm dừng khi rời màn (vd. màn hình tắt) để không tốn pin/dữ liệu chạy nền.
        try { if (player?.isPlaying == true) { player?.pause(); btnPlayPause.text = "▶" } } catch (e: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressRunnable)
        try { player?.release() } catch (e: Exception) { }
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_IS_VIDEO = "extra_is_video"
    }
}
