package com.h.adblockbrowser

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            tvTime.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            tvDate.text = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi")).format(now)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF000000.toInt())
        }

        tvTime = TextView(this).apply {
            textSize = 56f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setShadowLayer(20f, 0f, 0f, 0xFFC724FF.toInt())
        }
        tvDate = TextView(this).apply {
            textSize = 18f
            setTextColor(0xFFC724FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        root.addView(tvTime)
        root.addView(tvDate)
        setContentView(root)

        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
