package com.h.adblockbrowser

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.format.DateFormat
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Màn danh sách tài liệu/ghi chú đã lưu - DÙNG CHUNG cho "Soạn thảo văn bản" (DocsListActivity)
 *  và "Ghi chú" (NotesListActivity), chỉ khác nhau ở [bucket] và [screenTitle]. Bấm "+" để tạo
 *  mới, bấm vào 1 mục để mở lại chỉnh sửa, giữ lâu để xoá. */
abstract class DocListActivity : AppCompatActivity() {

    abstract fun bucket(): String
    abstract fun screenTitle(): String

    private lateinit var listView: ListView
    private lateinit var emptyLabel: TextView
    private var metas: List<DocMeta> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Trước đây onCreate() của màn Ghi chú/Soạn thảo KHÔNG có try/catch: bất kỳ lỗi runtime
        // nào ở đây (vd. dữ liệu cũ hỏng, thiết bị thiếu API...) sẽ làm CẢ APP văng ngay khi bấm
        // vào "Ghi chú". Bọc try/catch giống DocEditorActivity để chỉ đóng màn này + báo lỗi rõ
        // ràng, thay vì kéo sập toàn bộ ứng dụng.
        try {
            buildUi()
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được Ghi chú: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(0, dp(40), 0, 0)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(20), dp(12))
        }
        val title = TextView(this).apply {
            text = screenTitle()
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnNew = TextView(this).apply {
            text = "+ Mới"
            textSize = 15f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            isClickable = true
            setOnClickListener { openEditor(null) }
        }
        titleRow.addView(buildBackArrow())
        titleRow.addView(title)
        titleRow.addView(btnNew)
        root.addView(titleRow)

        listView = ListView(this).apply {
            setBackgroundColor(0xFF0D0D0D.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        emptyLabel = TextView(this).apply {
            text = "Chưa có mục nào. Bấm \"+ Mới\" để tạo."
            setTextColor(0xFF888888.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(emptyLabel)
        root.addView(listView)
        setContentView(root)

        listView.setOnItemClickListener { _, _, position, _ -> openEditor(metas[position].id) }
        listView.setOnItemLongClickListener { _, _, position, _ -> confirmDelete(metas[position]); true }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onResume() {
        super.onResume()
        try {
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Không tải được danh sách ghi chú: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        metas = DocumentStore.list(this, bucket())
        emptyLabel.visibility = if (metas.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        val fmt = { t: Long -> DateFormat.format("HH:mm dd/MM/yyyy", t).toString() }
        val names = metas.map { "${it.title}\n${fmt(it.updatedAt)}" }
        listView.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, names)
    }

    private fun openEditor(id: String?) {
        val intent = Intent(this, DocEditorActivity::class.java).apply {
            putExtra(DocEditorActivity.EXTRA_BUCKET, bucket())
            if (id != null) putExtra(DocEditorActivity.EXTRA_DOC_ID, id)
        }
        startActivity(intent)
    }

    private fun confirmDelete(meta: DocMeta) {
        AlertDialog.Builder(this)
            .setTitle("Xoá \"${meta.title}\"?")
            .setPositiveButton("Xoá") { _, _ ->
                DocumentStore.delete(this, bucket(), meta.id)
                refresh()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}

class DocsListActivity : DocListActivity() {
    override fun bucket() = "docs"
    override fun screenTitle() = "📝 Soạn thảo văn bản"
}

class NotesListActivity : DocListActivity() {
    override fun bucket() = "notes"
    override fun screenTitle() = "🗒 Ghi chú"
}
