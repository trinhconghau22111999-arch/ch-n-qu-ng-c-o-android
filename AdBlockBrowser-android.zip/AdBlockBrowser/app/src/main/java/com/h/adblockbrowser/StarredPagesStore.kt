package com.h.adblockbrowser

import android.content.Context

/** Danh sách trang "gắn dấu sao" của Đa tab - LƯU LÂU DÀI (SharedPreferences), giữ nguyên qua
 *  các lần thoát/mở lại app, đúng tinh thần "Đa tab: thoát ra vào lại vẫn còn nguyên". */
object StarredPagesStore {
    private const val PREFS = "starred_pages_multitab"
    private const val KEY = "urls"

    fun getAll(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("\n").filter { it.isNotBlank() }
    }

    fun isStarred(context: Context, url: String): Boolean = getAll(context).contains(url)

    fun toggle(context: Context, url: String): Boolean {
        val list = getAll(context).toMutableList()
        val nowStarred: Boolean
        if (list.contains(url)) {
            list.remove(url); nowStarred = false
        } else {
            list.add(0, url); nowStarred = true
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, list.joinToString("\n")).apply()
        return nowStarred
    }
}
