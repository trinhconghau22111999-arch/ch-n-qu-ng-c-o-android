package com.h.adblockbrowser

import android.content.Context
import android.os.StatFs
import java.io.File

object StorageInfo {

    /** Tổng dung lượng app này đang chiếm trên máy (bộ nhớ trong + cache), tính bằng byte. */
    fun appUsedBytes(context: Context): Long {
        var total = 0L
        total += dirSize(context.filesDir)
        total += dirSize(context.cacheDir)
        context.getExternalFilesDir(null)?.let { total += dirSize(it) }
        context.externalCacheDir?.let { total += dirSize(it) }
        return total
    }

    private fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var size = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            size += if (f.isDirectory) dirSize(f) else f.length()
        }
        return size
    }

    /** Dung lượng trống / tổng dung lượng của phân vùng lưu trữ chính trên máy (byte). */
    fun deviceFreeBytes(): Long {
        val stat = StatFs(android.os.Environment.getDataDirectory().path)
        return stat.availableBytes
    }

    fun deviceTotalBytes(): Long {
        val stat = StatFs(android.os.Environment.getDataDirectory().path)
        return stat.totalBytes
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var i = -1
        do {
            value /= 1024
            i++
        } while (value >= 1024 && i < units.size - 1)
        return "%.1f %s".format(value, units[i])
    }
}
