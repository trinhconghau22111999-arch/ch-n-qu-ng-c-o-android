package com.h.adblockbrowser

import android.animation.ObjectAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Thanh dọc sát cạnh phải màn hình.
 * - Kéo lên/xuống tự do dọc cạnh phải
 * - Vuốt sang trái → hiện 2 nút: 🌐 Dịch | 🖥 Desktop
 * - Vuốt sang phải / tap ngoài → ẩn 2 nút
 */
class EdgePanel(
    private val context: Context,
    private val onTranslate: () -> Unit,
    private val onToggleDesktop: () -> Unit,
    private val getDesktopLabel: () -> String
) {
    private val prefs: SharedPreferences = context.getSharedPreferences("edge_panel_prefs", 0)

    private lateinit var container: FrameLayout
    private lateinit var handleBar: LinearLayout   // thanh dọc sát phải
    private lateinit var popupRow: LinearLayout    // 2 nút khi vuốt

    private var expanded = false
    private var downY = 0f
    private var barStartY = 0f

    fun attachTo(root: FrameLayout) {
        container = root
        buildViews()
        root.addView(handleBar)
        root.addView(popupRow)
        restoreY()
    }

    private fun buildViews() {
        // ── Thanh dọc sát phải ──
        handleBar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(dp(14f), dp(14f), 0f, 0f, 0f, 0f, dp(14f), dp(14f))
                setColor(0xF0111111.toInt())
                setStroke(dp(1f).toInt(), 0xFF2A2A2A.toInt())
            }
            elevation = dp(10f)
            setPadding(dp(6f).toInt(), dp(10f).toInt(), dp(6f).toInt(), dp(10f).toInt())

            // 3 chấm trang trí dọc
            repeat(3) {
                addView(View(context).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(4f).toInt(), dp(4f).toInt()).also {
                        it.setMargins(0, dp(3f).toInt(), 0, dp(3f).toInt())
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(0x88C724FF.toInt())
                    }
                })
            }

            layoutParams = FrameLayout.LayoutParams(dp(24f).toInt(), dp(72f).toInt()).apply {
                gravity = Gravity.TOP or Gravity.END
            }
        }

        // ── 2 nút popup khi vuốt trái ──
        popupRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(dp(12f), dp(12f), 0f, 0f, 0f, 0f, dp(12f), dp(12f))
                setColor(0xF0111111.toInt())
                setStroke(dp(1f).toInt(), 0xFF333333.toInt())
            }
            elevation = dp(12f)
            visibility = View.GONE

            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.END }
        }

        popupRow.addView(makePopupBtn("🌐", "Dịch") { onTranslate(); collapse() })
        popupRow.addView(View(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1f).toInt(), dp(28f).toInt())
            setBackgroundColor(0x33FFFFFF)
        })
        popupRow.addView(makePopupBtn("🖥", getDesktopLabel()) {
            onToggleDesktop()
            collapse()
        })

        setupDrag()
    }

    private fun makePopupBtn(icon: String, desc: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
            contentDescription = desc
            setTextColor(0xFFEEEEEE.toInt())
            setPadding(dp(18f).toInt(), dp(14f).toInt(), dp(18f).toInt(), dp(14f).toInt())
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }
    }

    private fun setupDrag() {
        var swipeStartX = 0f
        var swipeStartY = 0f

        handleBar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    swipeStartX = event.rawX
                    swipeStartY = event.rawY
                    downY = event.rawY
                    barStartY = handleBar.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - downY
                    val newY = (barStartY + dy)
                        .coerceIn(0f, (container.height - handleBar.height).toFloat())
                    handleBar.y = newY
                    syncPopupY()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - swipeStartX
                    val dy = Math.abs(event.rawY - swipeStartY)
                    // Vuốt sang trái > 40dp và không phải kéo dọc → expand
                    if (dx < -dp(40f) && dy < dp(40f)) {
                        if (expanded) collapse() else expand()
                    } else if (Math.abs(dx) < dp(10f) && dy < dp(10f)) {
                        // Tap nhẹ → toggle
                        if (expanded) collapse() else expand()
                    } else {
                        // Kéo dọc xong → lưu vị trí
                        saveY(handleBar.y)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun expand() {
        expanded = true
        // Update label desktop trước khi show
        (popupRow.getChildAt(2) as? TextView)?.text = if (getDesktopLabel().contains("di động")) "📱" else "🖥"
        popupRow.visibility = View.VISIBLE
        popupRow.alpha = 0f
        popupRow.animate().alpha(1f).translationX(0f).setDuration(180).start()
        syncPopupY()
    }

    private fun collapse() {
        expanded = false
        popupRow.animate().alpha(0f).setDuration(120).withEndAction {
            popupRow.visibility = View.GONE
        }.start()
    }

    private fun syncPopupY() {
        val lp = popupRow.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = handleBar.y.toInt()
        lp.rightMargin = handleBar.width
        popupRow.layoutParams = lp
    }

    private fun saveY(y: Float) = prefs.edit().putFloat("y", y).apply()
    private fun restoreY() {
        handleBar.post {
            val defaultY = (container.height - handleBar.height) / 2f
            val y = prefs.getFloat("y", defaultY)
            handleBar.y = y
            syncPopupY()
        }
    }

    private fun dp(v: Float) = v * context.resources.displayMetrics.density
}
