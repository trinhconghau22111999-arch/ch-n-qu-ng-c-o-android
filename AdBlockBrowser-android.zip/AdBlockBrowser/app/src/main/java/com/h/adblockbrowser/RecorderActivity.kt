package com.h.adblockbrowser

import android.content.ContentValues
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Locale

class RecorderActivity : AppCompatActivity() {

    private var recorder: MediaRecorder? = null
    private var currentUri: Uri? = null
    private var isRecording = false
    private val recHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var recStartTime = 0L
    private lateinit var tvRecTimer: TextView
    private val recTick = object : Runnable {
        override fun run() {
            if (isRecording) {
                val secs = (System.currentTimeMillis() - recStartTime) / 1000
                tvRecTimer.text = "%02d:%02d".format(secs / 60, secs % 60)
                recHandler.postDelayed(this, 500)
            }
        }
    }

    private lateinit var btnRecord: Button
    private lateinit var listView: ListView
    private val recordings = ArrayList<Pair<String, Uri>>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 40, 24, 24)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }
        val title = TextView(this).apply {
            text = "🎙 Ghi âm"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(12, 0, 0, 0)
        }
        titleRow.addView(buildBackArrow())
        titleRow.addView(title)

        btnRecord = Button(this).apply {
            text = "⬤  Bắt đầu ghi âm"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFC724FF.toInt())
            setOnClickListener { toggleRecording() }
        }
        tvRecTimer = TextView(this).apply {
            text = ""
            textSize = 22f
            setTextColor(0xFFC724FF.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }

        listView = ListView(this).apply {
            setBackgroundColor(0xFF0D0D0D.toInt())
        }

        root.addView(titleRow)
        root.addView(btnRecord)
        root.addView(tvRecTimer)
        root.addView(listView)
        setContentView(root)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList())
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val rec = recordings[position]
            // TRƯỚC ĐÂY: phát thẳng bằng MediaPlayer.start() không có nút bấm/thanh trượt nào cả,
            // muốn dừng phải thoát màn hoặc ghi đè bằng bản ghi khác. Giờ mở màn phát riêng
            // (MediaPlayerActivity) có đủ thanh trượt thời gian, play/pause, tua lùi/tiến 5s.
            val intent = Intent(this, MediaPlayerActivity::class.java).apply {
                putExtra(MediaPlayerActivity.EXTRA_URI, rec.second.toString())
                putExtra(MediaPlayerActivity.EXTRA_NAME, rec.first)
                putExtra(MediaPlayerActivity.EXTRA_IS_VIDEO, false)
            }
            startActivity(intent)
        }
        // Giữ ngón tay lâu (long-press) trên 1 bản ghi -> hiện menu Đổi tên / Chia sẻ / Xoá.
        listView.setOnItemLongClickListener { _, _, position, _ ->
            showRecordingMenu(recordings[position])
            true
        }

        loadRecordings()
    }

    private fun toggleRecording() {
        if (isRecording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        val name = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".m4a"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/AdBlockBrowser")
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Không tạo được file")
                currentUri = uri
                val pfd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "w")
                    ?: throw IllegalStateException("Không mở được file")
                recorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(pfd.fileDescriptor)
                    prepare()
                    start()
                }
            } else {
                val dir = android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_MUSIC
                ).resolve("AdBlockBrowser").apply { mkdirs() }
                val file = dir.resolve(name)
                currentUri = Uri.fromFile(file)
                recorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(file.absolutePath)
                    prepare()
                    start()
                }
            }
            isRecording = true
            btnRecord.text = "⬛  Dừng ghi âm"
            recStartTime = System.currentTimeMillis()
            tvRecTimer.text = "00:00"
            recHandler.post(recTick)
            Toast.makeText(this, "Đang ghi âm...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Không ghi âm được: kiểm tra quyền micro", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
            recorder?.release()
        } catch (e: Exception) { }
        recorder = null
        isRecording = false
        recHandler.removeCallbacks(recTick)
        btnRecord.text = "⬤  Bắt đầu ghi âm"
        tvRecTimer.text = ""
        Toast.makeText(this, "Đã lưu vào Music/AdBlockBrowser", Toast.LENGTH_SHORT).show()
        loadRecordings()
    }

    private fun loadRecordings() {
        recordings.clear()
        try {
            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME)
            val selection = MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("%AdBlockBrowser%")
            contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
                MediaStore.Audio.Media.DATE_ADDED + " DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val fname = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                    recordings.add(fname to uri)
                }
            }
        } catch (e: Exception) { }
        adapter.clear()
        adapter.addAll(recordings.map { it.first })
        adapter.notifyDataSetChanged()
    }

    override fun onDestroy() {
        try { recorder?.release() } catch (e: Exception) { }
        recHandler.removeCallbacks(recTick)
        super.onDestroy()
    }

    private fun showRecordingMenu(rec: Pair<String, Uri>) {
        val options = arrayOf("Đổi tên", "Chia sẻ", "Xoá")
        android.app.AlertDialog.Builder(this)
            .setTitle(rec.first)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showRenameDialog(rec)
                    1 -> shareRecording(rec)
                    2 -> confirmDelete(rec)
                }
            }
            .show()
    }

    private fun showRenameDialog(rec: Pair<String, Uri>) {
        val oldName = rec.first
        val dotIdx = oldName.lastIndexOf('.')
        val baseName = if (dotIdx > 0) oldName.substring(0, dotIdx) else oldName
        val ext = if (dotIdx > 0) oldName.substring(dotIdx) else ""

        val input = android.widget.EditText(this).apply {
            setText(baseName)
            setSelection(baseName.length)
            setTextColor(0xFFFFFFFF.toInt())
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Đổi tên bản ghi")
            .setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val newBase = input.text.toString().trim()
                if (newBase.isEmpty()) {
                    Toast.makeText(this, "Tên không được để trống", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, newBase + ext)
                    }
                    contentResolver.update(rec.second, values, null, null)
                    Toast.makeText(this, "Đã đổi tên", Toast.LENGTH_SHORT).show()
                    loadRecordings()
                } catch (e: Exception) {
                    Toast.makeText(this, "Không đổi được tên (có thể do quyền hệ thống)", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun shareRecording(rec: Pair<String, Uri>) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, rec.second)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Chia sẻ bản ghi"))
        } catch (e: Exception) {
            Toast.makeText(this, "Không chia sẻ được tệp này", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(rec: Pair<String, Uri>) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Xoá bản ghi?")
            .setMessage("\"${rec.first}\" sẽ bị xoá vĩnh viễn.")
            .setPositiveButton("Xoá") { _, _ ->
                try {
                    contentResolver.delete(rec.second, null, null)
                    Toast.makeText(this, "Đã xoá", Toast.LENGTH_SHORT).show()
                    loadRecordings()
                } catch (e: Exception) {
                    Toast.makeText(this, "Không xoá được (có thể do quyền hệ thống)", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
