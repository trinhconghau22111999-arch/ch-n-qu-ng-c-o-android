package com.h.adblockbrowser

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var storageRow: LinearLayout

    private val pickWallpaper = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            WallpaperPrefs.set(this, uri.toString())
            Toast.makeText(this, "Đã đổi hình nền trang chủ", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(0, dp(40), 0, dp(24))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(20), dp(16))
        }
        val title = TextView(this).apply {
            text = "⚙ Cài đặt"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), 0, 0, 0)
        }
        titleRow.addView(buildBackArrow())
        titleRow.addView(title)
        root.addView(titleRow)

        root.addView(settingsRow("🖼  Hình nền trang chủ", "Đổi ảnh nền hiện ở trang chủ (trang đầu tiên khi mở app)") {
            pickWallpaper.launch("image/*")
        })
        root.addView(settingsRow("🔒  Khoá ứng dụng", lockSubtitle()) {
            startActivity(Intent(this, AppLockSetupActivity::class.java))
        })

        storageRow = settingsRow("💾  Bộ nhớ", "Đang tính...") { }
        root.addView(storageRow)

        setContentViewWithNavBar(root)
        refreshStorage()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lockSubtitle(): String = when (AppLockPrefs.lockType(this)) {
        "pin" -> "Đang dùng mã PIN"
        "pattern" -> "Đang dùng hình mở khoá"
        else -> "Chưa đặt khoá"
    }

    private fun settingsRow(title: String, subtitle: String, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0D0D0D.toInt())
            setPadding(dp(20), dp(14), dp(20), dp(14))
            isClickable = true
            isFocusable = true
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(2)
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        row.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
        })
        row.addView(TextView(this).apply {
            text = subtitle; textSize = 12f; setTextColor(0xFF888888.toInt())
            setPadding(0, dp(2), 0, 0)
            tag = "subtitle"
        })
        return row
    }

    private fun refreshStorage() {
        Thread {
            val appUsed = StorageInfo.appUsedBytes(this)
            val free = StorageInfo.deviceFreeBytes()
            val total = StorageInfo.deviceTotalBytes()
            runOnUiThread {
                val subtitleView = storageRow.getChildAt(1) as? TextView
                subtitleView?.text = "App dùng ${StorageInfo.formatBytes(appUsed)} · " +
                    "Máy còn trống ${StorageInfo.formatBytes(free)} / ${StorageInfo.formatBytes(total)}"
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        val subtitleView = (root.getChildAt(2) as? LinearLayout)?.getChildAt(1) as? TextView
        subtitleView?.text = lockSubtitle()
    }
}
