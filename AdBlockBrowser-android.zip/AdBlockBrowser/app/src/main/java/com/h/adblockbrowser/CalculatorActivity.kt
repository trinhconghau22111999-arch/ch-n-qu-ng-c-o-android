package com.h.adblockbrowser

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CalculatorActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private var currentValue: Double = 0.0
    private var pendingOp: String? = null
    private var newEntry = true
    private var displayText = "0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        display = TextView(this).apply {
            text = "0"
            textSize = 44f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(32, 80, 32, 40)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 260)
        }
        root.addView(display)

        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 5
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(grid)

        val labels = listOf(
            "C", "±", "%", "÷",
            "7", "8", "9", "×",
            "4", "5", "6", "−",
            "1", "2", "3", "+",
            "0", ".", "=", ""
        )

        for (label in labels) {
            if (label.isEmpty()) continue
            val btn = Button(this).apply {
                text = label
                textSize = 20f
                setTextColor(if (label in listOf("÷", "×", "−", "+", "=")) 0xFFC724FF.toInt() else 0xFFFFFFFF.toInt())
                setBackgroundColor(0xFF0D0D0D.toInt())
                val lp = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f)
                )
                lp.width = 0
                lp.height = 0
                lp.setMargins(6, 6, 6, 6)
                layoutParams = lp
                setOnClickListener { onKeyPress(label) }
            }
            grid.addView(btn)
        }

        setContentView(root)
    }

    private fun onKeyPress(key: String) {
        when (key) {
            "C" -> {
                currentValue = 0.0
                pendingOp = null
                displayText = "0"
                newEntry = true
            }
            "±" -> {
                displayText = if (displayText.startsWith("-")) displayText.substring(1)
                else "-$displayText"
            }
            "%" -> {
                displayText = (displayText.toDoubleOrNull()?.div(100) ?: 0.0).toCleanString()
            }
            "÷", "×", "−", "+" -> {
                currentValue = displayText.toDoubleOrNull() ?: 0.0
                pendingOp = key
                newEntry = true
            }
            "=" -> {
                val second = displayText.toDoubleOrNull() ?: 0.0
                val result = when (pendingOp) {
                    "÷" -> if (second != 0.0) currentValue / second else 0.0
                    "×" -> currentValue * second
                    "−" -> currentValue - second
                    "+" -> currentValue + second
                    else -> second
                }
                displayText = result.toCleanString()
                pendingOp = null
                newEntry = true
            }
            "." -> {
                if (newEntry) {
                    displayText = "0."
                    newEntry = false
                } else if (!displayText.contains(".")) {
                    displayText += "."
                }
            }
            else -> {
                displayText = if (newEntry || displayText == "0") key else displayText + key
                newEntry = false
            }
        }
        display.text = displayText
    }

    private fun Double.toCleanString(): String {
        return if (this == this.toLong().toDouble()) this.toLong().toString() else this.toString()
    }
}
