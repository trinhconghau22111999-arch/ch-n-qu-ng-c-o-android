package com.h.adblockbrowser

import android.graphics.drawable.Drawable
import android.text.style.ImageSpan

/** ImageSpan thường của Android không nhớ được ảnh đó đến từ tệp nào - cần thêm [path] để khi
 *  lưu tài liệu, biết chính xác ảnh nào cần ghi vào DocBlock ở đúng vị trí đó. */
class PathImageSpan(drawable: Drawable, val path: String) : ImageSpan(drawable)
