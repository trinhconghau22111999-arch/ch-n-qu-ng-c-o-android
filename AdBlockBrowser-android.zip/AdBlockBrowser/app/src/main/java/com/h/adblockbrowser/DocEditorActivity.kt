package com.h.adblockbrowser

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

/** Trình soạn thảo dùng chung cho "Soạn thảo văn bản" và "Ghi chú" - gõ văn bản, chèn ảnh ngay
 *  giữa bài (giống Word), lưu lại, và xuất ra file Word (.docx) hoặc PDF thật để chia sẻ/lưu trữ. */
class DocEditorActivity : AppCompatActivity() {

    private lateinit var bucket: String
    private lateinit var docId: String
    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) insertImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được trình soạn thảo: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun buildUi() {
        bucket = intent.getStringExtra(EXTRA_BUCKET) ?: "docs"
        docId = intent.getStringExtra(EXTRA_DOC_ID) ?: DocumentStore.newId()
        val isNew = intent.getStringExtra(EXTRA_DOC_ID) == null

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(36), dp(16), dp(8))
        }
        titleRow.addView(buildBackArrow(onBack = { saveAndFinish() }))
        etTitle = EditText(this).apply {
            hint = "Không tiêu đề"
            setHintTextColor(0xFF666666.toInt())
            setTextColor(0xFFC724FF.toInt())
            textSize = 18f
            setBackgroundColor(0x00000000)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleRow.addView(etTitle)
        root.addView(titleRow)

        // ── Thanh công cụ: Chèn ảnh / Lưu / Xuất Word / Xuất PDF ──
        val toolbarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(4), dp(12), dp(8))
        }
        toolbar.addView(toolButton("🖼 Chèn ảnh") { pickImage.launch("image/*") })
        toolbar.addView(toolButton("💾 Lưu") { saveDoc(); Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show() })
        toolbar.addView(toolButton("📄 Xuất Word") { exportWord() })
        toolbar.addView(toolButton("📕 Xuất PDF") { exportPdf() })
        toolbarScroll.addView(toolbar)
        root.addView(toolbarScroll)

        root.addView(android.view.View(this).apply {
            setBackgroundColor(0xFF222222.toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2)
        })

        etContent = EditText(this).apply {
            hint = "Bắt đầu soạn thảo..."
            setHintTextColor(0xFF555555.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            setBackgroundColor(0x00000000)
            setPadding(dp(20), dp(16), dp(20), dp(40))
            setLineSpacing(6f, 1f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        scroll.addView(etContent)
        // etContent tự chiếm hết chiều cao ScrollView cho phép cuộn được nội dung dài + ảnh chèn
        etContent.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(scroll)

        setContentView(root)

        if (!isNew) {
            val metas = DocumentStore.list(this, bucket)
            etTitle.setText(metas.firstOrNull { it.id == docId }?.title ?: "")
            val blocks = DocumentStore.loadBlocks(this, docId)
            etContent.text = renderBlocksToEditable(blocks)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toolButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF1A1A1A.toInt())
        setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        layoutParams = lp
        isClickable = true
        setOnClickListener { onClick() }
    }

    // ── Chèn ảnh ngay tại vị trí con trỏ, kiểu Word: ảnh nằm giữa văn bản theo đúng thứ tự gõ ──
    private fun insertImage(uri: Uri) {
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            val maxW = resources.displayMetrics.widthPixels - dp(80)
            // Nếu không đọc được kích thước gốc (opts.outWidth <= 0), vẫn LUÔN giảm mẫu 1 mức an
            // toàn thay vì giải mã nguyên bản gốc - ảnh chụp từ camera hiện đại (12-50MP) giải mã
            // không giảm mẫu rất dễ gây OutOfMemoryError, làm crash cả app (đúng lỗi "văng app"
            // khi soạn thảo/ghi chú, vì chèn ảnh trong lúc soạn thảo là thao tác phổ biến nhất).
            if (opts.outWidth <= 0 || opts.outHeight <= 0) {
                sample = 4
            } else {
                while (opts.outWidth / (sample * 2) >= maxW) sample *= 2
            }
            val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts2) } ?: return

            val path = DocumentStore.saveImage(this, bmp)
            val drawable = BitmapDrawable(resources, bmp)
            val scale = maxW.toFloat() / bmp.width.coerceAtLeast(1)
            val w = maxW; val h = (bmp.height * scale).toInt().coerceAtLeast(1)
            drawable.setBounds(0, 0, w, h)

            val editable = etContent.text
            var cursor = etContent.selectionStart.coerceIn(0, editable.length)
            editable.insert(cursor, "\n \n")
            val imgCharPos = cursor + 1
            editable.setSpan(PathImageSpan(drawable, path), imgCharPos, imgCharPos + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            etContent.setSelection((imgCharPos + 2).coerceAtMost(editable.length))
        } catch (e: Exception) {
            Toast.makeText(this, "Không chèn được ảnh này", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Chuyển qua lại giữa Editable (đang gõ) và List<DocBlock> (lưu trữ) ──
    private fun serializeEditor(): List<DocBlock> {
        val editable: Editable = etContent.text
        val blocks = ArrayList<DocBlock>()
        val spans = editable.getSpans(0, editable.length, PathImageSpan::class.java)
            .sortedBy { editable.getSpanStart(it) }
        var cursor = 0
        for (span in spans) {
            val start = editable.getSpanStart(span)
            val end = editable.getSpanEnd(span)
            if (start > cursor) {
                val text = editable.subSequence(cursor, start).toString()
                if (text.isNotEmpty()) blocks.add(DocBlock("text", text = text))
            }
            blocks.add(DocBlock("image", imagePath = span.path))
            cursor = end
        }
        if (cursor < editable.length) {
            val text = editable.subSequence(cursor, editable.length).toString()
            if (text.isNotEmpty()) blocks.add(DocBlock("text", text = text))
        }
        return blocks
    }

    private fun renderBlocksToEditable(blocks: List<DocBlock>): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        val maxW = resources.displayMetrics.widthPixels - dp(80)
        for (b in blocks) {
            if (b.type == "text" && b.text != null) {
                sb.append(b.text)
            } else if (b.type == "image" && b.imagePath != null && File(b.imagePath).exists()) {
                sb.append("\n")
                val start = sb.length
                sb.append(" ")
                val bmp = BitmapFactory.decodeFile(b.imagePath)
                if (bmp != null) {
                    val drawable = BitmapDrawable(resources, bmp)
                    val scale = maxW.toFloat() / bmp.width.coerceAtLeast(1)
                    drawable.setBounds(0, 0, maxW, (bmp.height * scale).toInt().coerceAtLeast(1))
                    sb.setSpan(PathImageSpan(drawable, b.imagePath), start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                sb.append("\n")
            }
        }
        return sb
    }

    private fun saveDoc() {
        val title = etTitle.text.toString().trim()
        DocumentStore.save(this, bucket, docId, title, serializeEditor())
    }

    private fun saveAndFinish() {
        val hasContent = etContent.text.isNotBlank() || etTitle.text.isNotBlank()
        if (hasContent) saveDoc()
        finish()
    }

    private fun exportWord() {
        try {
            saveDoc()
            val title = etTitle.text.toString().trim().ifBlank { "Tai_lieu" }
            val outDir = File(cacheDir, "exports").apply { mkdirs() }
            val outFile = File(outDir, "${sanitize(title)}.docx")
            DocxExporter.export(outFile, title, serializeEditor())
            shareFile(outFile, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        } catch (e: Exception) {
            Toast.makeText(this, "Xuất Word thất bại: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPdf() {
        try {
            saveDoc()
            val title = etTitle.text.toString().trim().ifBlank { "Tai_lieu" }
            val outDir = File(cacheDir, "exports").apply { mkdirs() }
            val outFile = File(outDir, "${sanitize(title)}.pdf")
            PdfExporter.export(outFile, title, serializeEditor())
            shareFile(outFile, "application/pdf")
        } catch (e: Exception) {
            Toast.makeText(this, "Xuất PDF thất bại: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun sanitize(name: String) = name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(50)

    private fun shareFile(file: File, mime: String) {
        val uri = FileProvider.getUriForFile(this, "com.h.adblockbrowser.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Lưu / Chia sẻ tệp"))
    }

    override fun onPause() {
        super.onPause()
        // Trước đây luôn gọi saveDoc() vô điều kiện ở đây - kể cả khi mở ghi chú mới rồi thoát
        // ngay không gõ gì, hoặc chỉ mở app chọn ảnh (pickImage cũng gây onPause) - khiến danh
        // sách ghi chú/tài liệu bị rác thêm mục "Không tiêu đề" trống. Giờ chỉ lưu khi thật sự có
        // nội dung, giống hệt điều kiện đã dùng trong saveAndFinish().
        val hasContent = etContent.text.isNotBlank() || etTitle.text.isNotBlank()
        if (hasContent) {
            try { saveDoc() } catch (e: Exception) { }
        }
    }

    companion object {
        const val EXTRA_BUCKET = "extra_bucket"
        const val EXTRA_DOC_ID = "extra_doc_id"
    }
}
