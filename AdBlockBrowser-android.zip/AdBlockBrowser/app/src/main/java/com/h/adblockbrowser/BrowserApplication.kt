package com.h.adblockbrowser

import android.app.ActivityManager
import android.app.Application
import android.os.Build
import android.os.Process
import android.webkit.WebView

/** BẮT BUỘC phải có class này: trình duyệt chính (tiến trình mặc định) và chế độ Ẩn danh (tiến
 *  trình ":incognito", xem AndroidManifest.xml) ĐỀU dùng WebView. Nếu 2 tiến trình của CÙNG 1 app
 *  dùng chung 1 thư mục dữ liệu WebView, Android sẽ ném lỗi ngay khi WebView thứ 2 khởi tạo:
 *  "WebView cannot be used from more than one process" - CRASH ngay khi mở Ẩn danh. Gọi
 *  WebView.setDataDirectorySuffix() SỚM NHẤT có thể (ngay đầu Application.onCreate(), trước khi
 *  bất kỳ WebView/CookieManager nào được đụng tới trong tiến trình đó) để mỗi tiến trình có thư
 *  mục dữ liệu WebView riêng, không đụng nhau nữa. */
class BrowserApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val processName = currentProcessName()
            if (processName != null && processName.endsWith(":incognito")) {
                try {
                    WebView.setDataDirectorySuffix("incognito")
                } catch (e: Exception) {
                    // Nếu vì lý do nào đó đã có WebView chạm vào trước (không nên xảy ra), bỏ
                    // qua an toàn thay vì crash cứng ngay tại đây.
                }
            }
        }
    }

    private fun currentProcessName(): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return getProcessName()
        }
        val pid = Process.myPid()
        val am = getSystemService(ACTIVITY_SERVICE) as? ActivityManager
        return am?.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName
    }
}
