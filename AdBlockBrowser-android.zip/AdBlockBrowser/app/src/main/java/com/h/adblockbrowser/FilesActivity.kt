package com.h.adblockbrowser

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class FilesActivity : AppCompatActivity() {

    private lateinit var tvPath: TextView
    private lateinit var listView: ListView
    private var currentDir: File = Environment.getExternalStorageDirectory()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 40, 24, 24)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(this).apply {
            text = "📁 Trang Tệp"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(12, 0, 0, 0)
        }
        // Nút back đi lên 1 cấp thư mục trước, giống hệt onBackPressed() (không thoát thẳng nếu
        // đang ở trong thư mục con).
        titleRow.addView(buildBackArrow(onBack = { onBackPressed() }))
        titleRow.addView(title)

        tvPath = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF888888.toInt())
            setPadding(0, 0, 0, 12)
        }

        listView = ListView(this).apply {
            setBackgroundColor(0xFF0D0D0D.toInt())
        }

        root.addView(titleRow)
        root.addView(tvPath)
        root.addView(listView)
        setContentView(root)

        listView.setOnItemClickListener { _, _, position, _ ->
            onItemClick(position)
        }

        openDir(currentDir)
    }

    private var entries: List<File> = emptyList()

    private fun openDir(dir: File) {
        currentDir = dir
        tvPath.text = dir.absolutePath

        val list = (dir.listFiles()?.toMutableList() ?: mutableListOf())
        list.sortWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        entries = list

        val names = ArrayList<String>()
        if (dir.parentFile != null && dir != Environment.getExternalStorageDirectory().parentFile) {
            names.add(".. (Lên thư mục cha)")
        }
        names.addAll(list.map { if (it.isDirectory) "📁 ${it.name}" else "📄 ${it.name}" })

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        listView.adapter = adapter
    }

    private fun onItemClick(position: Int) {
        val hasParent = tvPath.text != Environment.getExternalStorageDirectory().absolutePath &&
            currentDir.parentFile != null
        if (hasParent && position == 0) {
            currentDir.parentFile?.let { openDir(it) }
            return
        }
        val index = if (hasParent) position - 1 else position
        if (index < 0 || index >= entries.size) return
        val file = entries[index]
        if (file.isDirectory) {
            openDir(file)
        } else {
            openFile(file)
        }
    }

    private fun openFile(file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                this, "com.h.adblockbrowser.fileprovider", file
            )
            val mime = contentResolver.getType(uri) ?: guessMime(file.name)
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, mime)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được tệp này", Toast.LENGTH_SHORT).show()
        }
    }

    private fun guessMime(name: String): String {
        return when {
            name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png") -> "image/*"
            name.endsWith(".mp4") || name.endsWith(".mkv") -> "video/*"
            name.endsWith(".mp3") || name.endsWith(".m4a") -> "audio/*"
            name.endsWith(".pdf") -> "application/pdf"
            name.endsWith(".txt") -> "text/plain"
            else -> "*/*"
        }
    }

    override fun onBackPressed() {
        val parent = currentDir.parentFile
        if (parent != null && currentDir != Environment.getExternalStorageDirectory()) {
            openDir(parent)
        } else {
            super.onBackPressed()
        }
    }
}
