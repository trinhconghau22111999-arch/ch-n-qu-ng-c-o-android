package com.h.adblockbrowser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/** Xuất PDF bằng API PdfDocument có sẵn của Android (không cần thư viện ngoài). Tự chia trang
 *  khổ A4 (595 x 842 điểm ảnh ở 72dpi), vẽ văn bản có xuống dòng tự động và ảnh chèn giữa bài,
 *  tự sang trang mới khi hết chỗ. */
object PdfExporter {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 48

    fun export(outFile: File, title: String, blocks: List<DocBlock>) {
        val document = PdfDocument()
        val contentW = PAGE_W - MARGIN * 2

        val titlePaint = TextPaint().apply {
            isAntiAlias = true; color = 0xFF000000.toInt(); textSize = 20f; isFakeBoldText = true
        }
        val bodyPaint = TextPaint().apply {
            isAntiAlias = true; color = 0xFF000000.toInt(); textSize = 13f
        }

        var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, document.pages.size + 1).create())
        var canvas = page.canvas
        var y = MARGIN

        fun newPage() {
            document.finishPage(page)
            page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, document.pages.size + 1).create())
            canvas = page.canvas
            y = MARGIN
        }

        // Tiêu đề
        val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, contentW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        canvas.save(); canvas.translate(MARGIN.toFloat(), y.toFloat()); titleLayout.draw(canvas); canvas.restore()
        y += titleLayout.height + 24

        for (block in blocks) {
            when (block.type) {
                "text" -> {
                    val text = block.text ?: ""
                    if (text.isBlank()) continue
                    val layout = StaticLayout.Builder.obtain(text, 0, text.length, bodyPaint, contentW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(4f, 1f).build()
                    if (y + layout.height <= PAGE_H - MARGIN) {
                        canvas.save(); canvas.translate(MARGIN.toFloat(), y.toFloat()); layout.draw(canvas); canvas.restore()
                        y += layout.height + 10
                    } else {
                        // Đoạn quá dài không vừa hết trang hiện tại - vẽ theo từng dòng gốc
                        // (ngăn bởi ký tự xuống dòng người dùng đã gõ), tự sang trang khi cần.
                        for (rawLine in text.split("\n")) {
                            val lineLayout = StaticLayout.Builder.obtain(rawLine, 0, rawLine.length, bodyPaint, contentW)
                                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
                            if (y + lineLayout.height > PAGE_H - MARGIN) newPage()
                            canvas.save(); canvas.translate(MARGIN.toFloat(), y.toFloat()); lineLayout.draw(canvas); canvas.restore()
                            y += lineLayout.height + 2
                        }
                        y += 8
                    }
                }
                "image" -> {
                    val path = block.imagePath ?: continue
                    val bmp = decodeScaled(path, contentW) ?: continue
                    if (y + bmp.height > PAGE_H - MARGIN) newPage()
                    val left = MARGIN + (contentW - bmp.width) / 2f
                    canvas.drawBitmap(bmp, left, y.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG))
                    y += bmp.height + 16
                }
            }
        }

        document.finishPage(page)
        FileOutputStream(outFile).use { document.writeTo(it) }
        document.close()
    }

    private fun decodeScaled(path: String, maxWidth: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            var sample = 1
            while (opts.outWidth / (sample * 2) >= maxWidth) sample *= 2
            val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeFile(path, opts2) ?: return null
            if (bmp.width <= maxWidth) return bmp
            val scale = maxWidth.toFloat() / bmp.width
            Bitmap.createScaledBitmap(bmp, maxWidth, (bmp.height * scale).toInt(), true)
        } catch (e: Exception) {
            null
        }
    }
}
