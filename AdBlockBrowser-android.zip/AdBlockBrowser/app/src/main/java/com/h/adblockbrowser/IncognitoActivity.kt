package com.h.adblockbrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/** Đa web - mỗi "web" là 1 WebView độc lập, không chia sẻ cookie/session/storage với nhau.
 *  Khi chuyển web: lưu cookie của web hiện tại, xoá CookieManager, nạp cookie của web mới.
 *  Tối đa 8 web, đóng hết thì tự xoá sạch dữ liệu. */
class IncognitoActivity : AppCompatActivity() {

    private data class WebEntry(
        val webView: WebView,
        var title: String = "Web mới",
        var url: String = "",
        var savedCookies: String = ""   // lưu cookie string của web này
    )

    private val webs = ArrayList<WebEntry>()
    private var activeIndex = 0

    private lateinit var webBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctrl = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        ctrl.hide(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
        ctrl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_DEFAULT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        // ── Dãy web nằm ngang ──
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        webBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        scroll.addView(webBar)
        root.addView(scroll)

        // ── Thanh địa chỉ ──
        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        edtUrl = EditText(this).apply {
            hint = "Nhập địa chỉ web..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    loadFromInput(); true
                } else false
            }
        }
        urlRow.addView(edtUrl)
        root.addView(urlRow)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFC724FF.toInt())
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progressBar)

        webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webContainer)

        setContentView(root)
        wipeAll()
        newWeb("https://www.google.com")
    }

    // ── Tạo web mới ──
    @SuppressLint("SetJavaScriptEnabled")
    private fun newWeb(url: String) {
        if (webs.size >= 8) {
            Toast.makeText(this, "Tối đa 8 web", Toast.LENGTH_SHORT).show()
            return
        }
        // Tạo WebView với storage riêng
        val wv = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                userAgentString = UserAgentManager.MOBILE_UA
                saveFormData = false
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            visibility = View.GONE
        }

        val idx = webs.size
        val entry = WebEntry(wv, url = url)
        webs.add(entry)
        webContainer.addView(wv)
        setupCallbacks(wv, idx)
        switchWeb(idx)
        wv.loadUrl(url)
        renderBar()
    }

    // ── Chuyển web: lưu cookie cũ, xoá CookieManager, nạp cookie mới ──
    private fun switchWeb(index: Int) {
        if (index !in webs.indices) return

        // Lưu cookie của web đang active
        if (webs.indices.contains(activeIndex)) {
            val oldUrl = webs[activeIndex].url
            if (oldUrl.isNotEmpty()) {
                webs[activeIndex].savedCookies = CookieManager.getInstance().getCookie(oldUrl) ?: ""
            }
        }

        activeIndex = index

        // Xoá toàn bộ cookie hiện tại
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()

        // Nạp lại cookie của web mới (nếu có)
        val newEntry = webs[index]
        if (newEntry.savedCookies.isNotEmpty() && newEntry.url.isNotEmpty()) {
            val uri = Uri.parse(newEntry.url)
            val domain = "${uri.scheme}://${uri.host}"
            newEntry.savedCookies.split(";").forEach { cookie ->
                CookieManager.getInstance().setCookie(domain, cookie.trim())
            }
            CookieManager.getInstance().flush()
        }

        // Hiển thị WebView đúng
        for ((i, e) in webs.withIndex()) {
            e.webView.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        edtUrl.setText(newEntry.webView.url ?: "")
        renderBar()
    }

    private fun setupCallbacks(wv: WebView, idx: Int) {
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (idx == activeIndex) {
                    progressBar.progress = p
                    progressBar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
            }
            override fun onReceivedTitle(view: WebView?, title: String?) {
                webs.getOrNull(idx)?.title = title?.take(14) ?: "Web mới"
                renderBar()
            }
            override fun onCreateWindow(v: WebView?, d: Boolean, g: Boolean, m: android.os.Message?) = false
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, req: WebResourceRequest?): WebResourceResponse? {
                return if (AdBlocker.isAd(req?.url?.host)) AdBlocker.blockedResponse()
                else super.shouldInterceptRequest(view, req)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val s = req?.url?.scheme ?: return false
                return s != "http" && s != "https"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                webs.getOrNull(idx)?.url = url ?: ""
                if (idx == activeIndex) edtUrl.setText(url)
                view?.evaluateJavascript(AdOverlayBlocker.JS, null)
                if (YoutubeAdSkipper.isYoutube(url)) view?.evaluateJavascript(YoutubeAdSkipper.JS, null)
            }
        }
    }

    private fun closeWeb(index: Int) {
        if (index !in webs.indices) return
        val e = webs.removeAt(index)
        webContainer.removeView(e.webView)
        e.webView.destroy()
        if (webs.isEmpty()) { closeAll(); return }
        switchWeb(index.coerceAtMost(webs.size - 1))
        renderBar()
    }

    private fun renderBar() {
        webBar.removeAllViews()
        for ((i, e) in webs.withIndex()) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(if (i == activeIndex) 0xFF2A0033.toInt() else 0xFF141414.toInt())
                setPadding(dp(12), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = dp(6) }
                isClickable = true
                setOnClickListener { switchWeb(i) }
            }
            cell.addView(TextView(this).apply {
                text = e.title
                textSize = 12f
                setTextColor(if (i == activeIndex) 0xFFC724FF.toInt() else 0xFFAAAAAA.toInt())
            })
            cell.addView(TextView(this).apply {
                text = " ✕"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                isClickable = true
                setOnClickListener { closeWeb(i) }
            })
            webBar.addView(cell)
        }
        if (webs.size < 8) {
            webBar.addView(TextView(this).apply {
                text = "+ Web"
                textSize = 13f
                setTextColor(0xFFC724FF.toInt())
                setPadding(dp(12), dp(8), dp(12), dp(8))
                isClickable = true
                setOnClickListener { newWeb("https://www.google.com") }
            })
        }
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://"))
            input = if (input.contains(".") && !input.contains(" ")) "https://$input"
            else "https://www.google.com/search?q=" + Uri.encode(input)
        webs.getOrNull(activeIndex)?.webView?.loadUrl(input)
    }

    private fun closeAll() {
        wipeAll()
        finish()
    }

    private fun wipeAll() {
        for (e in webs) {
            e.webView.clearHistory()
            e.webView.clearCache(true)
            e.webView.clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            c.hide(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
        }
    }

    override fun onBackPressed() {
        val wv = webs.getOrNull(activeIndex)?.webView
        if (wv != null && wv.canGoBack()) wv.goBack()
        else closeAll()
    }

    override fun onDestroy() {
        wipeAll()
        for (e in webs) e.webView.destroy()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
