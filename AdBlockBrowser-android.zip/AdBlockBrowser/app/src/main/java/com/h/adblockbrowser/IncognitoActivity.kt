package com.h.adblockbrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Chế độ Ẩn danh - chạy ở TIẾN TRÌNH RIÊNG (xem android:process trong Manifest) nên dữ liệu
 *  (cookie, phiên đăng nhập, cache) hoàn toàn TÁCH BIỆT khỏi trình duyệt chính, không ảnh hưởng
 *  các tài khoản đang đăng nhập ở đó. Không lưu lịch sử (không có màn "Đa nhiệm" như trình duyệt
 *  chính), tự xoá sạch mọi dữ liệu khi đóng. Mở được KHÔNG GIỚI HẠN số tab, các tab chạy SONG SONG
 *  (chỉ ẩn/hiện chứ không tạm dừng tải), giữ ngón tay lên 1 link/ảnh để hiện menu "Mở trong tab
 *  mới", có nút đánh dấu sao (★) cho từng trang + nút mở lại toàn bộ các trang đã đánh dấu sao.
 *  Danh sách sao được LƯU BỀN (SharedPreferences riêng "incognito_starred_prefs") nên KHÔNG mất
 *  khi đóng Ẩn danh - chỉ tồn tại trong app nhỏ Ẩn danh này, không đồng bộ/chia sẻ với bất kỳ app
 *  nhỏ nào khác trong Mini Phone. */
class IncognitoActivity : AppCompatActivity() {

    private data class Tab(val webView: WebView, var title: String = "Tab mới")

    private val tabs = ArrayList<Tab>()
    private var activeIndex = 0
    private var programmaticLoad = false





    private lateinit var tabBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        insetsController.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        // Không còn thanh tiêu đề (mũi tên back + khoảng trống dành cho status bar) ở đây nữa -
        // đóng chế độ Ẩn danh vẫn hoạt động bình thường qua nút/cử chỉ Back của điện thoại
        // (xem onBackPressed() bên dưới), không cần nút back riêng nổi đè lên đầu màn hình.

        // ── Dãy tab nằm ngang, kiểu tab trên máy tính ──
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        tabScroll.addView(tabBar)
        root.addView(tabScroll)

        // ── Thanh địa chỉ ──
        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        edtUrl = EditText(this).apply {
            hint = "Nhập địa chỉ web..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    loadFromInput(); true
                } else false
            }
        }
        urlRow.addView(edtUrl)



        root.addView(urlRow)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFC724FF.toInt())
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progressBar)

        webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webContainer)

        setContentViewWithNavBar(root)

        // Xoá sạch trước khi bắt đầu, đảm bảo không dính dấu vết từ lần Ẩn danh trước
        wipeAllData()
        newTab("https://www.google.com")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ── Quản lý tab ──
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.userAgentString = UserAgentManager.MOBILE_UA
            // Ẩn danh: không lưu mật khẩu/form đã điền, không cho tự động điền lại
            settings.saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            }
            visibility = View.INVISIBLE
        }
        val tab = Tab(webView)
        val index = tabs.size
        tabs.add(tab)
        webContainer.addView(webView)
        setupWebViewCallbacks(webView, index)
        setupLongPressMenu(webView)
        switchTab(index)
        loadInTab(index, url)
        renderTabBar()
    }

    /** Giữ ngón tay lên 1 link hoặc ảnh -> hiện menu nhỏ có nút "Mở trong tab mới" (+ tiện thể có
     *  nút đánh dấu sao/sao chép luôn cho đỡ phải mở trang ra mới đánh dấu được). */
    private fun setupLongPressMenu(webView: WebView) {
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val targetUrl = when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                WebView.HitTestResult.IMAGE_TYPE -> result.extra
                else -> null
            }
            if (!targetUrl.isNullOrBlank()) {
                showLinkContextMenu(targetUrl)
                true
            } else false
        }
    }

    private fun showLinkContextMenu(url: String) {
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        fun row(label: String, onClick: () -> Unit) {
            panel.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(20), dp(16), dp(20), dp(16))
                isClickable = true
                setOnClickListener { dialog.dismiss(); onClick() }
            })
        }
        row("↗  Mở trong tab mới") { newTab(url) }
            cell.addView(TextView(this).apply {
                text = " ✕"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                isClickable = true
                setOnClickListener { closeTab(i) }
            })
            tabBar.addView(cell)
        }
        tabBar.addView(TextView(this).apply {
            text = "+ Tab"
            textSize = 13f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            isClickable = true
            setOnClickListener { newTab("https://www.google.com") }
        })
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = if (input.contains(".") && !input.contains(" ")) "https://$input"
            else "https://www.google.com/search?q=" + Uri.encode(input)
        }
        programmaticLoad = true
        loadInTab(activeIndex, input)
    }

    private fun closeIncognito() {
        wipeAllData()
        finish()
    }

    private fun wipeAllData() {
        for (t in tabs) {
            t.webView.clearHistory()
            t.webView.clearCache(true)
            t.webView.clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onBackPressed() {
        val current = tabs.getOrNull(activeIndex)?.webView
        if (current != null && current.canGoBack()) {
            programmaticLoad = true
            current.goBack()
        } else {
            closeIncognito()
        }
    }

    override fun onDestroy() {
        wipeAllData()
        for (t in tabs) t.webView.destroy()
        super.onDestroy()
    }
}
