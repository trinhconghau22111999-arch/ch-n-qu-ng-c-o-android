package com.h.adblockbrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Chế độ Ẩn danh - chạy ở TIẾN TRÌNH RIÊNG (xem android:process trong Manifest) nên dữ liệu
 *  (cookie, phiên đăng nhập, cache) hoàn toàn TÁCH BIỆT khỏi trình duyệt chính, không ảnh hưởng
 *  các tài khoản đang đăng nhập ở đó. Không lưu lịch sử (không có màn "Đa nhiệm" như trình duyệt
 *  chính), tự xoá sạch mọi dữ liệu khi đóng. Mở được KHÔNG GIỚI HẠN số tab, các tab chạy SONG SONG
 *  (chỉ ẩn/hiện chứ không tạm dừng tải), giữ ngón tay lên 1 link/ảnh để hiện menu "Mở trong tab
 *  mới", có nút đánh dấu sao (★) cho từng trang + nút mở lại toàn bộ các trang đã đánh dấu sao.
 *  khi đóng Ẩn danh - chỉ tồn tại trong app nhỏ Ẩn danh này, không đồng bộ/chia sẻ với bất kỳ app
 *  nhỏ nào khác trong Mini Phone. */
class IncognitoActivity : AppCompatActivity() {

    private data class Tab(val webView: WebView, var title: String = "Tab mới")

    private val tabs = ArrayList<Tab>()
    private var activeIndex = 0
    private var programmaticLoad = false

    // Danh sách link đã đánh dấu sao - LƯU BỀN trong SharedPreferences RIÊNG của Ẩn danh
    // Phone, và KHÔNG bị xoá khi đóng Ẩn danh (khác với cookie/cache/lịch sử vẫn xoá sạch như cũ -
    // đánh dấu sao là thứ người dùng CHỦ ĐỘNG lưu nên không tính là "dấu vết phiên duyệt web").




    private lateinit var tabBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        insetsController.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        // Không còn thanh tiêu đề (mũi tên back + khoảng trống dành cho status bar) ở đây nữa -
        // đóng chế độ Ẩn danh vẫn hoạt động bình thường qua nút/cử chỉ Back của điện thoại
        // (xem onBackPressed() bên dưới), không cần nút back riêng nổi đè lên đầu màn hình.

        // ── Dãy tab nằm ngang, kiểu tab trên máy tính ──
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        tabScroll.addView(tabBar)
        root.addView(tabScroll)

        // ── Thanh địa chỉ ──
        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        edtUrl = EditText(this).apply {
            hint = "Nhập địa chỉ web..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    loadFromInput(); true
                } else false
            }
        }
        urlRow.addView(edtUrl)



        root.addView(urlRow)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFC724FF.toInt())
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progressBar)

        webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webContainer)

        setContentViewWithNavBar(root)

        // Xoá sạch trước khi bắt đầu, đảm bảo không dính dấu vết từ lần Ẩn danh trước
        wipeAllData()
        newTab("https://www.google.com")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ── Quản lý tab ──
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.userAgentString = UserAgentManager.MOBILE_UA
            // Ẩn danh: không lưu mật khẩu/form đã điền, không cho tự động điền lại
            settings.saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            }
            visibility = View.INVISIBLE
        }
        val tab = Tab(webView)
        val index = tabs.size
        tabs.add(tab)
        webContainer.addView(webView)
        setupWebViewCallbacks(webView, index)
        setupLongPressMenu(webView)
        switchTab(index)
        loadInTab(index, url)
        renderTabBar()
    }

    /** Giữ ngón tay lên 1 link hoặc ảnh -> hiện menu nhỏ có nút "Mở trong tab mới" (+ tiện thể có
     *  nút đánh dấu sao/sao chép luôn cho đỡ phải mở trang ra mới đánh dấu được). */
    private fun setupLongPressMenu(webView: WebView) {
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val targetUrl = when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                WebView.HitTestResult.IMAGE_TYPE -> result.extra
                else -> null
            }
            if (!targetUrl.isNullOrBlank()) {
                showLinkContextMenu(targetUrl)
                true
            } else false
        }
    }

    private fun showLinkContextMenu(url: String) {
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        fun row(label: String, onClick: () -> Unit) {
            panel.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(20), dp(16), dp(20), dp(16))
                isClickable = true
                setOnClickListener { dialog.dismiss(); onClick() }
            })
        }
        row("↗  Mở trong tab mới") { newTab(url) }
        }
        row("⧉  Sao chép liên kết") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("url", url))
            android.widget.Toast.makeText(this, "Đã sao chép", android.widget.Toast.LENGTH_SHORT).show()
        }
        dialog.setContentView(panel)
        dialog.show()
    }

    /** Bật/tắt đánh dấu sao cho URL của tab đang mở. */



    /** Danh sách các link đã đánh dấu sao, mỗi dòng bấm vào để mở trong tab mới, cộng nút mở TẤT
     *  CẢ cùng lúc (mỗi link 1 tab riêng, chạy song song luôn nhờ đã bỏ giới hạn số tab). */
            android.widget.Toast.makeText(this, "Chưa đánh dấu sao link nào", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(4), dp(12), dp(4), dp(4))
        }
        panel.addView(TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(20), dp(14), dp(20), dp(14))
            isClickable = true
            setOnClickListener {
                dialog.dismiss()
            }
        })
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400))
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener { dialog.dismiss(); newTab(url) }
                addView(TextView(this@IncognitoActivity).apply {
                    text = url
                    textSize = 13f
                    setTextColor(0xFFDDDDDD.toInt())
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    setPadding(dp(20), dp(12), dp(8), dp(12))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(this@IncognitoActivity).apply {
                    text = "✕"
                    textSize = 13f
                    setTextColor(0xFF888888.toInt())
                    setPadding(dp(14), dp(12), dp(20), dp(12))
                    isClickable = true
                    setOnClickListener {
                        dialog.dismiss()
                    }
                })
            })
        }
        scroll.addView(list)
        panel.addView(scroll)
        dialog.setContentView(panel)
        dialog.show()
    }

    private fun setupWebViewCallbacks(webView: WebView, index: Int) {
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tabs.getOrNull(activeIndex)?.webView === webView) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (index < tabs.size) {
                    tabs[index].title = title?.take(14) ?: "Tab mới"
                    renderTabBar()
                }
            }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val host = request?.url?.host
                return if (AdBlocker.isAd(host)) AdBlocker.blockedResponse() else super.shouldInterceptRequest(view, request)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme != "http" && scheme != "https"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (tabs.getOrNull(activeIndex)?.webView === webView) {
                    edtUrl.setText(url)
                }
                view?.evaluateJavascript(ZoomEnabler.JS, null)
                view?.evaluateJavascript(AdOverlayBlocker.JS, null)
                view?.evaluateJavascript(TranslateInjector.JS, null)
                if (YoutubeAdSkipper.isYoutube(url)) view?.evaluateJavascript(YoutubeAdSkipper.JS, null)
            }
        }
    }

    private fun loadInTab(index: Int, url: String) {
        tabs.getOrNull(index)?.webView?.loadUrl(url)
    }

    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        activeIndex = index
        for ((i, t) in tabs.withIndex()) {
            t.webView.visibility = if (i == index) View.VISIBLE else View.INVISIBLE
        }
        edtUrl.setText(tabs[index].webView.url ?: "")
        renderTabBar()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        webContainer.removeView(tab.webView)
        tab.webView.destroy()
        if (tabs.isEmpty()) {
            closeIncognito()
            return
        }
        val newActive = index.coerceAtMost(tabs.size - 1)
        switchTab(newActive)
        renderTabBar()
    }

    private fun renderTabBar() {
        tabBar.removeAllViews()
        for ((i, tab) in tabs.withIndex()) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(if (i == activeIndex) 0xFF2A0033.toInt() else 0xFF141414.toInt())
                setPadding(dp(12), dp(8), dp(8), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.marginEnd = dp(6)
                layoutParams = lp
                isClickable = true
                setOnClickListener { switchTab(i) }
            }
            cell.addView(TextView(this).apply {
                text = tab.title
                textSize = 12f
                setTextColor(if (i == activeIndex) 0xFFC724FF.toInt() else 0xFFAAAAAA.toInt())
            })
            cell.addView(TextView(this).apply {
                text = " ✕"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                isClickable = true
                setOnClickListener { closeTab(i) }
            })
            tabBar.addView(cell)
        }
        tabBar.addView(TextView(this).apply {
            text = "+ Tab"
            textSize = 13f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            isClickable = true
            setOnClickListener { newTab("https://www.google.com") }
        })
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = if (input.contains(".") && !input.contains(" ")) "https://$input"
            else "https://www.google.com/search?q=" + Uri.encode(input)
        }
        programmaticLoad = true
        loadInTab(activeIndex, input)
    }

    private fun closeIncognito() {
        wipeAllData()
        finish()
    }

    private fun wipeAllData() {
        for (t in tabs) {
            t.webView.clearHistory()
            t.webView.clearCache(true)
            t.webView.clearFormData()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onBackPressed() {
        val current = tabs.getOrNull(activeIndex)?.webView
        if (current != null && current.canGoBack()) {
            programmaticLoad = true
            current.goBack()
        } else {
            closeIncognito()
        }
    }

    override fun onDestroy() {
        wipeAllData()
        for (t in tabs) t.webView.destroy()
        super.onDestroy()
    }
}
