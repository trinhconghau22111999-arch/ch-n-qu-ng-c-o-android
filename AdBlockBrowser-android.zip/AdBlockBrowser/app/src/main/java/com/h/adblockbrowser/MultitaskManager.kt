package com.h.adblockbrowser

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** 1 mục trong danh sách Đa nhiệm: hoặc là 1 trang web (key = URL thật), hoặc 1 app nội bộ của
 *  Mini Phone như Cài đặt/Ghi chú/Máy tính (key = "app://<tên class>"). */
data class TabEntry(
    val key: String,
    val title: String,
    val thumbnail: Bitmap?,
    val webState: Bundle? = null,
    val isApp: Boolean = false,
    val appClass: Class<*>? = null,
    val icon: String = "🌐"
)

/**
 * VIẾT LẠI HOÀN TOÀN phần logic của tính năng Đa nhiệm (danh sách trang/app đang mở, kiểu màn
 * recent-apps của Android). Thiết kế lại đơn giản, gọn:
 *
 * - 1 danh sách [tabs] duy nhất, thêm/cập nhật qua [upsert] - không còn 2 đường code riêng cho
 *   "tab web" và "app nội bộ" như trước.
 * - Chụp thumbnail bằng cách vẽ WebView THẲNG xuống 1 canvas đã thu nhỏ sẵn (canvas.scale trước
 *   khi draw) - không bao giờ cấp phát bitmap kích thước đầy đủ của trang, nên không thể OOM dù
 *   trang nguồn dài/nặng cỡ nào (Shopee, Lazada...).
 * - Mọi thao tác public đều tự bọc an toàn, lỗi chỉ báo Toast chứ không bao giờ văng ra ngoài làm
 *   kẹt luồng xử lý sự kiện chạm của 3 nút điều hướng.
 */
class MultitaskManager(
    private val context: Context,
    private val webView: WebView,
    private val onNavigate: (TabEntry) -> Unit,
    private val onClearAll: () -> Unit
) {
    private val tabs = mutableListOf<TabEntry>()

    private companion object {
        const val MAX_TABS = 12
        const val THUMB_W = 200
        const val THUMB_H = 360
    }

    /** Chụp lại trang web hiện tại (URL, tiêu đề, ảnh thu nhỏ, vị trí cuộn/lịch sử) - gọi mỗi khi
     *  rời trang (Home/Back) hoặc ngay sau khi trang tải xong. */
    fun captureCurrentPage() {
        val url = webView.url ?: return
        val title = webView.title?.takeIf { it.isNotBlank() } ?: url
        upsert(TabEntry(key = url, title = title, thumbnail = captureThumbnail(), webState = saveWebState()))
    }

    /** Thêm/cập nhật 1 app nội bộ (Cài đặt, Ghi chú, Máy tính...) vào danh sách khi nó được mở
     *  trong phiên này - bấm vào thẻ tương ứng trong màn Đa nhiệm sẽ mở lại đúng app đó. */
    fun addAppEntry(appClass: Class<*>, title: String, icon: String) {
        upsert(TabEntry(key = "app://${appClass.name}", title = title, thumbnail = null,
            isApp = true, appClass = appClass, icon = icon))
    }

    /** Xoá sạch toàn bộ danh sách - dùng khi bấm "Xoá tất cả". */
    fun clearAll() {
        tabs.clear()
    }

    /** Hiện màn Đa nhiệm dạng lưới card. */
    fun show() {
        try {
            captureCurrentPage()
        } catch (e: Exception) {
            // Chụp trang hiện tại lỗi thì vẫn cứ mở màn Đa nhiệm với danh sách đã có, không vì
            // 1 lỗi chụp ảnh mà chặn cả tính năng.
        }
        if (tabs.isEmpty()) {
            Toast.makeText(context, "Chưa có trang nào đang mở", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val dialog = Dialog(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            dialog.setContentView(buildOverlay(dialog))
            dialog.show()
        } catch (e: Exception) {
            Toast.makeText(context, "Không mở được màn Đa nhiệm", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- nội bộ ----------

    private fun upsert(entry: TabEntry) {
        val existingIndex = tabs.indexOfFirst {
            if (entry.isApp) it.isApp && it.appClass == entry.appClass else !it.isApp && it.key == entry.key
        }
        if (existingIndex >= 0) tabs[existingIndex] = entry else tabs.add(0, entry)
        while (tabs.size > MAX_TABS) tabs.removeAt(tabs.size - 1)
    }

    private fun saveWebState(): Bundle? = try {
        Bundle().also { webView.saveState(it) }
    } catch (e: Exception) {
        null
    }

    /** Vẽ WebView thẳng xuống 1 canvas ĐÃ THU NHỎ SẴN kích thước cố định - không bao giờ cấp phát
     *  bitmap full-size của cả trang, nên luôn chỉ tốn đúng bấy nhiêu bộ nhớ cho ảnh nhỏ, tránh
     *  hoàn toàn nguy cơ OutOfMemoryError từng gặp trên các trang dài/nặng. */
    private fun captureThumbnail(): Bitmap? {
        if (webView.width <= 0 || webView.height <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(THUMB_W, THUMB_H, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.scale(THUMB_W / webView.width.toFloat(), THUMB_H / webView.height.toFloat())
            webView.draw(canvas)
            bmp
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun buildOverlay(dialog: Dialog): View {
        val root = FrameLayout(context).apply { setBackgroundColor(0xE6000000.toInt()) }

        val label = TextView(context).apply {
            text = "Cửa sổ gần đây"
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(48), 0, dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
            )
        }

        val grid = GridLayout(context).apply {
            columnCount = 2
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        tabs.forEach { grid.addView(buildCard(it, dialog)) }

        val scroll = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ).also { it.topMargin = dp(80); it.bottomMargin = dp(72) }
            addView(grid)
        }

        val btnClearAll = TextView(context).apply {
            text = "🗑  Xoá tất cả"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(0xFF333333.toInt())
            }
            setPadding(dp(32), dp(14), dp(32), dp(14))
            isClickable = true
            isFocusable = true
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).also { it.bottomMargin = dp(20) }
            setOnClickListener {
                // "Xoá tất cả" = dọn sạch danh sách + đóng màn Đa nhiệm + VỀ THẲNG TRANG CHÍNH.
                clearAll()
                Toast.makeText(context, "Đã xoá tất cả cửa sổ", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                onClearAll()
            }
        }

        root.addView(label)
        root.addView(scroll)
        root.addView(btnClearAll)
        return root
    }

    private fun buildCard(tab: TabEntry, dialog: Dialog): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(0xFF1A1A1A.toInt())
                setStroke(dp(1), 0xFF333333.toInt())
            }
            elevation = dp(4).toFloat()
            clipToOutline = true
            layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            ).apply {
                width = 0
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                dialog.dismiss()
                onNavigate(tab)
            }
        }

        val thumb: View = when {
            tab.isApp -> TextView(context).apply {
                text = tab.icon
                textSize = 48f
                gravity = Gravity.CENTER
                setBackgroundColor(0xFF111111.toInt())
            }
            tab.thumbnail != null -> ImageView(context).apply {
                setImageBitmap(tab.thumbnail)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            else -> TextView(context).apply {
                text = "🌐"
                textSize = 36f
                gravity = Gravity.CENTER
                setBackgroundColor(0xFF111111.toInt())
            }
        }
        thumb.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160))

        val titleView = TextView(context).apply {
            text = tab.title.take(30)
            textSize = 11f
            setTextColor(0xFFCCCCCC.toInt())
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), dp(6), dp(8), dp(4))
        }
        val subtitleView = TextView(context).apply {
            text = if (tab.isApp) "" else tab.key.removePrefix("https://").removePrefix("http://").take(30)
            textSize = 10f
            setTextColor(0xFF888888.toInt())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), dp(8))
        }

        val btnRemove = TextView(context).apply {
            text = "✕"
            textSize = 12f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                tabs.remove(tab)
                (card.parent as? ViewGroup)?.removeView(card)
            }
        }
        val topRow = FrameLayout(context).apply {
            addView(btnRemove, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ))
        }

        card.addView(thumb)
        card.addView(topRow)
        card.addView(titleView)
        card.addView(subtitleView)
        return card
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
