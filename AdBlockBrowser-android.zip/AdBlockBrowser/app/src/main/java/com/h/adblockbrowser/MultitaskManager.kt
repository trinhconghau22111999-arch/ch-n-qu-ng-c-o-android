package com.h.adblockbrowser

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.webkit.WebView
import android.widget.*

data class TabEntry(
    val url: String,
    val title: String,
    var thumbnail: Bitmap?,
    // Trạng thái WebView (lịch sử điều hướng + vị trí cuộn...) tại thời điểm rời trang này.
    // KHÔNG chạy WebView nền - chỉ lưu dữ liệu trạng thái nhẹ này, khi mở lại tab thì phục
    // hồi (restoreState) thay vì tải lại trang từ đầu.
    var state: Bundle? = null,
    // Dành cho các app NỘI BỘ (Cài đặt, Máy tính, Ghi chú...) khi mở trong phiên - hiện luôn
    // trong màn Đa nhiệm cùng các tab web, bấm vào mở lại đúng app đó thay vì điều hướng URL.
    val isApp: Boolean = false,
    val appClass: Class<*>? = null,
    val icon: String = "🌐"
)

class MultitaskManager(
    private val context: Context,
    private val webView: WebView,
    private val onNavigate: (TabEntry) -> Unit,
    private val onClearAll: () -> Unit
) {
    private val tabs = mutableListOf<TabEntry>()

    /** Chụp thumbnail + trạng thái trang hiện tại và lưu vào danh sách tab */
    fun captureCurrentPage() {
        val url = webView.url ?: return
        val title = webView.title ?: url
        // Chụp bitmap từ WebView (scale nhỏ để tiết kiệm RAM)
        val bmp = try {
            webView.isDrawingCacheEnabled = true
            webView.buildDrawingCache()
            val raw = webView.drawingCache
            if (raw != null) Bitmap.createScaledBitmap(raw, 200, 360, true) else null
        } catch (e: Exception) { null } finally {
            webView.isDrawingCacheEnabled = false
        }
        // Lưu trạng thái nhẹ (không phải chạy nền) để khi quay lại KHÔNG tải lại trang
        val state = Bundle().also { webView.saveState(it) }
        val existing = tabs.indexOfFirst { it.url == url }
        if (existing >= 0) {
            tabs[existing] = TabEntry(url, title, bmp, state)
        } else {
            tabs.add(0, TabEntry(url, title, bmp, state))
            if (tabs.size > 12) tabs.removeAt(tabs.size - 1)
        }
    }

    /** Thêm/cập nhật 1 "app nội bộ" (Cài đặt, Máy tính, Ghi chú...) vào danh sách Đa nhiệm khi
     *  nó được mở trong phiên này - để bấm vào màn Đa nhiệm mở lại đúng app đó, giống các tab
     *  web. Dùng key riêng ("app://<tên class>") để không trùng với URL web thật nào. */
    fun addAppEntry(appClass: Class<*>, title: String, icon: String) {
        val key = "app://${appClass.name}"
        val entry = TabEntry(key, title, null, null, isApp = true, appClass = appClass, icon = icon)
        val existing = tabs.indexOfFirst { it.isApp && it.appClass == appClass }
        if (existing >= 0) {
            tabs[existing] = entry
        } else {
            tabs.add(0, entry)
            if (tabs.size > 12) tabs.removeAt(tabs.size - 1)
        }
    }

    /** Hiện màn đa nhiệm kiểu Android — lưới card thumbnail */
    fun show() {
        captureCurrentPage()
        if (tabs.isEmpty()) {
            Toast.makeText(context, "Chưa có trang nào", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = Dialog(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(buildOverlay(dialog))
        dialog.show()
    }

    private fun buildOverlay(dialog: Dialog): View {
        val root = FrameLayout(context).apply {
            setBackgroundColor(0xE6000000.toInt())
        }

        val label = TextView(context).apply {
            text = "Cửa sổ gần đây"
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(48), 0, dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        }

        val scroll = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ).also { it.topMargin = dp(80); it.bottomMargin = dp(72) }
        }

        val grid = GridLayout(context).apply {
            columnCount = 2
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        tabs.forEach { tab ->
            grid.addView(buildCard(tab, dialog))
        }

        scroll.addView(grid)

        val btnClose = TextView(context).apply {
            text = "🗑  Xoá tất cả"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(0xFF333333.toInt())
            }
            setPadding(dp(32), dp(14), dp(32), dp(14))
            isClickable = true; isFocusable = true
            setOnClickListener {
                // Xoá đúng nghĩa "Xoá tất cả": dọn sạch toàn bộ danh sách tab đang lưu, tắt màn
                // đa nhiệm, VÀ quay thẳng về trang chính luôn (trước đây chỉ dọn danh sách rồi
                // đóng dialog, còn đứng lại đúng trang web đang xem dở - giờ về hẳn màn hình
                // chính, đúng cảm giác "xoá hết" của launcher điện thoại thật).
                tabs.clear()
                Toast.makeText(context, "Đã xoá tất cả cửa sổ", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                onClearAll()
            }
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).also { it.bottomMargin = dp(20) }
        }

        root.addView(label)
        root.addView(scroll)
        root.addView(btnClose)
        return root
    }

    private fun buildCard(tab: TabEntry, dialog: Dialog): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(0xFF1A1A1A.toInt())
                setStroke(dp(1), 0xFF333333.toInt())
            }
            elevation = dp(4).toFloat()
            clipToOutline = true
            val colSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            val rowSpec = GridLayout.spec(GridLayout.UNDEFINED)
            layoutParams = GridLayout.LayoutParams(rowSpec, colSpec).apply {
                width = 0
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            isClickable = true; isFocusable = true
            setOnClickListener {
                dialog.dismiss()
                onNavigate(tab)
            }
        }

        // Thumbnail hoặc placeholder - riêng app nội bộ hiện icon lớn thay vì ảnh chụp web
        val thumb = if (tab.isApp) {
            TextView(context).apply {
                text = tab.icon
                textSize = 48f
                gravity = Gravity.CENTER
                setBackgroundColor(0xFF111111.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(160)
                )
            }
        } else if (tab.thumbnail != null) {
            ImageView(context).apply {
                setImageBitmap(tab.thumbnail)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(160)
                )
            }
        } else {
            TextView(context).apply {
                text = "🌐"
                textSize = 36f
                gravity = Gravity.CENTER
                setBackgroundColor(0xFF111111.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(160)
                )
            }
        }

        val titleView = TextView(context).apply {
            text = tab.title.take(30)
            textSize = 11f
            setTextColor(0xFFCCCCCC.toInt())
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(8), dp(6), dp(8), dp(4))
        }
        val urlView = TextView(context).apply {
            // App nội bộ không có URL thật -> để trống, khỏi hiện "app://com.h...."
            text = if (tab.isApp) "" else tab.url.removePrefix("https://").removePrefix("http://").take(30)
            textSize = 10f
            setTextColor(0xFF888888.toInt())
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), dp(8))
        }

        // Nút X xoá tab
        val btnRemove = TextView(context).apply {
            text = "✕"
            textSize = 12f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            isClickable = true; isFocusable = true
            setOnClickListener {
                tabs.remove(tab)
                (card.parent as? ViewGroup)?.removeView(card)
            }
        }
        val topRow = FrameLayout(context).apply {
            addView(btnRemove, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ))
        }

        card.addView(thumb)
        card.addView(topRow)
        card.addView(titleView)
        card.addView(urlView)
        return card
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
