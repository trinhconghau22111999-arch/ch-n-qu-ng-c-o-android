package com.h.adblockbrowser

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Loại 1 mục trên trang chủ: mở thẳng 1 trang web (WEB) hay mở 1 Activity trong app (ACTIVITY). */
enum class ShortcutType { WEB, ACTIVITY }

data class ShortcutItem(
    val key: String,
    val label: String,
    val type: ShortcutType,
    val target: String,
    val iconRes: Int
)

/** Danh sách rút gọn - CHỈ còn 3 mục theo yêu cầu: YouTube, Ẩn danh, và YouTube mở trong Ẩn danh.
 *  Toàn bộ các "app con" khác (Máy tính, Lịch, Camera, Đồng hồ, Ghi chú, Quản lý tệp, Thư viện,
 *  Xem ảnh, Phát media, Ghi âm, Cài đặt, Truy cập nhanh...) và thanh 3 nút điều hướng nổi đã bị
 *  xoá hoàn toàn khỏi app theo yêu cầu dọn dẹp. */
object ShortcutsRepository {
    val ALL: LinkedHashMap<String, ShortcutItem> = linkedMapOf(
        "youtube" to ShortcutItem(
            "youtube", "YouTube", ShortcutType.WEB, "https://www.youtube.com", R.drawable.ic_shortcut_youtube
        ),
        "incognito" to ShortcutItem(
            "incognito", "Ẩn danh", ShortcutType.ACTIVITY, "IncognitoActivity", R.drawable.ic_shortcut_incognito
        ),
        "youtube_incognito" to ShortcutItem(
            "youtube_incognito", "YouTube + Ẩn danh", ShortcutType.ACTIVITY, "IncognitoActivity:https://www.youtube.com",
            R.drawable.ic_shortcut_youtube
        )
    )
}

/** Trang chủ rút gọn: chỉ hiện đúng 3 icon cố định (không phân trang, không kéo-thả, không menu
 *  tuỳ chỉnh) - thay cho bản cũ nhiều trang/kéo-thả/Cài đặt đã bị xoá. */
class HomeScreenManager(
    private val context: Context,
    private val onOpenShortcut: (ShortcutItem) -> Unit
) {
    fun build(): FrameLayout {
        val root = FrameLayout(context)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        }

        listOf("youtube", "incognito", "youtube_incognito").forEach { key ->
            ShortcutsRepository.ALL[key]?.let { item ->
                row.addView(buildIconCell(item), LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.leftMargin = dp(20); it.rightMargin = dp(20) })
            }
        }

        root.addView(row)
        return root
    }

    private fun buildIconCell(item: ShortcutItem): View {
        val cell = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(10), dp(6), dp(10))
            isClickable = true; isFocusable = true
            background = android.util.TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }

        val icon = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            setImageResource(item.iconRes)
        }
        val label = TextView(context).apply {
            text = item.label
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(2), dp(6), dp(2), 0)
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }

        cell.addView(icon)
        cell.addView(label)
        cell.setOnClickListener { onOpenShortcut(item) }
        return cell
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
