package com.h.adblockbrowser

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONArray
import org.json.JSONObject

// ---------- Lưu trữ icon trên màn hình chính ----------

data class HomeIcon(val key: String, val page: Int, val position: Int)

object HomeScreenPrefs {
    private const val PREFS = "home_screen_prefs"
    private const val KEY_ICONS = "icons"
    private const val KEY_PAGES = "pages"

    fun load(ctx: Context): Pair<Int, MutableList<HomeIcon>> {
        val prefs = ctx.getSharedPreferences(PREFS, 0)
        val pages = prefs.getInt(KEY_PAGES, 1)
        val json = prefs.getString(KEY_ICONS, null) ?: return Pair(pages, mutableListOf())
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<HomeIcon>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(HomeIcon(obj.getString("key"), obj.getInt("page"), obj.getInt("pos")))
            }
            Pair(pages, list)
        } catch (e: Exception) { Pair(1, mutableListOf()) }
    }

    fun save(ctx: Context, pages: Int, icons: List<HomeIcon>) {
        val arr = JSONArray()
        icons.forEach { arr.put(JSONObject().put("key", it.key).put("page", it.page).put("pos", it.position)) }
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putInt(KEY_PAGES, pages)
            .putString(KEY_ICONS, arr.toString())
            .apply()
    }
}

// ---------- HomeScreenManager ----------

class HomeScreenManager(
    private val context: Context,
    private val onOpenShortcut: (ShortcutItem) -> Unit,
    private val onOpenSettings: () -> Unit = {}
) {
    companion object {
        const val COLS = 4
        const val ROWS = 5
        const val PAGE_SIZE = COLS * ROWS
    }

    private var pageCount = 1
    private val icons = mutableListOf<HomeIcon>()

    private lateinit var viewPager: ViewPager2
    private lateinit var dotContainer: LinearLayout
    private lateinit var pagerAdapter: HomePagerAdapter

    fun build(): FrameLayout {
        val (savedPages, savedIcons) = HomeScreenPrefs.load(context)
        pageCount = savedPages
        icons.clear(); icons.addAll(savedIcons)

        viewPager = ViewPager2(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            // Đặt offscreenPageLimit để các trang không bị destroy khi vuốt
            offscreenPageLimit = 3
        }

        dotContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).also { it.bottomMargin = dp(14) }
        }

        val root = FrameLayout(context)
        root.addView(viewPager)
        root.addView(dotContainer)

        pagerAdapter = HomePagerAdapter()
        viewPager.adapter = pagerAdapter
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = refreshDots(position)
        })
        refreshDots(0)
        return root
    }

    fun addIcon(key: String) {
        val currentPage = viewPager.currentItem
        val countOnPage = icons.count { it.page == currentPage }
        if (countOnPage >= PAGE_SIZE) {
            // Trang hiện tại đầy → tạo trang mới
            pageCount++
            val newPage = pageCount - 1
            icons.add(HomeIcon(key, newPage, 0))
            pagerAdapter.notifyItemInserted(newPage)
            pagerAdapter.notifyItemChanged(newPage)
            refreshDots(newPage)
            viewPager.currentItem = newPage
        } else {
            val pos = (icons.filter { it.page == currentPage }.maxOfOrNull { it.position } ?: -1) + 1
            icons.add(HomeIcon(key, currentPage, pos))
            pagerAdapter.notifyItemChanged(currentPage)
        }
        save()
    }

    fun addPage() {
        pageCount++
        pagerAdapter.notifyItemInserted(pageCount - 1)
        refreshDots(viewPager.currentItem)
        viewPager.currentItem = pageCount - 1
        save()
    }

    private fun save() = HomeScreenPrefs.save(context, pageCount, icons)

    private fun refreshDots(selected: Int) {
        dotContainer.removeAllViews()
        for (i in 0 until pageCount) {
            val dot = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).also {
                    it.setMargins(dp(4), 0, dp(4), 0)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == selected) 0xFFC724FF.toInt() else 0x66FFFFFF.toInt())
                }
            }
            dotContainer.addView(dot)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    // ---------- PagerAdapter dùng RecyclerView.Adapter (ViewPager2 yêu cầu) ----------

    inner class HomePagerAdapter : RecyclerView.Adapter<HomePagerAdapter.PageVH>() {

        inner class PageVH(val grid: GridLayout) : RecyclerView.ViewHolder(grid)

        override fun getItemCount() = pageCount

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val grid = GridLayout(context).apply {
                columnCount = COLS
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setPadding(dp(4), dp(40), dp(4), dp(48))
            }
            return PageVH(grid)
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            holder.grid.removeAllViews()

            val pageIcons = icons.filter { it.page == position }.sortedBy { it.position }
            pageIcons.forEach { hi ->
                val item = ShortcutsRepository.ALL[hi.key] ?: return@forEach
                holder.grid.addView(buildIconCell(item, position, hi.position))
            }

            // Long-press vào vùng trống → menu tùy chọn
            holder.grid.setOnLongClickListener { showPageOptions(); true }
        }
    }

    // ---------- Cell icon ----------

    private fun buildIconCell(item: ShortcutItem, pageIndex: Int, pos: Int): View {
        val cell = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            val colSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            val rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            layoutParams = GridLayout.LayoutParams(rowSpec, colSpec).apply {
                width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            isClickable = true; isFocusable = true
            background = android.util.TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }

        val icon = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            setImageResource(item.iconRes)
        }
        val label = TextView(context).apply {
            text = item.label
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }

        cell.addView(icon)
        cell.addView(label)

        cell.setOnClickListener { onOpenShortcut(item) }
        cell.setOnLongClickListener { showIconOptions(item, pageIndex, pos); true }

        return cell
    }

    // ---------- Context menus ----------

    private fun showIconOptions(item: ShortcutItem, pageIndex: Int, pos: Int) {
        AlertDialog.Builder(context)
            .setTitle(item.label)
            .setItems(arrayOf("🗑  Xoá khỏi màn hình chính")) { _, _ ->
                icons.removeAll { it.key == item.key && it.page == pageIndex && it.position == pos }
                pagerAdapter.notifyItemChanged(pageIndex)
                save()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun showPageOptions() {
        AlertDialog.Builder(context)
            .setTitle("Tuỳ chọn màn hình chính")
            .setItems(arrayOf("➕  Thêm màn hình mới", "⚙  Cài đặt")) { _, which ->
                when (which) {
                    0 -> addPage()
                    1 -> onOpenSettings()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
