package com.h.adblockbrowser

import android.app.AlertDialog
import android.content.ClipData
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.DragEvent
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONArray
import org.json.JSONObject

// ---------- Lưu trữ icon trên màn hình chính ----------

data class HomeIcon(val key: String, val page: Int, val position: Int)

// Dữ liệu tạm mang theo trong lúc kéo-thả 1 icon (kéo để đổi vị trí hoặc kéo vào thùng rác để xoá)
private data class DragPayload(val key: String, val page: Int, val position: Int)

object HomeScreenPrefs {
    private const val PREFS = "home_screen_prefs"
    private const val KEY_ICONS = "icons"
    private const val KEY_PAGES = "pages"

    fun load(ctx: Context): Pair<Int, MutableList<HomeIcon>> {
        val prefs = ctx.getSharedPreferences(PREFS, 0)
        val pages = prefs.getInt(KEY_PAGES, 1)
        val json = prefs.getString(KEY_ICONS, null) ?: return Pair(pages, mutableListOf())
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<HomeIcon>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(HomeIcon(obj.getString("key"), obj.getInt("page"), obj.getInt("pos")))
            }
            Pair(pages, list)
        } catch (e: Exception) { Pair(1, mutableListOf()) }
    }

    fun save(ctx: Context, pages: Int, icons: List<HomeIcon>) {
        val arr = JSONArray()
        icons.forEach { arr.put(JSONObject().put("key", it.key).put("page", it.page).put("pos", it.position)) }
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putInt(KEY_PAGES, pages)
            .putString(KEY_ICONS, arr.toString())
            .apply()
    }
}

// ---------- HomeScreenManager ----------

class HomeScreenManager(
    private val context: Context,
    private val onOpenShortcut: (ShortcutItem) -> Unit,
    private val onOpenSettings: () -> Unit = {}
) {
    companion object {
        const val COLS = 4
        const val ROWS = 5
        const val PAGE_SIZE = COLS * ROWS
    }

    private var pageCount = 1
    private val icons = mutableListOf<HomeIcon>()

    private lateinit var viewPager: ViewPager2
    private lateinit var dotContainer: LinearLayout
    private lateinit var pagerAdapter: HomePagerAdapter
    private lateinit var trashZone: LinearLayout
    private lateinit var trashLabel: TextView

    private lateinit var tvClockTime: TextView
    private lateinit var tvClockDate: TextView
    private val clockHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockWidget()
            clockHandler.postDelayed(this, 1000)
        }
    }

    private fun updateClockWidget() {
        val now = java.util.Calendar.getInstance()
        val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale("vi", "VN"))
        // "Thứ Ba, 4 tháng 8 năm 2026" - thứ/ngày/tháng/năm xuống dòng dưới giờ:phút
        val dateFmt = java.text.SimpleDateFormat("EEEE, d 'tháng' M 'năm' yyyy", java.util.Locale("vi", "VN"))
        tvClockTime.text = timeFmt.format(now.time)
        tvClockDate.text = dateFmt.format(now.time).replaceFirstChar { it.uppercase() }
    }

    fun build(): FrameLayout {
        val (savedPages, savedIcons) = HomeScreenPrefs.load(context)
        pageCount = savedPages
        icons.clear(); icons.addAll(savedIcons)

        viewPager = ViewPager2(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            // Đặt offscreenPageLimit để các trang không bị destroy khi vuốt
            offscreenPageLimit = 3
        }

        dotContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).also { it.bottomMargin = dp(14) }
        }

        // ---------- Widget đồng hồ + lịch, dán ở đầu trang chủ (giống màn hình chính máy thật):
        // dòng 1 = giờ:phút cỡ lớn, dòng 2 = thứ, ngày tháng năm ----------
        val clockWidget = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).also { it.topMargin = dp(48) }
        }
        tvClockTime = TextView(context).apply {
            textSize = 46f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            android.graphics.Typeface.DEFAULT_BOLD.also { typeface = it }
        }
        tvClockDate = TextView(context).apply {
            textSize = 14f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        clockWidget.addView(tvClockTime)
        clockWidget.addView(tvClockDate)
        updateClockWidget()

        // ---------- Vùng "thùng rác" hiện lên khi đang kéo 1 icon - thả icon vào đây để xoá
        // khỏi màn hình chính. Ẩn mặc định, chỉ hiện trong lúc kéo-thả. ----------
        trashLabel = TextView(context).apply {
            text = "🗑  Kéo vào đây để xoá"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        trashZone = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(14), dp(22), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(0xCC000000.toInt())
            }
            visibility = View.GONE
            addView(trashLabel)
            setOnDragListener { _, event ->
                when (event.action) {
                    DragEvent.ACTION_DRAG_ENTERED -> {
                        (background as GradientDrawable).setColor(0xFFFF3B30.toInt())
                        trashLabel.text = "🗑  Thả ra để xoá"
                        true
                    }
                    DragEvent.ACTION_DRAG_EXITED -> {
                        (background as GradientDrawable).setColor(0xCC000000.toInt())
                        trashLabel.text = "🗑  Kéo vào đây để xoá"
                        true
                    }
                    DragEvent.ACTION_DROP -> {
                        val payload = event.localState as? DragPayload
                        if (payload != null) {
                            icons.removeAll { it.key == payload.key && it.page == payload.page && it.position == payload.position }
                            reindexPage(payload.page)
                            save()
                            pagerAdapter.notifyDataSetChanged()
                            Toast.makeText(context, "Đã xoá khỏi màn hình chính", Toast.LENGTH_SHORT).show()
                        }
                        true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> {
                        visibility = View.GONE
                        (background as GradientDrawable).setColor(0xCC000000.toInt())
                        trashLabel.text = "🗑  Kéo vào đây để xoá"
                        true
                    }
                    else -> true
                }
            }
        }
        val trashParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).also { it.bottomMargin = dp(46) }

        val root = FrameLayout(context)
        root.addView(viewPager)
        root.addView(clockWidget)
        root.addView(dotContainer)
        root.addView(trashZone, trashParams)

        clockHandler.removeCallbacks(clockRunnable)
        clockHandler.post(clockRunnable)

        pagerAdapter = HomePagerAdapter()
        viewPager.adapter = pagerAdapter
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = refreshDots(position)
        })
        refreshDots(0)
        return root
    }

    fun addIcon(key: String) {
        val currentPage = viewPager.currentItem
        val countOnPage = icons.count { it.page == currentPage }
        if (countOnPage >= PAGE_SIZE) {
            pageCount++
            val newPage = pageCount - 1
            icons.add(HomeIcon(key, newPage, 0))
            save()
            pagerAdapter.notifyDataSetChanged()
            refreshDots(newPage)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                viewPager.currentItem = newPage
            }, 100)
        } else {
            val pos = (icons.filter { it.page == currentPage }.maxOfOrNull { it.position } ?: -1) + 1
            icons.add(HomeIcon(key, currentPage, pos))
            save()
            pagerAdapter.notifyDataSetChanged()
        }
    }

    fun addPage() {
        pageCount++
        save()
        pagerAdapter.notifyDataSetChanged()
        refreshDots(pageCount - 1)
        // Delay nhỏ để adapter kịp update rồi mới scroll
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            viewPager.currentItem = pageCount - 1
        }, 100)
    }

    private fun save() = HomeScreenPrefs.save(context, pageCount, icons)

    // Dồn lại số thứ tự các icon trong 1 trang cho liền mạch (0,1,2...), tránh để lỗ trống
    // sau khi xoá hoặc chuyển 1 icon đi trang khác.
    private fun reindexPage(page: Int) {
        val sorted = icons.filter { it.page == page }.sortedBy { it.position }.toMutableList()
        icons.removeAll { it.page == page }
        sorted.forEachIndexed { idx, hi -> icons.add(hi.copy(position = idx)) }
    }

    // Di chuyển 1 icon (đang kéo) tới vị trí targetPos trên trang targetPage. Nếu trang đích
    // đã đầy (khác trang nguồn) thì huỷ thao tác và báo cho người dùng biết.
    private fun moveIconTo(payload: DragPayload, targetPos: Int, targetPage: Int) {
        val oldIndex = icons.indexOfFirst {
            it.key == payload.key && it.page == payload.page && it.position == payload.position
        }
        if (oldIndex < 0) return
        val destCountExcludingSelf = icons.count { it.page == targetPage } - (if (payload.page == targetPage) 1 else 0)
        if (payload.page != targetPage && destCountExcludingSelf >= PAGE_SIZE) {
            Toast.makeText(context, "Trang này đã đầy", Toast.LENGTH_SHORT).show()
            return
        }
        val removed = icons.removeAt(oldIndex)
        val destSorted = icons.filter { it.page == targetPage }.sortedBy { it.position }.toMutableList()
        val insertAt = targetPos.coerceIn(0, destSorted.size)
        destSorted.add(insertAt, removed)
        icons.removeAll { it.page == targetPage }
        destSorted.forEachIndexed { idx, hi -> icons.add(hi.copy(position = idx, page = targetPage)) }
        if (payload.page != targetPage) reindexPage(payload.page)
        save()
        pagerAdapter.notifyDataSetChanged()
    }

    private fun refreshDots(selected: Int) {
        dotContainer.removeAllViews()
        for (i in 0 until pageCount) {
            val dot = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).also {
                    it.setMargins(dp(4), 0, dp(4), 0)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == selected) 0xFFC724FF.toInt() else 0x66FFFFFF.toInt())
                }
            }
            dotContainer.addView(dot)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    // ---------- PagerAdapter dùng RecyclerView.Adapter (ViewPager2 yêu cầu) ----------

    inner class HomePagerAdapter : RecyclerView.Adapter<HomePagerAdapter.PageVH>() {

        inner class PageVH(val grid: GridLayout) : RecyclerView.ViewHolder(grid)

        override fun getItemCount() = pageCount

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val grid = GridLayout(context).apply {
                columnCount = COLS
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setPadding(dp(4), dp(140), dp(4), dp(48))
            }
            return PageVH(grid)
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            holder.grid.removeAllViews()

            val pageIcons = icons.filter { it.page == position }.sortedBy { it.position }
            pageIcons.forEach { hi ->
                val item = ShortcutsRepository.ALL[hi.key] ?: return@forEach
                holder.grid.addView(buildIconCell(item, position, hi.position))
            }

            // Long-press vào vùng trống → menu tùy chọn
            holder.grid.setOnLongClickListener { showPageOptions(); true }

            // Nhận icon được kéo-thả vào: xác định ô lưới gần điểm thả nhất rồi chuyển icon
            // tới đúng vị trí đó, các icon khác tự dồn chỗ.
            holder.grid.setOnDragListener { v, event ->
                val grid = v as GridLayout
                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED -> event.localState is DragPayload
                    DragEvent.ACTION_DROP -> {
                        val payload = event.localState as? DragPayload ?: return@setOnDragListener false
                        val usableW = grid.width - grid.paddingLeft - grid.paddingRight
                        val usableH = grid.height - grid.paddingTop - grid.paddingBottom
                        if (usableW <= 0 || usableH <= 0) return@setOnDragListener false
                        val cellW = usableW / COLS
                        val cellH = usableH / ROWS
                        val col = (((event.x - grid.paddingLeft) / cellW).toInt()).coerceIn(0, COLS - 1)
                        val row = (((event.y - grid.paddingTop) / cellH).toInt()).coerceIn(0, ROWS - 1)
                        moveIconTo(payload, row * COLS + col, position)
                        true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> {
                        trashZone.visibility = View.GONE
                        true
                    }
                    else -> true
                }
            }
        }
    }

    // ---------- Cell icon ----------

    private fun buildIconCell(item: ShortcutItem, pageIndex: Int, pos: Int): View {
        val cell = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            val colSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            val rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
            layoutParams = GridLayout.LayoutParams(rowSpec, colSpec).apply {
                width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            isClickable = true; isFocusable = true
            background = android.util.TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }

        val icon = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            setImageResource(item.iconRes)
        }
        val label = TextView(context).apply {
            text = item.label
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }

        cell.addView(icon)
        cell.addView(label)

        cell.setOnClickListener { onOpenShortcut(item) }
        // Giữ (long-press) để bắt đầu kéo icon: kéo thả vào ô khác để đổi vị trí, kéo vào
        // thùng rác hiện ra bên dưới để xoá khỏi màn hình chính.
        cell.setOnLongClickListener {
            cell.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val payload = DragPayload(item.key, pageIndex, pos)
            val clip = ClipData.newPlainText("home_icon", item.key)
            val shadow = View.DragShadowBuilder(cell)
            trashZone.visibility = View.VISIBLE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cell.startDragAndDrop(clip, shadow, payload, 0)
            } else {
                @Suppress("DEPRECATION")
                cell.startDrag(clip, shadow, payload, 0)
            }
            true
        }

        return cell
    }

    // ---------- Context menus ----------

    private fun showPageOptions() {
        AlertDialog.Builder(context)
            .setTitle("Tuỳ chọn màn hình chính")
            .setItems(arrayOf("➕  Thêm màn hình mới", "⚙  Cài đặt")) { _, which ->
                when (which) {
                    0 -> addPage()
                    1 -> onOpenSettings()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
