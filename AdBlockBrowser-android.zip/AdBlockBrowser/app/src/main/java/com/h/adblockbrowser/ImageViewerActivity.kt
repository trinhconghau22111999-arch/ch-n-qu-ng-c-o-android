package com.h.adblockbrowser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.concurrent.Executors

/** Trình xem ảnh ĐƠN GIẢN NHẸ NHẤT - vuốt trái/phải giữa các ảnh (ViewPager2), không dùng thư
 *  viện load ảnh ngoài (Glide/Coil...), tự giải mã bitmap có giảm kích thước (inSampleSize) để
 *  không tốn bộ nhớ, đúng tinh thần "trình xem ảnh gốc" tối giản của Android. */
class ImageViewerActivity : AppCompatActivity() {

    private val bgExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uris = intent.getStringArrayListExtra(EXTRA_URIS) ?: arrayListOf()
        val startIndex = intent.getIntExtra(EXTRA_START_INDEX, 0)
        if (uris.isEmpty()) { finish(); return }

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        val pager = ViewPager2(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            adapter = ImagePagerAdapter(uris, bgExecutor)
            setCurrentItem(startIndex, false)
        }
        root.addView(pager)

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), statusBarHeight() + dp(4), dp(8), dp(4))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0x99000000.toInt()) }
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
            )
        }
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnShare = TextView(this).apply {
            text = "↗  Chia sẻ"; textSize = 15f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0x88333333.toInt()) }
            isClickable = true
            setOnClickListener { shareCurrent(uris, pager.currentItem) }
        }
        val btnDelete = TextView(this).apply {
            text = "🗑  Xoá"; textSize = 15f; setTextColor(0xFFFF6B6B.toInt())
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0x88330000.toInt()) }
            isClickable = true
            setOnClickListener { confirmDeleteCurrent(uris, pager.currentItem) }
        }
        topBar.addView(spacer)
        topBar.addView(btnShare)
        topBar.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(8), 1) })
        topBar.addView(btnDelete)
        root.addView(topBar)

        setContentView(root)
    }

    private fun shareCurrent(uris: List<String>, index: Int) {
        val uri = uris.getOrNull(index)?.let { Uri.parse(it) } ?: return
        try {
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri) ?: "image/*"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Chia sẻ"))
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "Không chia sẻ được tệp này", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDeleteCurrent(uris: List<String>, index: Int) {
        val uri = uris.getOrNull(index)?.let { Uri.parse(it) } ?: return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Xoá ảnh này?")
            .setPositiveButton("Xoá") { _, _ ->
                try {
                    contentResolver.delete(uri, null, null)
                    android.widget.Toast.makeText(this, "Đã xoá", android.widget.Toast.LENGTH_SHORT).show()
                    finish()
                } catch (e: Exception) {
                    android.widget.Toast.makeText(this, "Không xoá được (thiếu quyền)", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        bgExecutor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URIS = "extra_uris"
        const val EXTRA_START_INDEX = "extra_start_index"
    }
}

private class ImagePagerAdapter(
    private val uris: List<String>,
    private val executor: java.util.concurrent.ExecutorService
) : RecyclerView.Adapter<ImagePagerAdapter.PageVH>() {

    class PageVH(val image: ImageView) : RecyclerView.ViewHolder(image)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val image = ImageView(parent.context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        return PageVH(image)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        val uriStr = uris[position]
        holder.image.setImageDrawable(null)
        val ctx = holder.image.context
        val screenW = ctx.resources.displayMetrics.widthPixels
        val screenH = ctx.resources.displayMetrics.heightPixels
        executor.execute {
            val bmp = decodeSampled(ctx, Uri.parse(uriStr), screenW, screenH)
            (ctx as? androidx.appcompat.app.AppCompatActivity)?.runOnUiThread {
                if (holder.bindingAdapterPosition == position) holder.image.setImageBitmap(bmp)
            }
        }
    }

    private fun decodeSampled(ctx: android.content.Context, uri: Uri, reqW: Int, reqH: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            var w = opts.outWidth; var h = opts.outHeight
            while (w / (sample * 2) >= reqW && h / (sample * 2) >= reqH) sample *= 2
            val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts2) }
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = uris.size
}
