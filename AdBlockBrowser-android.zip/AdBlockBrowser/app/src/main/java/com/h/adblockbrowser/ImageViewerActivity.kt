package com.h.adblockbrowser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.concurrent.Executors

/** Trình xem ảnh ĐƠN GIẢN NHẸ NHẤT - vuốt trái/phải giữa các ảnh (ViewPager2), không dùng thư
 *  viện load ảnh ngoài (Glide/Coil...), tự giải mã bitmap có giảm kích thước (inSampleSize) để
 *  không tốn bộ nhớ, đúng tinh thần "trình xem ảnh gốc" tối giản của Android. */
class ImageViewerActivity : AppCompatActivity() {

    private val bgExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uris = intent.getStringArrayListExtra(EXTRA_URIS) ?: arrayListOf()
        val startIndex = intent.getIntExtra(EXTRA_START_INDEX, 0)
        if (uris.isEmpty()) { finish(); return }

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        val pager = ViewPager2(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            adapter = ImagePagerAdapter(uris, bgExecutor)
            setCurrentItem(startIndex, false)
        }
        root.addView(pager)

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(36), dp(16), dp(8))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
            )
        }
        topBar.addView(buildBackArrow())
        root.addView(topBar)

        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        bgExecutor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URIS = "extra_uris"
        const val EXTRA_START_INDEX = "extra_start_index"
    }
}

private class ImagePagerAdapter(
    private val uris: List<String>,
    private val executor: java.util.concurrent.ExecutorService
) : RecyclerView.Adapter<ImagePagerAdapter.PageVH>() {

    class PageVH(val image: ImageView) : RecyclerView.ViewHolder(image)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val image = ImageView(parent.context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        return PageVH(image)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        val uriStr = uris[position]
        holder.image.setImageDrawable(null)
        val ctx = holder.image.context
        val screenW = ctx.resources.displayMetrics.widthPixels
        val screenH = ctx.resources.displayMetrics.heightPixels
        executor.execute {
            val bmp = decodeSampled(ctx, Uri.parse(uriStr), screenW, screenH)
            (ctx as? androidx.appcompat.app.AppCompatActivity)?.runOnUiThread {
                if (holder.bindingAdapterPosition == position) holder.image.setImageBitmap(bmp)
            }
        }
    }

    private fun decodeSampled(ctx: android.content.Context, uri: Uri, reqW: Int, reqH: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            var w = opts.outWidth; var h = opts.outHeight
            while (w / (sample * 2) >= reqW && h / (sample * 2) >= reqH) sample *= 2
            val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts2) }
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = uris.size
}
