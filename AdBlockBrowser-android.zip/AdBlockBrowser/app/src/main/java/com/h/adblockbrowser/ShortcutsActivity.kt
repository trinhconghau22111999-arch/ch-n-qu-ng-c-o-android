package com.h.adblockbrowser

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

enum class ShortcutType { WEB, ACTIVITY }

data class ShortcutItem(val key: String, val label: String, val type: ShortcutType, val target: String)

object ShortcutsRepository {

    // Danh sách mặc định (key -> nhãn hiển thị, loại, đích đến)
    val ALL: LinkedHashMap<String, ShortcutItem> = linkedMapOf(
        "google" to ShortcutItem("google", "Google", ShortcutType.WEB, "https://www.google.com"),
        "youtube" to ShortcutItem("youtube", "YouTube", ShortcutType.WEB, "https://www.youtube.com"),
        "facebook" to ShortcutItem("facebook", "Facebook", ShortcutType.WEB, "https://www.facebook.com"),
        "zalo" to ShortcutItem("zalo", "Zalo Web", ShortcutType.WEB, "https://chat.zalo.me"),
        "mail" to ShortcutItem("mail", "Mail", ShortcutType.WEB, "https://mail.google.com"),
        "meet" to ShortcutItem("meet", "Meet", ShortcutType.WEB, "https://meet.google.com"),
        "zoom" to ShortcutItem("zoom", "Zoom", ShortcutType.WEB, "https://zoom.us"),
        "drive" to ShortcutItem("drive", "Drive", ShortcutType.WEB, "https://drive.google.com"),
        "maps" to ShortcutItem("maps", "Google Maps", ShortcutType.WEB, "https://www.google.com/maps"),
        "notes" to ShortcutItem("notes", "Ghi chú", ShortcutType.WEB, "https://keep.google.com"),
        "shopee" to ShortcutItem("shopee", "Shopee", ShortcutType.WEB, "https://shopee.vn"),
        "lazada" to ShortcutItem("lazada", "Lazada", ShortcutType.WEB, "https://www.lazada.vn"),
        "docs" to ShortcutItem("docs", "Soạn thảo văn bản", ShortcutType.WEB, "https://docs.google.com/document/create"),
        "camera" to ShortcutItem("camera", "Trang Camera", ShortcutType.ACTIVITY, "CameraActivity"),
        "gallery" to ShortcutItem("gallery", "Bộ sưu tập", ShortcutType.ACTIVITY, "GalleryActivity"),
        "files" to ShortcutItem("files", "Trang Tệp", ShortcutType.ACTIVITY, "FilesActivity"),
        "clock" to ShortcutItem("clock", "Đồng hồ", ShortcutType.ACTIVITY, "ClockActivity"),
        "calendar" to ShortcutItem("calendar", "Lịch", ShortcutType.ACTIVITY, "CalendarActivity"),
        "calculator" to ShortcutItem("calculator", "Máy tính", ShortcutType.ACTIVITY, "CalculatorActivity"),
        "recorder" to ShortcutItem("recorder", "Ghi âm", ShortcutType.ACTIVITY, "RecorderActivity")
    )

    private const val PREFS = "shortcuts_prefs"
    private const val KEY_ORDER = "order"

    fun loadOrder(prefs: SharedPreferences): List<ShortcutItem> {
        val savedCsv = prefs.getString(KEY_ORDER, null)
        val savedKeys = savedCsv?.split(",")?.filter { it.isNotBlank() } ?: emptyList()

        val ordered = ArrayList<ShortcutItem>()
        for (k in savedKeys) {
            ALL[k]?.let { ordered.add(it) }
        }
        // thêm các mục mới (nếu có cập nhật sau này) chưa có trong thứ tự đã lưu
        for (item in ALL.values) {
            if (ordered.none { it.key == item.key }) ordered.add(item)
        }
        return ordered
    }

    fun saveOrder(prefs: SharedPreferences, items: List<ShortcutItem>) {
        prefs.edit().putString(KEY_ORDER, items.joinToString(",") { it.key }).apply()
    }

    fun prefs(activity: AppCompatActivity): SharedPreferences =
        activity.getSharedPreferences(PREFS, 0)
}

class ShortcutsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ShortcutAdapter
    private lateinit var items: MutableList<ShortcutItem>
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = ShortcutsRepository.prefs(this)
        items = ShortcutsRepository.loadOrder(prefs).toMutableList()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 40, 24, 24)
        }

        val title = TextView(this).apply {
            text = "Truy cập nhanh — giữ ☰ để kéo đổi vị trí"
            textSize = 16f
            setTextColor(0xFFC724FF.toInt())
            setPadding(0, 0, 0, 16)
        }

        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ShortcutsActivity)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(title)
        root.addView(recyclerView)
        setContentView(root)

        adapter = ShortcutAdapter(items,
            onOpen = { item -> openShortcut(item) },
            onStartDrag = { holder -> touchHelper.startDrag(holder) }
        )
        recyclerView.adapter = adapter

        touchHelper.attachToRecyclerView(recyclerView)
    }

    private val touchHelper by lazy {
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.adapterPosition
                val to = target.adapterPosition
                if (from < 0 || to < 0) return false
                val moved = items.removeAt(from)
                items.add(to, moved)
                adapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                ShortcutsRepository.saveOrder(prefs, items)
            }
        })
    }

    private fun openShortcut(item: ShortcutItem) {
        val result = Intent()
        result.putExtra("shortcut_key", item.key)
        setResult(RESULT_OK, result)
        finish()
    }
}

class ShortcutAdapter(
    private val items: MutableList<ShortcutItem>,
    private val onOpen: (ShortcutItem) -> Unit,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<ShortcutAdapter.VH>() {

    inner class VH(val row: LinearLayout, val label: TextView, val handle: TextView) :
        RecyclerView.ViewHolder(row)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val row = LinearLayout(parent.context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(20, 28, 20, 28)
            setBackgroundColor(0xFF0D0D0D.toInt())
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 4, 0, 4) }
        }
        val label = TextView(parent.context).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val handle = TextView(parent.context).apply {
            text = "☰"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(24, 0, 8, 0)
        }
        row.addView(label)
        row.addView(handle)
        return VH(row, label, handle)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.label.text = item.label
        holder.row.setOnClickListener { onOpen(item) }

        @Suppress("ClickableViewAccessibility")
        holder.handle.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                onStartDrag(holder)
            }
            false
        }
    }

    override fun getItemCount(): Int = items.size
}
