package com.h.adblockbrowser

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView

enum class ShortcutType { WEB, ACTIVITY }

data class ShortcutItem(
    val key: String,
    val label: String,
    val type: ShortcutType,
    val target: String,
    val iconRes: Int
)

object ShortcutsRepository {

    // Danh sách mặc định (key -> nhãn hiển thị, loại, đích đến, icon riêng - xem
    // res/drawable/ic_shortcut_*.xml, mỗi icon tự vẽ dạng vector, không dùng logo thật)
    val ALL: LinkedHashMap<String, ShortcutItem> = linkedMapOf(
        "google" to ShortcutItem("google", "Google", ShortcutType.WEB, "https://www.google.com", R.drawable.ic_shortcut_google),
        "youtube" to ShortcutItem("youtube", "YouTube", ShortcutType.WEB, "https://www.youtube.com", R.drawable.ic_shortcut_youtube),
        "facebook" to ShortcutItem("facebook", "Facebook", ShortcutType.WEB, "https://www.facebook.com", R.drawable.ic_shortcut_facebook),
        "zalo" to ShortcutItem("zalo", "Zalo Web", ShortcutType.WEB, "https://chat.zalo.me", R.drawable.ic_shortcut_zalo),
        "mail" to ShortcutItem("mail", "Mail", ShortcutType.WEB, "https://mail.google.com", R.drawable.ic_shortcut_mail),
        "drive" to ShortcutItem("drive", "Drive", ShortcutType.WEB, "https://drive.google.com", R.drawable.ic_shortcut_drive),
        "maps" to ShortcutItem("maps", "Google Maps", ShortcutType.WEB, "https://www.google.com/maps", R.drawable.ic_shortcut_maps),
        "notes" to ShortcutItem("notes", "Ghi chú", ShortcutType.ACTIVITY, "NotesListActivity", R.drawable.ic_shortcut_notes),
        "shopee" to ShortcutItem("shopee", "Shopee", ShortcutType.WEB, "https://shopee.vn", R.drawable.ic_shortcut_shopee),
        "lazada" to ShortcutItem("lazada", "Lazada", ShortcutType.WEB, "https://www.lazada.vn", R.drawable.ic_shortcut_lazada),
        "docs" to ShortcutItem("docs", "Soạn thảo văn bản", ShortcutType.ACTIVITY, "DocsListActivity", R.drawable.ic_shortcut_docs),
        "camera" to ShortcutItem("camera", "Trang Camera", ShortcutType.ACTIVITY, "CameraActivity", R.drawable.ic_shortcut_camera),
        "gallery" to ShortcutItem("gallery", "Bộ sưu tập", ShortcutType.ACTIVITY, "GalleryActivity", R.drawable.ic_shortcut_gallery),
        "files" to ShortcutItem("files", "Trang Tệp", ShortcutType.ACTIVITY, "FilesActivity", R.drawable.ic_shortcut_files),
        "clock" to ShortcutItem("clock", "Đồng hồ", ShortcutType.ACTIVITY, "ClockActivity", R.drawable.ic_shortcut_clock),
        "calendar" to ShortcutItem("calendar", "Lịch", ShortcutType.ACTIVITY, "CalendarActivity", R.drawable.ic_shortcut_calendar),
        "calculator" to ShortcutItem("calculator", "Máy tính", ShortcutType.ACTIVITY, "CalculatorActivity", R.drawable.ic_shortcut_calculator),
        "recorder" to ShortcutItem("recorder", "Ghi âm", ShortcutType.ACTIVITY, "RecorderActivity", R.drawable.ic_shortcut_recorder),
        "incognito" to ShortcutItem("incognito", "Ẩn danh", ShortcutType.ACTIVITY, "IncognitoActivity", R.drawable.ic_shortcut_incognito)
    )

    private const val PREFS = "shortcuts_prefs"
    private const val KEY_ORDER = "order"

    fun loadOrder(prefs: SharedPreferences): List<ShortcutItem> {
        val savedCsv = prefs.getString(KEY_ORDER, null)
        val savedKeys = savedCsv?.split(",")?.filter { it.isNotBlank() } ?: emptyList()

        val ordered = ArrayList<ShortcutItem>()
        for (k in savedKeys) {
            ALL[k]?.let { ordered.add(it) }
        }
        // thêm các mục mới (nếu có cập nhật sau này) chưa có trong thứ tự đã lưu
        for (item in ALL.values) {
            if (ordered.none { it.key == item.key }) ordered.add(item)
        }
        return ordered
    }

    fun saveOrder(prefs: SharedPreferences, items: List<ShortcutItem>) {
        prefs.edit().putString(KEY_ORDER, items.joinToString(",") { it.key }).apply()
    }

    fun prefs(activity: AppCompatActivity): SharedPreferences =
        activity.getSharedPreferences(PREFS, 0)
}

/** Màn "Truy cập nhanh" - giao diện LƯỚI ICON kiểu màn hình chính điện thoại (4 cột), thay cho
 *  danh sách chữ + tay cầm kéo (☰) trước đây. Giữ NGÓN TAY LÊN 1 ICON (long-press) để kéo đổi vị
 *  trí, đúng thao tác quen thuộc của người dùng trên màn hình chính Android - không cần tay cầm
 *  kéo riêng nữa. Chạm nhanh (tap) để mở như cũ. */
class ShortcutsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ShortcutAdapter
    private lateinit var items: MutableList<ShortcutItem>
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = ShortcutsRepository.prefs(this)
        items = ShortcutsRepository.loadOrder(prefs).toMutableList()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 40, 24, 24)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 4)
        }
        titleRow.addView(buildBackArrow())

        val title = TextView(this).apply {
            text = "Truy cập nhanh — giữ 1 icon để kéo đổi vị trí"
            textSize = 14f
            setTextColor(0xFFC724FF.toInt())
            setPadding(12, 0, 8, 16)
        }

        recyclerView = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@ShortcutsActivity, 4)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
            clipToPadding = false
            setPadding(0, 8, 0, 24)
        }

        root.addView(titleRow)
        root.addView(title)
        root.addView(recyclerView)
        setContentView(root)

        adapter = ShortcutAdapter(items, onOpen = { item -> openShortcut(item) })
        recyclerView.adapter = adapter

        touchHelper.attachToRecyclerView(recyclerView)
    }

    private val touchHelper by lazy {
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun isLongPressDragEnabled(): Boolean = true

            override fun onMove(
                rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.adapterPosition
                val to = target.adapterPosition
                if (from < 0 || to < 0) return false
                val moved = items.removeAt(from)
                items.add(to, moved)
                adapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(vh, actionState)
                // Phóng to nhẹ + làm mờ icon đang kéo, đúng cảm giác kéo icon trên màn hình chính
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                    vh?.itemView?.animate()?.scaleX(1.12f)?.scaleY(1.12f)?.alpha(0.85f)?.setDuration(120)?.start()
                }
            }

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                vh.itemView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
                ShortcutsRepository.saveOrder(prefs, items)
            }
        })
    }

    private fun openShortcut(item: ShortcutItem) {
        val result = Intent()
        result.putExtra("shortcut_key", item.key)
        setResult(RESULT_OK, result)
        finish()
    }
}

class ShortcutAdapter(
    private val items: MutableList<ShortcutItem>,
    private val onOpen: (ShortcutItem) -> Unit
) : RecyclerView.Adapter<ShortcutAdapter.VH>() {

    inner class VH(val cell: LinearLayout, val tapTarget: LinearLayout, val icon: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val density = parent.context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        // Ô NGOÀI (cell) - chiếm trọn 1 ô lưới, KHÔNG bắt sự kiện chạm trực tiếp; chỉ dùng để canh
        // giữa + làm vùng nhận diện long-press-kéo-thả (ItemTouchHelper lắng nghe trên toàn bộ
        // itemView này, đúng cảm giác "giữ đâu đó gần icon cũng kéo được" như máy thật).
        val cell = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT
            )
        }
        // Ô TRONG (tapTarget) - chỉ to bằng đúng icon + nhãn, đây mới là nơi NHẬN CHẠM để MỞ. Nhờ
        // vậy chạm vào khoảng trống giữa 2 icon (vẫn nằm trong `cell` nhưng ngoài `tapTarget`) sẽ
        // KHÔNG còn vô tình mở nhầm icon nữa - đúng lỗi "chưa bấm trúng icon mà nó vẫn ăn".
        val tapTarget = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            isClickable = true
            isFocusable = true
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x33FFFFFF), null,
                android.graphics.drawable.ShapeDrawable(android.graphics.drawable.shapes.RoundRectShape(
                    FloatArray(8) { dp(12).toFloat() }, null, null))
            )
        }
        val icon = ImageView(parent.context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        val label = TextView(parent.context).apply {
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(0, dp(6), 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        tapTarget.addView(icon)
        tapTarget.addView(label)
        cell.addView(tapTarget)
        return VH(cell, tapTarget, icon, label)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.icon.setImageResource(item.iconRes)
        holder.label.text = item.label
        holder.tapTarget.setOnClickListener { onOpen(item) }
    }

    override fun getItemCount(): Int = items.size
}
