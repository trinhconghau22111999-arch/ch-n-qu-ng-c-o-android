package com.h.adblockbrowser

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GalleryActivity : AppCompatActivity() {

    private data class MediaItem(val name: String, val uri: Uri, val mime: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 40, 24, 24)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }
        val title = TextView(this).apply {
            text = "🖼 Bộ sưu tập"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(12, 0, 0, 0)
        }
        titleRow.addView(buildBackArrow())
        titleRow.addView(title)

        val listView = ListView(this).apply {
            setBackgroundColor(0xFF0D0D0D.toInt())
        }

        root.addView(titleRow)
        root.addView(listView)
        setContentView(root)

        val items = ArrayList<MediaItem>()
        items.addAll(queryMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*", "Pictures/AdBlockBrowser"))
        items.addAll(queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*", "Movies/AdBlockBrowser"))

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { it.name })
        listView.adapter = adapter

        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Chưa có ảnh/video nào được lưu từ app."
                setTextColor(0xFF888888.toInt())
                setPadding(0, 20, 0, 0)
            }
            root.addView(empty)
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val item = items[position]
            if (item.mime.startsWith("video")) {
                // Video: mở màn phát TRONG APP, có đủ thanh trượt/play-pause/tua 5s
                // (xem MediaPlayerActivity.kt), thay vì giao cho app ngoài như trước.
                val intent = Intent(this, MediaPlayerActivity::class.java).apply {
                    putExtra(MediaPlayerActivity.EXTRA_URI, item.uri.toString())
                    putExtra(MediaPlayerActivity.EXTRA_NAME, item.name)
                    putExtra(MediaPlayerActivity.EXTRA_IS_VIDEO, true)
                }
                startActivity(intent)
                return@setOnItemClickListener
            }
            try {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(item.uri, item.mime)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Không mở được tệp này", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun queryMedia(collection: Uri, mime: String, pathFilter: String): List<MediaItem> {
        val result = ArrayList<MediaItem>()
        try {
            val idCol = if (mime.startsWith("image")) MediaStore.Images.Media._ID else MediaStore.Video.Media._ID
            val nameCol = if (mime.startsWith("image")) MediaStore.Images.Media.DISPLAY_NAME else MediaStore.Video.Media.DISPLAY_NAME
            val pathCol = if (mime.startsWith("image")) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Video.Media.RELATIVE_PATH

            val projection = arrayOf(idCol, nameCol)
            val selection = "$pathCol LIKE ?"
            val args = arrayOf("%AdBlockBrowser%")

            contentResolver.query(collection, projection, selection, args, "date_added DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(idCol)
                val nameIndex = cursor.getColumnIndexOrThrow(nameCol)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idIndex)
                    val name = cursor.getString(nameIndex)
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    result.add(MediaItem(name, uri, mime))
                }
            }
        } catch (e: Exception) { }
        return result
    }
}
