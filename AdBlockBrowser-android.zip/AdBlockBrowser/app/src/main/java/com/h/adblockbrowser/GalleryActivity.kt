package com.h.adblockbrowser

import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

data class MediaItem(val id: Long, val name: String, val uri: Uri, val isVideo: Boolean)

/** Bộ sưu tập - 2 tab "Ảnh" / "Video" phía trên, bên dưới là LƯỚI ẢNH VUÔNG NHỎ 3 CỘT (giống
 *  trình xem ảnh gốc đơn giản của Android), bấm vào ảnh mở [ImageViewerActivity] (vuốt qua lại
 *  giữa các ảnh), bấm vào video mở [MediaPlayerActivity] (đã có sẵn từ trước, có đủ điều khiển). */
class GalleryActivity : AppCompatActivity() {

    private val thumbExecutor = Executors.newFixedThreadPool(3)
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private var photos: List<MediaItem> = emptyList()
    private var videos: List<MediaItem> = emptyList()
    private var showingPhotos = true

    private lateinit var tabPhoto: TextView
    private lateinit var tabVideo: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyLabel: TextView
    private lateinit var adapter: MediaGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(0, dp(40), 0, 0)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, dp(24), dp(16))
        }
        val title = TextView(this).apply {
            text = "🖼 Bộ sưu tập"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), 0, 0, 0)
        }
        titleRow.addView(buildBackArrow())
        titleRow.addView(title)
        root.addView(titleRow)

        // ── 2 ô tab chính: Ảnh (trái) / Video (phải) ──
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), 0, dp(16), dp(8))
        }
        tabPhoto = TextView(this).apply {
            text = "🖼  Ảnh"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
            isClickable = true
            setOnClickListener { switchTab(true) }
        }
        tabVideo = TextView(this).apply {
            text = "🎬  Video"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
            isClickable = true
            setOnClickListener { switchTab(false) }
        }
        tabRow.addView(tabPhoto)
        tabRow.addView(tabVideo)
        root.addView(tabRow)

        val gridArea = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        recyclerView = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, 3)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            clipToPadding = false
        }
        emptyLabel = TextView(this).apply {
            text = "Chưa có ảnh nào được lưu từ app."
            setTextColor(0xFF888888.toInt())
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        }
        gridArea.addView(recyclerView)
        gridArea.addView(emptyLabel)
        root.addView(gridArea)
        setContentView(root)

        adapter = MediaGridAdapter(emptyList(), thumbExecutor, mainHandler) { item, index, list ->
            if (item.isVideo) {
                val intent = android.content.Intent(this, MediaPlayerActivity::class.java).apply {
                    putExtra(MediaPlayerActivity.EXTRA_URI, item.uri.toString())
                    putExtra(MediaPlayerActivity.EXTRA_NAME, item.name)
                    putExtra(MediaPlayerActivity.EXTRA_IS_VIDEO, true)
                }
                startActivity(intent)
            } else {
                val intent = android.content.Intent(this, ImageViewerActivity::class.java).apply {
                    putStringArrayListExtra(ImageViewerActivity.EXTRA_URIS, ArrayList(list.map { it.uri.toString() }))
                    putExtra(ImageViewerActivity.EXTRA_START_INDEX, index)
                }
                startActivity(intent)
            }
        }
        recyclerView.adapter = adapter

        photos = queryMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, isVideo = false)
        videos = queryMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, isVideo = true)
        switchTab(true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun switchTab(photoTab: Boolean) {
        showingPhotos = photoTab
        tabPhoto.setTextColor(if (photoTab) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
        tabPhoto.setBackgroundColor(if (photoTab) 0x33C724FF else 0x00000000)
        tabVideo.setTextColor(if (!photoTab) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
        tabVideo.setBackgroundColor(if (!photoTab) 0x33C724FF else 0x00000000)

        val list = if (photoTab) photos else videos
        adapter.updateItems(list)
        emptyLabel.text = if (photoTab) "Chưa có ảnh nào được lưu từ app." else "Chưa có video nào được lưu từ app."
        emptyLabel.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun queryMedia(collection: Uri, isVideo: Boolean): List<MediaItem> {
        val result = ArrayList<MediaItem>()
        try {
            val idCol = if (isVideo) MediaStore.Video.Media._ID else MediaStore.Images.Media._ID
            val nameCol = if (isVideo) MediaStore.Video.Media.DISPLAY_NAME else MediaStore.Images.Media.DISPLAY_NAME
            val pathCol = if (isVideo) MediaStore.Video.Media.RELATIVE_PATH else MediaStore.Images.Media.RELATIVE_PATH

            val projection = arrayOf(idCol, nameCol)
            val selection = "$pathCol LIKE ?"
            val args = arrayOf("%AdBlockBrowser%")

            contentResolver.query(collection, projection, selection, args, "date_added DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(idCol)
                val nameIndex = cursor.getColumnIndexOrThrow(nameCol)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idIndex)
                    val name = cursor.getString(nameIndex)
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    result.add(MediaItem(id, name, uri, isVideo))
                }
            }
        } catch (e: Exception) { }
        return result
    }

    override fun onDestroy() {
        thumbExecutor.shutdownNow()
        super.onDestroy()
    }
}

/** Adapter lưới ảnh vuông 3 cột - tải ảnh thu nhỏ (thumbnail) ở luồng nền, đơn giản nhẹ, không
 *  dùng thư viện load ảnh ngoài nào (Glide/Coil...) để giữ app nhẹ nhất có thể. */
class MediaGridAdapter(
    private var items: List<MediaItem>,
    private val executor: java.util.concurrent.ExecutorService,
    private val mainHandler: android.os.Handler,
    private val onClick: (MediaItem, Int, List<MediaItem>) -> Unit
) : RecyclerView.Adapter<MediaGridAdapter.VH>() {

    inner class VH(val image: ImageView, val videoBadge: TextView) : RecyclerView.ViewHolder(image.parent as View)

    fun updateItems(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val density = parent.context.resources.displayMetrics.density
        val cell = FrameLayout(parent.context)
        val image = ImageView(parent.context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1A1A1A.toInt())
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (110 * density).toInt())
        }
        val badge = TextView(parent.context).apply {
            text = "▶"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, (4 * density).toInt(), (4 * density).toInt()) }
        }
        cell.addView(image)
        cell.addView(badge)
        val cellLp = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cellLp.setMargins((2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt(), (2 * density).toInt())
        cell.layoutParams = cellLp
        return VH(image, badge)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.image.setImageDrawable(null)
        holder.videoBadge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        holder.image.setOnClickListener { onClick(item, position, items) }

        val ctx = holder.image.context
        executor.execute {
            val bmp = loadThumbnail(ctx, item)
            mainHandler.post {
                if (holder.adapterPosition == position) holder.image.setImageBitmap(bmp)
            }
        }
    }

    private fun loadThumbnail(ctx: android.content.Context, item: MediaItem): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ctx.contentResolver.loadThumbnail(item.uri, Size(300, 300), null)
            } else if (item.isVideo) {
                @Suppress("DEPRECATION")
                MediaStore.Video.Thumbnails.getThumbnail(
                    ctx.contentResolver, item.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Thumbnails.getThumbnail(
                    ctx.contentResolver, item.id, MediaStore.Images.Thumbnails.MINI_KIND, null
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = items.size
}
