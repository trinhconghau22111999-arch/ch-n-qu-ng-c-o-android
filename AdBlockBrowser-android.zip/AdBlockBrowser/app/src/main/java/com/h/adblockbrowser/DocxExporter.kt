package com.h.adblockbrowser

import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Tự dựng file .docx (Word) từ danh sách [DocBlock] - .docx thực chất là 1 file ZIP chứa các
 *  tệp XML theo chuẩn OOXML (Office Open XML). Không cần thư viện ngoài, chỉ dùng java.util.zip
 *  có sẵn trong Android. Hỗ trợ: đoạn văn bản thuần (giữ xuống dòng) và ảnh chèn giữa văn bản
 *  (căn giữa trang, tự co theo chiều rộng trang A4). */
object DocxExporter {

    private const val EMU_PER_PIXEL = 9525 // 1 px (96dpi) = 9525 EMU - đơn vị đo trong OOXML
    private const val MAX_IMG_WIDTH_PX = 550 // ~5.7 inch, vừa khổ A4 có lề

    fun export(outFile: File, title: String, blocks: List<DocBlock>) {
        ZipOutputStream(FileOutputStream(outFile)).use { zip ->
            writeEntry(zip, "[Content_Types].xml", contentTypesXml())
            writeEntry(zip, "_rels/.rels", rootRelsXml())
            writeEntry(zip, "docProps/core.xml", coreXml(title))

            val images = blocks.filter { it.type == "image" && it.imagePath != null }
            writeEntry(zip, "word/_rels/document.xml.rels", documentRelsXml(images.size))
            writeEntry(zip, "word/document.xml", documentXml(title, blocks))

            images.forEachIndexed { idx, block ->
                val path = block.imagePath ?: return@forEachIndexed
                val bytes = File(path).takeIf { it.exists() }?.readBytes() ?: return@forEachIndexed
                zip.putNextEntry(ZipEntry("word/media/image${idx + 1}.jpg"))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }

    private fun writeEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun contentTypesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="jpg" ContentType="image/jpeg"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""

    private fun rootRelsXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>"""

    private fun coreXml(title: String) = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:title>${escapeXml(title)}</dc:title>
</cp:coreProperties>"""

    private fun documentRelsXml(imageCount: Int): String {
        val rels = StringBuilder()
        for (i in 1..imageCount) {
            rels.append("<Relationship Id=\"rId$i\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image$i.jpg\"/>\n")
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$rels</Relationships>"""
    }

    private fun documentXml(title: String, blocks: List<DocBlock>): String {
        val body = StringBuilder()
        // Tiêu đề tài liệu, in đậm cỡ lớn
        body.append("<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val=\"36\"/></w:rPr><w:t xml:space=\"preserve\">${escapeXml(title)}</w:t></w:r></w:p>")

        var imgIndex = 0
        for (block in blocks) {
            when (block.type) {
                "text" -> {
                    val text = block.text ?: ""
                    // Giữ xuống dòng: mỗi dòng con trong đoạn -> 1 <w:r> riêng ngăn bởi <w:br/>
                    val lines = text.split("\n")
                    body.append("<w:p><w:r>")
                    lines.forEachIndexed { i, line ->
                        if (i > 0) body.append("<w:br/>")
                        body.append("<w:t xml:space=\"preserve\">${escapeXml(line)}</w:t>")
                    }
                    body.append("</w:r></w:p>")
                }
                "image" -> {
                    imgIndex++
                    val path = block.imagePath
                    val (cx, cy) = imageSizeEmu(path)
                    body.append(
                        "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing>" +
                        "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
                        "<wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
                        "<wp:docPr id=\"$imgIndex\" name=\"Picture $imgIndex\"/>" +
                        "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                        "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"$imgIndex\" name=\"Picture $imgIndex\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                        "<pic:blipFill><a:blip r:embed=\"rId$imgIndex\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                        "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
                        "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
                        "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
                    )
                }
            }
        }

        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>
$body
<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417"/></w:sectPr>
</w:body>
</w:document>"""
    }

    private fun imageSizeEmu(path: String?): Pair<Long, Long> {
        if (path == null) return Pair(1L, 1L)
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            var w = opts.outWidth; var h = opts.outHeight
            if (w <= 0 || h <= 0) return Pair(1L, 1L)
            if (w > MAX_IMG_WIDTH_PX) {
                h = (h.toFloat() * MAX_IMG_WIDTH_PX / w).toInt()
                w = MAX_IMG_WIDTH_PX
            }
            Pair(w.toLong() * EMU_PER_PIXEL, h.toLong() * EMU_PER_PIXEL)
        } catch (e: Exception) {
            Pair(1L, 1L)
        }
    }

    private fun escapeXml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
