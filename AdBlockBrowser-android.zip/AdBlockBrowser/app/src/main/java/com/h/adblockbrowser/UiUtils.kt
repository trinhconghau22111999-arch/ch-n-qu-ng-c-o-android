package com.h.adblockbrowser

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Lấy chiều cao status bar thật (px) để tránh nội dung bị che.
 *  QUAN TRỌNG: resource "status_bar_height" là resource ẩn của hệ thống, KHÔNG đảm bảo đúng
 *  trên mọi ROM (đặc biệt MIUI) hoặc khi app đang chạy ở chế độ cửa sổ nổi/pop-up - có thể trả
 *  về giá trị SAI, rất lớn, khiến các thanh top bar trong app bị đẩy xuống giữa màn hình. Vì
 *  vậy LUÔN giới hạn (clamp) kết quả trong khoảng hợp lý của 1 status bar thật (tối đa 60dp -
 *  kể cả máy có tai thỏ/đục lỗ cũng không status bar nào cao hơn mức này). */
fun Activity.statusBarHeight(): Int {
    val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
    val raw = if (resId > 0) resources.getDimensionPixelSize(resId) else dp(24)
    val maxReasonable = dp(60)
    return if (raw in 1..maxReasonable) raw else dp(24)
}

fun Activity.buildBackArrow(onBack: () -> Unit = { finish() }): TextView =
    TextView(this).apply {
        text = "◀"
        textSize = 32f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setBackgroundColor(0x66000000)
        isClickable = true
        isFocusable = true
        android.graphics.Typeface.DEFAULT_BOLD.also { typeface = it }
        setOnClickListener { onBack() }
    }

/** Gắn thanh đa nhiệm nổi (FloatingNavBar, 3 nút Đa nhiệm/Home/Back) lên MỌI màn hình dùng hàm
 *  này thay cho setContentView(view) thông thường - dùng chung cho tất cả màn phụ (Máy tính,
 *  Lịch, Camera, Đồng hồ, Ghi chú, Quản lý tệp, Thư viện, Xem ảnh, Ẩn danh, Phát media, Ghi âm,
 *  Cài đặt, Truy cập nhanh...). KHÔNG dùng cho 2 màn khoá (LockScreenActivity,
 *  AppLockSetupActivity) vì lý do bảo mật - không được để lộ đường tắt thoát ra ngoài lúc đang
 *  yêu cầu xác thực.
 *
 *  Trên các màn phụ (không phải MainActivity), cả 3 nút đều đưa về đúng 1 hành động hợp lý nhất:
 *  đóng màn hiện tại (finish()) để quay lại nơi mở nó ra (thường là màn hình chính) - vì khái
 *  niệm "Đa nhiệm nhiều tab web" hay "Home riêng có widget đồng hồ" chỉ có ý nghĩa bên trong
 *  MainActivity (nơi đã tự triển khai FloatingNavBar riêng với hành vi đầy đủ hơn). */
fun Activity.setContentViewWithNavBar(content: View) {
    val wrapper = FrameLayout(this)
    wrapper.addView(content, FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    ))
    setContentView(wrapper)

    val navBar = FloatingNavBar(
        context = this,
        onMultitask = { finish() },
        onHome = { finish() },
        onBack = { finish() }
    )
    navBar.attachTo(wrapper)
}

fun Activity.overlayBackArrow(root: FrameLayout) {
    val back = buildBackArrow()
    val lp = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        // Dùng chiều cao status bar thật thay vì giá trị cứng
        topMargin = statusBarHeight() + dp(8)
        leftMargin = dp(16)
    }
    root.addView(back, lp)
}
