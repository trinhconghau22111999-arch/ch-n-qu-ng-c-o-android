package com.h.adblockbrowser

import android.app.Activity
import android.content.Intent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Lấy chiều cao status bar thật (px) để tránh nội dung bị che */
fun Activity.statusBarHeight(): Int {
    val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(24)
}

fun Activity.buildBackArrow(onBack: () -> Unit = { finish() }): TextView =
    TextView(this).apply {
        text = "◀"
        textSize = 32f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setBackgroundColor(0x66000000)
        isClickable = true
        isFocusable = true
        android.graphics.Typeface.DEFAULT_BOLD.also { typeface = it }
        setOnClickListener { onBack() }
    }

fun Activity.overlayBackArrow(root: FrameLayout) {
    val back = buildBackArrow()
    val lp = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        // Dùng chiều cao status bar thật thay vì giá trị cứng
        topMargin = statusBarHeight() + dp(8)
        leftMargin = dp(16)
    }
    root.addView(back, lp)
}

/**
 * Bọc nội dung màn hình (content) vào 1 FrameLayout rồi setContentView, đồng thời gắn THANH
 * ĐA NHIỆM (FloatingNavBar: lùi / xem app / home / đa nhiệm) NỔI lên trên - để thanh này luôn
 * có mặt ở MỌI trang trong app (Máy tính, Lịch, Camera, Đồng hồ, Tệp, Thư viện, Ẩn danh, Ghi
 * chú, Ghi âm, phát media, Cài đặt...), giống như 1 thanh điều hướng hệ thống thật, chứ không
 * chỉ riêng màn hình duyệt web (MainActivity đã tự gắn thanh riêng của nó, không dùng hàm này).
 *
 * KHÔNG dùng cho LockScreenActivity / AppLockSetupActivity (không được phép thoát/điều hướng
 * lung tung trước khi xác thực xong).
 */
fun Activity.setContentViewWithNavBar(content: android.view.View) {
    val overlay = FrameLayout(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }
    overlay.addView(
        content,
        FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    )
    setContentView(overlay)

    val navBar = FloatingNavBar(
        context = this,
        onMultitask = {
            // Tuỳ chọn trang (dịch trang, bản máy tính...) chỉ có ý nghĩa trong trình duyệt.
            Toast.makeText(this, "Tuỳ chọn trang chỉ có trong trình duyệt", Toast.LENGTH_SHORT).show()
        },
        onApps = { startActivity(Intent(this, ShortcutsActivity::class.java)) },
        onHome = {
            val i = Intent(this, MainActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(i)
        },
        onBack = { finish() }
    )
    navBar.attachTo(overlay)
}
