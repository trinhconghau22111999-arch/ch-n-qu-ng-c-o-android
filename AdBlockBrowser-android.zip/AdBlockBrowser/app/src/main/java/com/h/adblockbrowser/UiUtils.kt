package com.h.adblockbrowser

import android.app.Activity
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

/** Nút mũi tên "←" thoát màn hình, đặt cố định ở góc trái trên - đúng vị trí quen thuộc của các
 *  app thật (Gmail, Maps, Zoom...), thay vì chỉ trông chờ vào nút back hệ thống. Dùng chung cho
 *  mọi màn phụ (Camera, Bộ sưu tập, Tệp, Ghi âm, Đồng hồ, Lịch, Máy tính, Phát media...) để đồng
 *  bộ 1 kiểu duy nhất trong toàn app. */
fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Activity.buildBackArrow(onBack: () -> Unit = { finish() }): TextView =
    TextView(this).apply {
        text = "←"
        textSize = 24f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setBackgroundColor(0x66000000)
        isClickable = true
        isFocusable = true
        setOnClickListener { onBack() }
    }

/** Đặt nút back làm view NỔI ĐÈ ở góc trái trên cùng của [root] (root phải là FrameLayout, hoặc
 *  root được bọc trong 1 FrameLayout ngoài cùng) - dùng cho các màn có layout không dễ chèn thêm
 *  1 hàng ngang ở đầu (vd: CameraActivity dùng full-screen preview, ClockActivity căn giữa). */
fun Activity.overlayBackArrow(root: FrameLayout) {
    val back = buildBackArrow()
    val lp = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        topMargin = dp(32)
        leftMargin = dp(16)
    }
    root.addView(back, lp)
}

/** Nút icon tròn DÙNG CHUNG cho cả app (chia sẻ, xoá, và các hành động tương tự) - thay cho kiểu
 *  cũ mỗi màn tự vẽ 1 emoji/ký tự khác nhau. Icon vector (24dp) đặt giữa 1 khối nền tròn mờ
 *  [circle_icon_btn_bg], màu icon [tint] tuỳ chỉnh theo ngữ cảnh (trắng cho chia sẻ, đỏ cho xoá).
 *  size = đường kính khối nền tròn (mặc định 40dp, đủ to để bấm thoải mái bằng ngón tay). */
fun Activity.buildIconButton(
    iconRes: Int, tint: Int, size: Int = 40, onClick: () -> Unit
): FrameLayout = FrameLayout(this).apply {
    background = androidx.core.content.ContextCompat.getDrawable(this@buildIconButton, R.drawable.circle_icon_btn_bg)
    // KHÔNG gán sẵn layoutParams cụ thể ở đây - nút này được dùng lại ở nhiều màn với parent khác
    // kiểu nhau (LinearLayout, FrameLayout...). Gán cứng 1 loại LayoutParams rồi add vào parent
    // khác kiểu sẽ crash (ClassCastException) ngay khi layout. Dùng minimumWidth/Height để LUÔN
    // ra đúng kích thước hình tròn dù parent tự sinh layoutParams kiểu gì.
    minimumWidth = dp(size)
    minimumHeight = dp(size)
    isClickable = true
    isFocusable = true
    setOnClickListener { onClick() }

    val icon = ImageView(this@buildIconButton).apply {
        setImageResource(iconRes)
        imageTintList = ColorStateList.valueOf(tint)
        val iconLp = FrameLayout.LayoutParams(dp(size * 5 / 8), dp(size * 5 / 8))
        iconLp.gravity = Gravity.CENTER
        layoutParams = iconLp
    }
    addView(icon)
}
