package com.h.adblockbrowser

import android.app.Activity
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

/** Nút mũi tên "←" thoát màn hình, đặt cố định ở góc trái trên - đúng vị trí quen thuộc của các
 *  app thật (Gmail, Maps, Zoom...), thay vì chỉ trông chờ vào nút back hệ thống. Dùng chung cho
 *  mọi màn phụ (Camera, Bộ sưu tập, Tệp, Ghi âm, Đồng hồ, Lịch, Máy tính, Phát media...) để đồng
 *  bộ 1 kiểu duy nhất trong toàn app. */
fun Activity.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Activity.buildBackArrow(onBack: () -> Unit = { finish() }): TextView =
    TextView(this).apply {
        text = "◀"
        textSize = 32f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setBackgroundColor(0x66000000)
        isClickable = true
        isFocusable = true
        android.graphics.Typeface.DEFAULT_BOLD.also { typeface = it }
        setOnClickListener { onBack() }
    }

/** Đặt nút back làm view NỔI ĐÈ ở góc trái trên cùng của [root] (root phải là FrameLayout, hoặc
 *  root được bọc trong 1 FrameLayout ngoài cùng) - dùng cho các màn có layout không dễ chèn thêm
 *  1 hàng ngang ở đầu (vd: CameraActivity dùng full-screen preview, ClockActivity căn giữa). */
fun Activity.overlayBackArrow(root: FrameLayout) {
    val back = buildBackArrow()
    val lp = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        topMargin = dp(32)
        leftMargin = dp(16)
    }
    root.addView(back, lp)
}
