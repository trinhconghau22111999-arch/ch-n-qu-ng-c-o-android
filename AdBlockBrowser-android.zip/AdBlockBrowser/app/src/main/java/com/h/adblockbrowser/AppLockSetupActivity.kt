package com.h.adblockbrowser

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AppLockSetupActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var firstPin: String? = null
    private var firstPattern: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF000000.toInt())
            setPadding(dp(32), dp(40), dp(32), dp(32))
        }
        setContentView(root)
        showMenu()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun clearRoot() { root.removeAllViews() }

    private fun addTitle(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            setTextColor(0xFFC724FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        })
    }

    private fun showMenu() {
        clearRoot()
        addTitle("🔒 Khoá ứng dụng")
        val current = AppLockPrefs.lockType(this)
        root.addView(TextView(this).apply {
            text = when (current) {
                "pin" -> "Đang dùng: Mã PIN"
                "pattern" -> "Đang dùng: Hình mở khoá"
                else -> "Hiện chưa đặt khoá"
            }
            setTextColor(0xFF888888.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        })
        root.addView(menuButton("Đặt mã PIN") { firstPin = null; showPinStep(1) })
        root.addView(menuButton("Đặt hình mở khoá") { firstPattern = null; showPatternStep(1) })
        if (current != "none") {
            root.addView(menuButton("Tắt khoá") {
                AppLockPrefs.clear(this)
                Toast.makeText(this, "Đã tắt khoá ứng dụng", Toast.LENGTH_SHORT).show()
                showMenu()
            })
        }
        root.addView(menuButton("← Quay lại") { finish() })
    }

    private fun menuButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF1A1A1A.toInt())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        layoutParams = lp
        setOnClickListener { onClick() }
    }

    private fun showPinStep(step: Int) {
        clearRoot()
        addTitle(if (step == 1) "Nhập mã PIN mới (tối thiểu 4 số)" else "Nhập lại mã PIN để xác nhận")
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(200), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(input)
        root.addView(menuButton("Tiếp tục") {
            val pin = input.text.toString()
            if (pin.length < 4) {
                Toast.makeText(this, "PIN cần tối thiểu 4 số", Toast.LENGTH_SHORT).show()
                return@menuButton
            }
            if (step == 1) {
                firstPin = pin
                showPinStep(2)
            } else {
                if (pin == firstPin) {
                    AppLockPrefs.setPin(this, pin)
                    Toast.makeText(this, "Đã đặt mã PIN", Toast.LENGTH_SHORT).show()
                    showMenu()
                } else {
                    Toast.makeText(this, "Hai lần nhập không khớp, thử lại", Toast.LENGTH_SHORT).show()
                    firstPin = null
                    showPinStep(1)
                }
            }
        })
        root.addView(menuButton("Huỷ") { showMenu() })
    }

    private fun showPatternStep(step: Int) {
        clearRoot()
        addTitle(if (step == 1) "Vẽ hình mở khoá mới (nối tối thiểu 4 chấm)" else "Vẽ lại hình để xác nhận")
        val patternView = PatternLockView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(280), dp(280))
        }
        patternView.onPatternTooShort = {
            Toast.makeText(this, "Cần nối tối thiểu 4 chấm", Toast.LENGTH_SHORT).show()
        }
        patternView.onPatternComplete = { pattern ->
            if (step == 1) {
                firstPattern = pattern
                showPatternStep(2)
            } else {
                if (pattern == firstPattern) {
                    AppLockPrefs.setPattern(this, pattern)
                    Toast.makeText(this, "Đã đặt hình mở khoá", Toast.LENGTH_SHORT).show()
                    showMenu()
                } else {
                    Toast.makeText(this, "Hai lần vẽ không khớp, thử lại", Toast.LENGTH_SHORT).show()
                    firstPattern = null
                    showPatternStep(1)
                }
            }
        }
        root.addView(patternView)
        root.addView(menuButton("Huỷ") { showMenu() })
    }
}
