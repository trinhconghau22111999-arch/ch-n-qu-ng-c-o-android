package com.h.adblockbrowser

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/**
 * Thanh ngắn (grip) nằm sát cạnh PHẢI, phía trên màn hình. Vuốt từ cạnh phải sang trái để kéo
 * ra 1 bảng nhỏ gồm 2 icon:
 *   1. Đổi bản máy tính / di động (thay cho nút btnDesktopSite nổi cũ - đã ẩn khỏi màn hình)
 *   2. Dịch toàn bộ trang hiện tại sang tiếng Việt (dịch mọi ngôn ngữ gốc)
 * Vuốt/thả ra giữa chừng sẽ tự "chốt" về trạng thái mở hoàn toàn hoặc đóng hoàn toàn (giống các
 * ngăn kéo cạnh - edge panel - trên điện thoại thật).
 */
class EdgeSwipePanel(
    private val context: Context,
    private val onToggleDesktop: () -> Unit,
    private val onTranslate: () -> Unit
) {
    private lateinit var handle: View
    private lateinit var panel: LinearLayout
    private lateinit var iconDesktop: ImageView
    private lateinit var iconTranslate: ImageView

    private val panelWidthPx get() = dp(96)
    private val handleWidthPx get() = dp(10)
    private val barHeightPx get() = dp(56)
    private val topMarginPx get() = dp(90)

    private var downRawX = 0f
    private var isOpen = false

    fun attachTo(root: FrameLayout) {
        // Grip mỏng dính sát cạnh phải, luôn cố định vị trí (không di chuyển)
        handle = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(
                    dp(8).toFloat(), dp(8).toFloat(),   // top-left
                    0f, 0f,                              // top-right (sát mép nên vuông)
                    0f, 0f,                              // bottom-right
                    dp(8).toFloat(), dp(8).toFloat()    // bottom-left
                )
                setColor(0xB3444444.toInt())
            }
        }
        val handleLp = FrameLayout.LayoutParams(handleWidthPx, barHeightPx).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = topMarginPx
        }
        root.addView(handle, handleLp)

        // Bảng 2 icon, ẩn phía sau/ngoài mép phải, chỉ lộ ra khi vuốt
        panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(
                    dp(14).toFloat(), dp(14).toFloat(),
                    0f, 0f,
                    0f, 0f,
                    dp(14).toFloat(), dp(14).toFloat()
                )
                setColor(0xE6111111.toInt())
                setStroke(dp(1), 0xFF333333.toInt())
            }
            elevation = dp(6).toFloat()
        }
        val panelLp = FrameLayout.LayoutParams(panelWidthPx, barHeightPx).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = topMarginPx
            marginEnd = handleWidthPx
        }
        root.addView(panel, panelLp)
        // Đóng sẵn: đẩy panel ra hết bên phải (nằm sau grip, ngoài màn hình)
        panel.translationX = panelWidthPx.toFloat()

        iconDesktop = buildIcon(R.drawable.ic_mobile_mode, "Bản máy tính / di động") {
            onToggleDesktop()
            closePanel()
        }
        iconTranslate = buildIcon(R.drawable.ic_translate, "Dịch trang sang tiếng Việt") {
            onTranslate()
            closePanel()
        }
        panel.addView(iconDesktop)
        panel.addView(iconTranslate)

        setupSwipe(root)
    }

    /** Gọi từ MainActivity mỗi khi trạng thái desktop/mobile đổi để icon phản ánh đúng. */
    fun setDesktopIcon(forceDesktop: Boolean) {
        iconDesktop.setImageResource(
            if (forceDesktop) R.drawable.ic_desktop_mode else R.drawable.ic_mobile_mode
        )
    }

    private fun buildIcon(res: Int, desc: String, onClick: () -> Unit): ImageView =
        ImageView(context).apply {
            setImageResource(res)
            contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun setupSwipe(root: FrameLayout) {
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Vuốt từ phải qua trái -> delta dương -> mở dần
                    val delta = downRawX - event.rawX
                    val newTranslation = (panelWidthPx - delta)
                        .coerceIn(0f, panelWidthPx.toFloat())
                    panel.translationX = newTranslation
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    // Kéo qua được hơn 40% bề rộng bảng -> chốt mở, ngược lại chốt đóng
                    if (panel.translationX < panelWidthPx * 0.6f) {
                        openPanel()
                    } else {
                        closePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun openPanel() {
        isOpen = true
        panel.animate().translationX(0f).setDuration(150).start()
    }

    private fun closePanel() {
        isOpen = false
        panel.animate().translationX(panelWidthPx.toFloat()).setDuration(150).start()
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
