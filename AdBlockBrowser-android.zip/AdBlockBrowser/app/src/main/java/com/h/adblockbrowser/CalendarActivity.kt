package com.h.adblockbrowser

import android.os.Bundle
import android.widget.CalendarView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CalendarActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "📅 Lịch"
            textSize = 20f
            setTextColor(0xFFC724FF.toInt())
            setPadding(0, 0, 0, 16)
        }

        val tvSelected = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 16, 0, 0)
            text = "Đã chọn: " + SimpleDateFormat("dd/MM/yyyy", Locale("vi")).format(Date())
        }

        val calendarView = CalendarView(this).apply {
            setBackgroundColor(0xFF0D0D0D.toInt())
            setOnDateChangeListener { _, year, month, dayOfMonth ->
                tvSelected.text = String.format("Đã chọn: %02d/%02d/%d", dayOfMonth, month + 1, year)
            }
        }

        root.addView(title)
        root.addView(calendarView)
        root.addView(tvSelected)
        setContentView(root)
    }
}
