package com.h.adblockbrowser

import android.content.ContentValues
import android.graphics.drawable.GradientDrawable
import android.media.MediaActionSound
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var btnFlash: TextView
    private lateinit var tvFlashLabel: TextView
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private val shutterSound = MediaActionSound()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        shutterSound.load(MediaActionSound.SHUTTER_CLICK)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // Nút chụp: viền trắng sáng + khối tròn trắng đặc bên trong (như nút chụp thật của
        // camera gốc), to hơn bản trước (84dp thay vì 76dp). Khi bấm, khối tròn trong co lại
        // một nhịp rồi trở về, giống hiệu ứng nhấn của app camera thật.
        val ringSize = dp(84)
        val ringStroke = dp(6)
        val innerMargin = dp(10)
        val innerMarginPressed = dp(18)
        val shutterRing = FrameLayout(this)
        val innerCircle = android.view.View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFFFFFFF.toInt())
            }
        }
        shutterRing.apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(ringStroke, 0xFFFFFFFF.toInt())
                setColor(0x00000000)
            }
            isClickable = true
            isFocusable = true
            addView(innerCircle, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                setMargins(innerMargin, innerMargin, innerMargin, innerMargin)
            })
            setOnClickListener {
                (innerCircle.layoutParams as FrameLayout.LayoutParams).setMargins(
                    innerMarginPressed, innerMarginPressed, innerMarginPressed, innerMarginPressed
                )
                innerCircle.requestLayout()
                postDelayed({
                    (innerCircle.layoutParams as FrameLayout.LayoutParams).setMargins(
                        innerMargin, innerMargin, innerMargin, innerMargin
                    )
                    innerCircle.requestLayout()
                }, 120)
                takePhoto()
            }
        }
        val btnParams = FrameLayout.LayoutParams(ringSize, ringSize)
        btnParams.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        btnParams.bottomMargin = dp(50)
        root.addView(shutterRing, btnParams)

        // Nút lật camera trước/sau - hình tròn kính mờ trắng, icon trắng, cùng phong cách với
        // nút flash, giống cụm nút của app camera gốc thay vì nền đen đơn giản như trước.
        val btnFlip = TextView(this).apply {
            text = "🔄"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x40FFFFFF)
            }
            isClickable = true
            setOnClickListener { flipCamera() }
        }
        val flipParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flipParams.gravity = Gravity.BOTTOM or Gravity.END
        flipParams.bottomMargin = dp(66); flipParams.rightMargin = dp(28)
        root.addView(btnFlip, flipParams)

        // Nút đèn flash - hình tròn kính mờ trắng cùng cỡ với nút lật camera, icon trắng khi
        // tắt và chuyển màu vàng khi bật/tự động - đúng quy ước màu của app camera thật.
        val flashCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        btnFlash = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x40FFFFFF)
            }
            isClickable = true
            setOnClickListener { toggleFlash() }
        }
        tvFlashLabel = TextView(this).apply {
            text = "Tắt"
            textSize = 10f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
            setBackgroundColor(0x66000000)
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        flashCol.addView(btnFlash)
        flashCol.addView(tvFlashLabel)
        val flashParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flashParams.gravity = Gravity.TOP or Gravity.END
        flashParams.topMargin = dp(36); flashParams.rightMargin = dp(20)
        root.addView(flashCol, flashParams)

        overlayBackArrow(root)

        setContentView(root)
        startCamera()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder().build().apply {
                this.flashMode = this@CameraActivity.flashMode
            }
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, selector, preview, imageCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Không thể mở camera trên máy này", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun toggleFlash() {
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
            ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        val (label, color) = when (flashMode) {
            ImageCapture.FLASH_MODE_ON -> "Bật" to 0xFFFFD60A.toInt()
            ImageCapture.FLASH_MODE_AUTO -> "Tự động" to 0xFFFFD60A.toInt()
            else -> "Tắt" to 0xFFFFFFFF.toInt()
        }
        tvFlashLabel.text = label
        btnFlash.setTextColor(color)
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        shutterSound.play(MediaActionSound.SHUTTER_CLICK)

        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AdBlockBrowser")
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(this@CameraActivity, "Đã lưu vào Pictures/AdBlockBrowser", Toast.LENGTH_SHORT).show()
                }

                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(this@CameraActivity, "Chụp ảnh thất bại", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    override fun onDestroy() {
        shutterSound.release()
        super.onDestroy()
    }
}
