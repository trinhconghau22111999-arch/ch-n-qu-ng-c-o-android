package com.h.adblockbrowser

import android.content.ContentValues
import android.graphics.drawable.GradientDrawable
import android.media.MediaActionSound
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var btnFlash: TextView
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashOn = false
    private val shutterSound = MediaActionSound()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        shutterSound.load(MediaActionSound.SHUTTER_CLICK)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // Nút chụp: viền tròn màu xám, RỖNG bên trong - đúng kiểu nút chụp máy ảnh thật, thay cho
        // nút chữ "⬤ Chụp" trước đây.
        val ringSize = dp(76)
        val btnCapture = android.view.View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(4), 0xFFBBBBBB.toInt())
                setColor(0x00000000) // rỗng bên trong, không tô màu
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                // Hiệu ứng bấm: chớp nhanh phần rỗng bên trong thành trắng mờ rồi tắt lại, giống
                // nút chụp thật, kèm âm thanh chụp.
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(4), 0xFFBBBBBB.toInt())
                    setColor(0x33FFFFFF)
                }
                postDelayed({
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(4), 0xFFBBBBBB.toInt())
                        setColor(0x00000000)
                    }
                }, 120)
                takePhoto()
            }
        }
        val btnParams = FrameLayout.LayoutParams(ringSize, ringSize)
        btnParams.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        btnParams.bottomMargin = dp(50)
        root.addView(btnCapture, btnParams)

        // Nút lật camera trước/sau - góc dưới phải
        val btnFlip = TextView(this).apply {
            text = "🔄"
            textSize = 26f
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x66000000)
            }
            isClickable = true
            setOnClickListener { flipCamera() }
        }
        val flipParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flipParams.gravity = Gravity.BOTTOM or Gravity.END
        flipParams.bottomMargin = dp(62); flipParams.rightMargin = dp(28)
        root.addView(btnFlip, flipParams)

        // Nút đèn flash - góc trên phải
        btnFlash = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            setTextColor(0xFF888888.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x66000000)
            }
            isClickable = true
            setOnClickListener { toggleFlash() }
        }
        val flashParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flashParams.gravity = Gravity.TOP or Gravity.END
        flashParams.topMargin = dp(36); flashParams.rightMargin = dp(20)
        root.addView(btnFlash, flashParams)

        overlayBackArrow(root)

        setContentView(root)
        startCamera()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder().build().apply {
                flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            }
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, selector, preview, imageCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Không thể mở camera trên máy này", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        btnFlash.setTextColor(if (flashOn) 0xFFC724FF.toInt() else 0xFF888888.toInt())
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        shutterSound.play(MediaActionSound.SHUTTER_CLICK)

        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AdBlockBrowser")
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(this@CameraActivity, "Đã lưu vào Pictures/AdBlockBrowser", Toast.LENGTH_SHORT).show()
                }

                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(this@CameraActivity, "Chụp ảnh thất bại", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    override fun onDestroy() {
        shutterSound.release()
        super.onDestroy()
    }
}
