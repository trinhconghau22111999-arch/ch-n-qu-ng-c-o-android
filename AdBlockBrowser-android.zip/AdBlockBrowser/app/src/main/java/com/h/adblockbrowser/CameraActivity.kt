package com.h.adblockbrowser

import android.content.ContentValues
import android.graphics.drawable.GradientDrawable
import android.media.MediaActionSound
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var btnFlash: TextView
    private lateinit var tvFlashLabel: TextView
    private lateinit var btnCapture: View
    private lateinit var btnMode: TextView
    private lateinit var tvTimer: TextView

    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var isVideoMode = false
    private var isRecording = false

    private val shutterSound = MediaActionSound()
    private val handler = Handler(Looper.getMainLooper())
    private var recSeconds = 0
    private val timerRunnable = object : Runnable {
        override fun run() {
            recSeconds++
            val m = recSeconds / 60; val s = recSeconds % 60
            tvTimer.text = "%02d:%02d".format(m, s)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shutterSound.load(MediaActionSound.SHUTTER_CLICK)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        // ── PreviewView toàn màn hình ──
        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // ── Timer ghi video (ẩn mặc định) ──
        tvTimer = TextView(this).apply {
            text = "00:00"
            textSize = 16f
            setTextColor(0xFFFF4444.toInt())
            visibility = View.GONE
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat(); setColor(0x88000000.toInt())
            }
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        root.addView(tvTimer, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).also { it.topMargin = statusBarHeight() + dp(8) })

        // ── Flash - góc trên phải ──
        val flashCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        }
        btnFlash = TextView(this).apply {
            text = "⚡"; textSize = 22f; setTextColor(0xFF888888.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(4))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66000000) }
            isClickable = true; setOnClickListener { toggleFlash() }
        }
        tvFlashLabel = TextView(this).apply {
            text = "Tắt"; textSize = 10f; setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER; setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        flashCol.addView(btnFlash); flashCol.addView(tvFlashLabel)
        root.addView(flashCol, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        ).also { it.topMargin = statusBarHeight() + dp(8); it.rightMargin = dp(20) })

        // ── Thanh dưới: [Chuyển mode] [Nút chụp] [Lật cam] ──
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(32))
        }

        // Nút chuyển mode Ảnh/Video
        btnMode = TextView(this).apply {
            text = "📷"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = dp(12).toFloat()
                setColor(0x66000000)
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
            isClickable = true
            setOnClickListener { toggleMode() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        // Nút chụp/quay chính giữa
        val captureSize = dp(76)
        btnCapture = View(this).apply {
            background = buildCaptureDrawable(false)
            isClickable = true; isFocusable = true
            setOnClickListener { onCaptureTap() }
            layoutParams = LinearLayout.LayoutParams(captureSize, captureSize).also {
                it.setMargins(0, 0, 0, 0)
                it.gravity = Gravity.CENTER_VERTICAL
            }
        }

        // Nút lật camera
        val btnFlip = TextView(this).apply {
            text = "🔄"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66000000) }
            setPadding(dp(14), dp(14), dp(14), dp(14))
            isClickable = true; setOnClickListener { flipCamera() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        // Wrapper giữa để căn nút chụp
        val centerWrap = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(captureSize, captureSize)
        }
        centerWrap.addView(btnCapture)

        bottomBar.addView(btnMode)
        bottomBar.addView(centerWrap)
        bottomBar.addView(btnFlip)

        root.addView(bottomBar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ))

        setContentViewWithNavBar(root)
        startCamera()
    }

    private fun buildCaptureDrawable(videoMode: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        if (videoMode) {
            setColor(0xFFFF3B30.toInt())  // đỏ khi video mode
            setStroke(dp(5), 0xFFFFFFFF.toInt())
        } else {
            setColor(0x00000000)           // trong suốt khi ảnh
            setStroke(dp(8), 0xFFFFFFFF.toInt())
        }
    }

    private fun buildRecordingDrawable() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE   // vuông khi đang ghi
        cornerRadius = dp(8).toFloat()
        setColor(0xFFFF3B30.toInt())
        setStroke(dp(5), 0xFFFFFFFF.toInt())
    }

    private fun toggleMode() {
        isVideoMode = !isVideoMode
        btnMode.text = if (isVideoMode) "🎬" else "📷"
        btnCapture.background = buildCaptureDrawable(isVideoMode)
        startCamera()
    }

    private fun onCaptureTap() {
        if (isVideoMode) toggleRecording() else takePhoto()
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun toggleFlash() {
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
            ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        val (label, color) = when (flashMode) {
            ImageCapture.FLASH_MODE_ON -> "Bật" to 0xFFC724FF.toInt()
            ImageCapture.FLASH_MODE_AUTO -> "Tự động" to 0xFFC724FF.toInt()
            else -> "Tắt" to 0xFF888888.toInt()
        }
        tvFlashLabel.text = label; btnFlash.setTextColor(color)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val cp = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                cp.unbindAll()
                if (isVideoMode) {
                    val recorder = Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.HIGHEST))
                        .build()
                    videoCapture = VideoCapture.withOutput(recorder)
                    cp.bindToLifecycle(this, selector, preview, videoCapture)
                } else {
                    imageCapture = ImageCapture.Builder().build().apply {
                        this.flashMode = this@CameraActivity.flashMode
                    }
                    cp.bindToLifecycle(this, selector, preview, imageCapture)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Không thể mở camera", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        shutterSound.play(MediaActionSound.SHUTTER_CLICK)
        btnCapture.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(0x33FFFFFF)
            setStroke(dp(8), 0xFFFFFFFF.toInt())
        }
        btnCapture.postDelayed({ btnCapture.background = buildCaptureDrawable(false) }, 120)

        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MiniPhone")
        }
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(out: ImageCapture.OutputFileResults) {
                    Toast.makeText(this@CameraActivity, "Đã lưu ảnh", Toast.LENGTH_SHORT).show()
                }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(this@CameraActivity, "Chụp thất bại", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    private fun toggleRecording() {
        if (isRecording) {
            recording?.stop(); recording = null
            isRecording = false
            handler.removeCallbacks(timerRunnable)
            recSeconds = 0; tvTimer.visibility = View.GONE
            btnCapture.background = buildCaptureDrawable(true)
        } else {
            val vc = videoCapture ?: return
            isRecording = true
            btnCapture.background = buildRecordingDrawable()
            tvTimer.visibility = View.VISIBLE; tvTimer.text = "00:00"
            recSeconds = 0; handler.post(timerRunnable)

            val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MiniPhone")
            }
            recording = vc.output.prepareRecording(this,
                MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                    .setContentValues(values).build()
            ).apply {
                try { withAudioEnabled() } catch (e: Exception) { }
            }.start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    if (!event.hasError()) Toast.makeText(this, "Đã lưu video", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "Lỗi ghi video", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(timerRunnable)
        recording?.stop()
        shutterSound.release()
        super.onDestroy()
    }
}
