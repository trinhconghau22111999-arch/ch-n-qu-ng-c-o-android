package com.h.adblockbrowser

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Trang "Đa nhiệm" TOÀN MÀN HÌNH: lưới 2 HÀNG ô vuông cuộn NGANG, giống màn hình đa nhiệm
 *  (Recent apps / Overview) của các máy Android thật - thay cho hộp thoại danh sách chữ đơn
 *  giản trước đây (showMultitaskDialog cũ). */
class MultitaskActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TabAdapter
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(4))
        }
        titleRow.addView(buildBackArrow())

        val title = TextView(this).apply {
            text = "Đa nhiệm — các trang đã mở"
            textSize = 14f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), 0, dp(8), dp(16))
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        titleRow.addView(title)

        val btnClearAll = TextView(this).apply {
            text = "Xoá tất cả"
            textSize = 13f
            setTextColor(0xFFFF6666.toInt())
            setPadding(dp(12), dp(6), dp(12), dp(6))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                TabSessionStore.list.clear()
                adapter.notifyDataSetChanged()
                refreshEmptyState()
            }
        }
        titleRow.addView(btnClearAll)

        emptyText = TextView(this).apply {
            text = "Chưa có trang nào trong phiên này."
            textSize = 14f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
            visibility = View.GONE
        }

        recyclerView = RecyclerView(this).apply {
            // 2 HÀNG, cuộn NGANG - đúng kiểu lưới đa nhiệm của máy Android thật (không phải
            // lưới cuộn dọc thông thường)
            layoutManager = GridLayoutManager(
                this@MultitaskActivity, 2, GridLayoutManager.HORIZONTAL, false
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
            clipToPadding = false
            setPadding(dp(4), dp(8), dp(4), dp(24))
        }

        root.addView(titleRow)
        root.addView(recyclerView)
        root.addView(emptyText)
        setContentView(root)

        adapter = TabAdapter(
            TabSessionStore.list,
            onOpen = { entry ->
                val result = Intent()
                result.putExtra("url", entry.url)
                setResult(RESULT_OK, result)
                finish()
            },
            onClose = { position ->
                if (position in TabSessionStore.list.indices) {
                    TabSessionStore.list.removeAt(position)
                    adapter.notifyItemRemoved(position)
                    refreshEmptyState()
                }
            }
        )
        recyclerView.adapter = adapter
        refreshEmptyState()
    }

    private fun refreshEmptyState() {
        val empty = TabSessionStore.list.isEmpty()
        emptyText.visibility = if (empty) View.VISIBLE else View.GONE
        recyclerView.visibility = if (empty) View.GONE else View.VISIBLE
    }
}

class TabAdapter(
    private val items: MutableList<SessionTab>,
    private val onOpen: (SessionTab) -> Unit,
    private val onClose: (Int) -> Unit
) : RecyclerView.Adapter<TabAdapter.VH>() {

    inner class VH(val cell: FrameLayout, val titleView: TextView, val urlView: TextView) :
        RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val density = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        // Ô vuông: hiện ~3 ô mỗi hàng trong tầm nhìn, giống mật độ lưới đa nhiệm thật, người
        // dùng vuốt ngang để xem thêm các trang khác.
        val screenWidth = ctx.resources.displayMetrics.widthPixels
        val cellSize = screenWidth / 3

        val cell = FrameLayout(ctx).apply {
            layoutParams = RecyclerView.LayoutParams(cellSize - dp(12), cellSize - dp(12)).apply {
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            background = GradientDrawable().apply {
                setColor(0xFF1A1A1A.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFF333333.toInt())
            }
            isClickable = true
            isFocusable = true
        }

        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val titleView = TextView(ctx).apply {
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            maxLines = 2
        }
        val urlView = TextView(ctx).apply {
            textSize = 10f
            setTextColor(0xFF999999.toInt())
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(0, dp(4), 0, 0)
        }
        content.addView(titleView)
        content.addView(urlView)
        cell.addView(content)

        // Nút đóng (X) góc trên-phải mỗi ô, giống nút đóng tab trên màn đa nhiệm thật
        val close = TextView(ctx).apply {
            text = "✕"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = dp(20).toFloat()
            }
            isClickable = true
            isFocusable = true
        }
        val closeLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(4)
            rightMargin = dp(4)
        }
        cell.addView(close, closeLp)

        return VH(cell, titleView, urlView)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.titleView.text = if (item.title.isNotBlank()) item.title else item.url
        holder.urlView.text = item.url
        holder.cell.setOnClickListener { onOpen(item) }
        // nút đóng (X) là view con thứ 2 của cell (con 0 = nội dung, con 1 = nút đóng)
        (holder.cell.getChildAt(1) as? TextView)?.setOnClickListener {
            onClose(holder.adapterPosition)
        }
    }

    override fun getItemCount(): Int = items.size
}
