package com.h.adblockbrowser

/** Tự động dịch MỌI trang (bất kể ngôn ngữ gốc là gì) sang tiếng Việt bằng widget "Google Dịch
 *  trang web" chính chủ của Google (translate.google.com/translate_a/element.js) - không cần API
 *  key riêng. Dùng pageLanguage "auto" để Google tự nhận diện đúng ngôn ngữ gốc của từng trang -
 *  nếu trang đã là tiếng Việt, Google tự nhận ra và không dịch (dịch việt->việt không đổi gì).
 *  Tự ẩn khung/thanh giao diện RIÊNG của widget này (khung chọn ngôn ngữ, banner "Đã dịch sang...")
 *  - nó chỉ cần chạy NGẦM để dịch nội dung, không cần hiện khung riêng đè lên trang.
 *
 *  SỬA LỖI: bản trước chỉ ẩn bằng CSS chọn đúng vài class cố định (.goog-te-banner-frame...),
 *  nhưng Google thỉnh thoảng đổi cấu trúc DOM hoặc banner render trước khi CSS kịp áp dụng, khiến
 *  banner trắng "Được dịch sang:..." vẫn lọt ra ngoài. Giờ dùng MutationObserver để CHỦ ĐỘNG xoá
 *  (không chỉ ẩn) bất kỳ phần tử nào Google chèn vào - iframe id bắt đầu bằng "goog-gt-"/"goog-te-",
 *  hoặc mang class "skiptranslate" - ngay khi nó vừa xuất hiện trong DOM, đồng thời liên tục ép
 *  <html> và <body> về top/margin = 0 (Google có bản đẩy <html>, có bản đẩy <body> tuỳ phiên bản). */
object TranslateInjector {
    const val JS = """
        (function() {
            if (window.__translateInjected) return;
            window.__translateInjected = true;

            var style = document.createElement('style');
            style.innerHTML =
                '.goog-te-banner-frame, .goog-te-balloon-frame, #goog-gt-tt, .goog-tooltip, ' +
                '.goog-te-menu-value, iframe.goog-te-menu-frame, .skiptranslate iframe, ' +
                'iframe[id^="goog-gt-"], iframe[id^="goog-te-"] { ' +
                'display: none !important; visibility: hidden !important; height: 0 !important; }' +
                'html, body { top: 0px !important; margin-top: 0px !important; position: static !important; }' +
                '.goog-text-highlight { background: none !important; box-shadow: none !important; }' +
                '#google_translate_element { display: none !important; }';
            document.head.appendChild(style);

            function nukeBanner() {
                document.documentElement.style.top = '0px';
                document.documentElement.style.marginTop = '0px';
                document.body.style.top = '0px';
                document.body.style.marginTop = '0px';
                var sels = [
                    'iframe.goog-te-banner-frame', 'iframe[id^="goog-gt-"]', 'iframe[id^="goog-te-"]',
                    '.goog-te-banner-frame', '.goog-te-balloon-frame', '#goog-gt-tt'
                ];
                sels.forEach(function(sel) {
                    document.querySelectorAll(sel).forEach(function(el) {
                        if (el && el.parentNode) el.parentNode.removeChild(el);
                    });
                });
            }

            // Xoá ngay bất cứ khi nào Google chèn thêm phần tử mới vào <body>/<html>, thay vì chỉ
            // dựa vào 1 vòng lặp setInterval như trước (vốn có độ trễ tối đa 300ms mỗi lần kiểm).
            var observer = new MutationObserver(nukeBanner);
            observer.observe(document.documentElement, { childList: true, subtree: true });

            var div = document.createElement('div');
            div.id = 'google_translate_element';
            div.style.display = 'none';
            document.body.appendChild(div);

            window.googleTranslateElementInit = function() {
                try {
                    new google.translate.TranslateElement(
                        { pageLanguage: 'auto', includedLanguages: 'vi', autoDisplay: false },
                        'google_translate_element'
                    );
                    var tries = 0;
                    var timer = setInterval(function() {
                        tries++;
                        var combo = document.querySelector('.goog-te-combo');
                        if (combo) {
                            combo.value = 'vi';
                            combo.dispatchEvent(new Event('change'));
                            clearInterval(timer);
                        } else if (tries > 20) {
                            clearInterval(timer);
                        }
                        nukeBanner();
                    }, 300);
                } catch (e) {}
            };

            var script = document.createElement('script');
            script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            document.body.appendChild(script);
        })();
    """
}
