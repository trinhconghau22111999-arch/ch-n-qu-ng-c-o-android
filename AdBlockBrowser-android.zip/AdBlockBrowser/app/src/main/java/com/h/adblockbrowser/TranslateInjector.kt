package com.h.adblockbrowser

/** Tự động dịch MỌI trang (bất kể ngôn ngữ gốc là gì) sang tiếng Việt bằng widget "Google Dịch
 *  trang web" chính chủ của Google (translate.google.com/translate_a/element.js) - không cần API
 *  key riêng. Dùng pageLanguage "auto" để Google tự nhận diện đúng ngôn ngữ gốc của từng trang -
 *  nếu trang đã là tiếng Việt, Google tự nhận ra và không dịch (dịch việt->việt không đổi gì).
 *  Tự ẩn khung/thanh giao diện RIÊNG của widget này (khung chọn ngôn ngữ, banner "Đã dịch sang...")
 *  - nó chỉ cần chạy NGẦM để dịch nội dung, không cần hiện khung riêng đè lên trang (đúng lỗi
 *  thấy ở Zalo: 1 khung nhỏ che góc trái trên màn hình). */
object TranslateInjector {
    const val JS = """
        (function() {
            if (window.__translateInjected) return;
            window.__translateInjected = true;

            var style = document.createElement('style');
            style.innerHTML =
                '.goog-te-banner-frame, .goog-te-balloon-frame, #goog-gt-tt, .goog-tooltip, ' +
                '.goog-te-menu-value, iframe.goog-te-menu-frame { display: none !important; visibility: hidden !important; }' +
                'body { top: 0px !important; position: static !important; }' +
                '.goog-text-highlight { background: none !important; box-shadow: none !important; }' +
                '#google_translate_element { display: none !important; }';
            document.head.appendChild(style);

            var div = document.createElement('div');
            div.id = 'google_translate_element';
            div.style.display = 'none';
            document.body.appendChild(div);

            window.googleTranslateElementInit = function() {
                try {
                    new google.translate.TranslateElement(
                        { pageLanguage: 'auto', includedLanguages: 'vi', autoDisplay: false },
                        'google_translate_element'
                    );
                    var tries = 0;
                    var timer = setInterval(function() {
                        tries++;
                        var combo = document.querySelector('.goog-te-combo');
                        if (combo) {
                            combo.value = 'vi';
                            combo.dispatchEvent(new Event('change'));
                            clearInterval(timer);
                        } else if (tries > 20) {
                            clearInterval(timer);
                        }
                        // Google tự chèn banner + đẩy body xuống - dọn lại liên tục để không bị
                        // đè lên giao diện trang (đặc biệt các trang tự dựng UI riêng như Zalo).
                        document.body.style.top = '0px';
                        var banner = document.querySelector('.goog-te-banner-frame');
                        if (banner) banner.style.display = 'none';
                    }, 300);
                } catch (e) {}
            };

            var script = document.createElement('script');
            script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            document.body.appendChild(script);
        })();
    """
}
