package com.h.adblockbrowser

/** Tự động dịch MỌI trang (bất kể ngôn ngữ gốc là gì) sang tiếng Việt bằng widget "Google Dịch
 *  trang web" chính chủ của Google (translate.google.com/translate_a/element.js) - không cần API
 *  key riêng. Dùng pageLanguage "auto" để Google tự nhận diện đúng ngôn ngữ gốc của từng trang -
 *  nếu trang đã là tiếng Việt, Google tự nhận ra và không dịch (dịch việt->việt không đổi gì). */
object TranslateInjector {
    const val JS = """
        (function() {
            if (window.__translateInjected) return;
            window.__translateInjected = true;

            var div = document.createElement('div');
            div.id = 'google_translate_element';
            div.style.display = 'none';
            document.body.appendChild(div);

            window.googleTranslateElementInit = function() {
                try {
                    new google.translate.TranslateElement(
                        { pageLanguage: 'auto', includedLanguages: 'vi', autoDisplay: false },
                        'google_translate_element'
                    );
                    var tries = 0;
                    var timer = setInterval(function() {
                        tries++;
                        var combo = document.querySelector('.goog-te-combo');
                        if (combo) {
                            combo.value = 'vi';
                            combo.dispatchEvent(new Event('change'));
                            clearInterval(timer);
                        } else if (tries > 20) {
                            clearInterval(timer);
                        }
                    }, 300);
                } catch (e) {}
            };

            var script = document.createElement('script');
            script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            document.body.appendChild(script);
        })();
    """
}
