package com.h.adblockbrowser

/** Tự động dịch trang tiếng Anh sang tiếng Việt bằng widget "Google Dịch trang web" chính chủ của
 *  Google (translate.google.com/translate_a/element.js) - không cần API key riêng. Chỉ kích hoạt
 *  khi trang tự khai báo ngôn ngữ là tiếng Anh (thẻ <html lang="en">) - trang không khai báo hoặc
 *  khai báo ngôn ngữ khác thì bỏ qua, tránh dịch nhầm trang đã là tiếng Việt. */
object TranslateInjector {
    const val JS = """
        (function() {
            if (window.__translateInjected) return;
            var lang = (document.documentElement.lang || '').toLowerCase();
            if (lang.indexOf('en') !== 0) return;
            window.__translateInjected = true;

            var div = document.createElement('div');
            div.id = 'google_translate_element';
            div.style.display = 'none';
            document.body.appendChild(div);

            window.googleTranslateElementInit = function() {
                try {
                    new google.translate.TranslateElement(
                        { pageLanguage: 'en', includedLanguages: 'vi', autoDisplay: false },
                        'google_translate_element'
                    );
                    var tries = 0;
                    var timer = setInterval(function() {
                        tries++;
                        var combo = document.querySelector('.goog-te-combo');
                        if (combo) {
                            combo.value = 'vi';
                            combo.dispatchEvent(new Event('change'));
                            clearInterval(timer);
                        } else if (tries > 20) {
                            clearInterval(timer);
                        }
                    }, 300);
                } catch (e) {}
            };

            var script = document.createElement('script');
            script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            document.body.appendChild(script);
        })();
    """
}
