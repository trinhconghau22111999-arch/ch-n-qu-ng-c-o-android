package com.h.adblockbrowser

import android.content.Context

/** Đăng ký trạng thái 8 "web" (tab) của Đa tab - mỗi tab chạy 1 tiến trình riêng, nên không thể
 *  giữ danh sách tab trong bộ nhớ RAM của 1 Activity như trước (mỗi tiến trình có RAM riêng).
 *  Dùng SharedPreferences (dùng chung được giữa mọi tiến trình cùng app) để mọi tab đều biết
 *  đủ 8 tab đang mở gì, hiển thị đúng thanh tab giống hệt giao diện cũ. */
object MultiTabSlotsStore {
    const val MAX_SLOTS = 8
    private const val PREFS = "multitab_slots"

    data class Slot(val index: Int, val used: Boolean, val url: String, val title: String)

    fun loadAll(context: Context): List<Slot> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return (0 until MAX_SLOTS).map { i ->
            val used = p.getBoolean("used_$i", false)
            val url = p.getString("url_$i", "") ?: ""
            val title = p.getString("title_$i", "Tab mới") ?: "Tab mới"
            Slot(i, used, url, title)
        }
    }

    fun update(context: Context, index: Int, url: String, title: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("used_$index", true)
            .putString("url_$index", url)
            .putString("title_$index", title)
            .apply()
    }

    fun clear(context: Context, index: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("used_$index", false)
            .remove("url_$index")
            .remove("title_$index")
            .apply()
    }

    /** Tìm 1 slot trống (0..7) để mở tab mới, null nếu đã đủ 8 */
    fun findFreeSlot(context: Context): Int? =
        loadAll(context).firstOrNull { !it.used }?.index

    /** Tên đầy đủ của activity-alias ứng với từng slot (dùng để startActivity đúng tiến trình) */
    fun aliasComponent(context: Context, index: Int): android.content.ComponentName =
        android.content.ComponentName(context.packageName, "com.h.adblockbrowser.MultiTabSlot$index")
}
