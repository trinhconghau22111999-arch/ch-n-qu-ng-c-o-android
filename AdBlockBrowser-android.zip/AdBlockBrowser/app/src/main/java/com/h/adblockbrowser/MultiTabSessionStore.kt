package com.h.adblockbrowser

import android.content.Context

/** Danh sách URL các tab đang mở của "Đa tab" - LƯU LÂU DÀI, để thoát app vào lại các tab cũ
 *  vẫn còn nguyên (không giống Ẩn danh - Ẩn danh thoát ra là mất hết). */
object MultiTabSessionStore {
    private const val PREFS = "multitab_session"
    private const val KEY = "urls"

    fun load(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("\n").filter { it.isNotBlank() }
    }

    fun save(context: Context, urls: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, urls.joinToString("\n")).apply()
    }
}
