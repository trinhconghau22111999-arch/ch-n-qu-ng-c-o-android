package com.h.adblockbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class FloatingNavBar(
    private val context: Context,
    private val onMultitask: () -> Unit,
    private val onHome: () -> Unit,
    private val onBack: () -> Unit
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floating_nav_prefs", 0)

    private lateinit var bar: LinearLayout
    private lateinit var container: FrameLayout

    private var isDragging = false
    private val longPressHandler = Handler(Looper.getMainLooper())
    private var downRawX = 0f
    private var downRawY = 0f
    private var barOffsetX = 0f
    private var barOffsetY = 0f

    fun attachTo(root: FrameLayout) {
        container = root
        bar = buildBar()
        root.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        restorePosition()
        setupDrag()
    }

    private fun buildBar(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(36).toFloat()
                // Nền đen sâu
                setColor(0xF5050505.toInt())
                setStroke(dp(1), 0xFF1A1A1A.toInt())
            }
            elevation = dp(12).toFloat()

            addView(buildBtn("⚡", "Đa nhiệm") { if (!isDragging) onMultitask() })
            addView(buildSep())
            addView(buildBtn("⌁", "Home") { if (!isDragging) onHome() })
            addView(buildSep())
            addView(buildBtn("‹", "Back") { if (!isDragging) onBack() })
        }
    }

    private fun buildBtn(icon: String, desc: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = icon
            textSize = 22f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            contentDescription = desc
            setPadding(dp(16), dp(12), dp(16), dp(12))
            isClickable = true
            isFocusable = true
            // Ripple bo tròn
            background = TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildSep(): View = View(context).apply {
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).also {
            it.setMargins(0, 0, 0, 0)
        }
        setBackgroundColor(0x33FFFFFF)
    }

    private fun setupDrag() {
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    barOffsetX = event.rawX - bar.x
                    barOffsetY = event.rawY - bar.y
                    isDragging = false

                    longPressHandler.postDelayed({
                        isDragging = true
                        bar.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                        bar.animate().scaleX(0.92f).scaleY(0.92f).setDuration(120).start()
                    }, 2000)
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dist = Math.hypot(
                        (event.rawX - downRawX).toDouble(),
                        (event.rawY - downRawY).toDouble()
                    )
                    if (!isDragging && dist > dp(10)) {
                        longPressHandler.removeCallbacksAndMessages(null)
                    }
                    if (isDragging) {
                        // Cho phép kéo sát hoàn toàn 2 cạnh trái/phải (x có thể âm 1 nửa)
                        val halfW = bar.width / 2f
                        val newX = (event.rawX - barOffsetX)
                            .coerceIn(-halfW, container.width - halfW)
                        val newY = (event.rawY - barOffsetY)
                            .coerceIn(0f, (container.height - bar.height).toFloat())
                        bar.x = newX
                        bar.y = newY
                        true
                    } else false
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        // Snap sát cạnh nếu kéo quá gần
                        val midScreen = container.width / 2f
                        if (bar.x + bar.width / 2f < midScreen) {
                            bar.animate().x(-bar.width / 2f + dp(8).toFloat()).setDuration(150).start()
                            savePosition(-bar.width / 2f + dp(8).toFloat(), bar.y)
                        } else {
                            val snapX = container.width - bar.width / 2f - dp(8).toFloat()
                            bar.animate().x(snapX).setDuration(150).start()
                            savePosition(snapX, bar.y)
                        }
                        isDragging = false
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun savePosition(x: Float, y: Float) {
        prefs.edit().putFloat("x", x).putFloat("y", y).apply()
    }

    private fun restorePosition() {
        bar.post {
            val screenW = container.width.toFloat()
            val screenH = container.height.toFloat()
            val defaultX = (screenW - bar.width) / 2f
            val defaultY = screenH - bar.height - dp(80)
            bar.x = prefs.getFloat("x", defaultX)
            bar.y = prefs.getFloat("y", defaultY)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
