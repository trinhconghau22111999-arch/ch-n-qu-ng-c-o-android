package com.h.adblockbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Thanh đa nhiệm (Đa nhiệm / Home / Back) - đụng sát 2 cạnh trái-phải màn hình (full-width),
 *  3 nút chia đều khoảng cách bằng nhau (layout_weight), KHÔNG còn nền đen bao quanh cả dãy nữa -
 *  chỉ 3 nút icon nổi trực tiếp trên hình nền/trang web. Home dùng CÙNG icon 3 gạch (☰) như nút
 *  Đa nhiệm nhưng khung hình VUÔNG (bo góc nhẹ) để phân biệt - thay vì hình tròn trơn như trước.
 *  Mặc định thanh nằm SÁT CẠNH DƯỚI màn hình. Vẫn kéo được lên/xuống (giữ 2 giây), chỉ trên trục
 *  dọc - không kéo ngang vì thanh đã cố định chạm 2 cạnh màn hình rồi. */
class FloatingNavBar(
    private val context: Context,
    private val onMultitask: () -> Unit,
    private val onHome: () -> Unit,
    private val onBack: () -> Unit
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floating_nav_prefs", 0)

    private lateinit var container: FrameLayout
    internal lateinit var bar: LinearLayout

    private var isDragging = false
    private val longPressHandler = Handler(Looper.getMainLooper())
    private var downRawY = 0f
    private var barOffsetY = 0f

    fun getBar(): LinearLayout? = if (::bar.isInitialized) bar else null

    fun attachTo(root: FrameLayout) {
        container = root
        bar = buildBar()
        root.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        restorePosition()
        setupDrag()
    }

    private fun buildBar(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            background = null
            elevation = 0f

            // 3 nút chia đều weight=1, mỗi nút 48×48dp căn giữa trong ô
            addView(buildIconBtn("☰", "Đa nhiệm", filled = true, square = false) { if (!isDragging) onMultitask() }, weightParams())
            addView(buildIconBtn("☰", "Home", filled = true, square = true) { if (!isDragging) onHome() }, weightParams())
            addView(buildIconBtn("<<<", "Back", filled = true, square = false, size = 13f) { if (!isDragging) onBack() }, weightParams())
        }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
        it.gravity = Gravity.CENTER
    }

    /** 1 kiểu nút DÙNG CHUNG cho cả 3 nút - cùng kích thước/padding/chữ, chỉ khác màu + hình dạng:
     *  Home (square=true) dùng khung VUÔNG bo góc để phân biệt với 2 nút tròn còn lại, và tô
     *  trắng nổi bật (filled=true) vì là nút chính - vẫn dùng chung icon 3 gạch (☰) với Đa nhiệm
     *  theo đúng yêu cầu "y chang nút 3 gạch nhưng là ô vuông". */
    private fun buildIconBtn(icon: String, desc: String, filled: Boolean, square: Boolean, size: Float = 20f, onClick: () -> Unit): View {
        val wrapper = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(dp(48), dp(48))
        }
        val btn = TextView(context).apply {
            text = icon
            textSize = size
            gravity = Gravity.CENTER
            contentDescription = desc
            isClickable = true
            isFocusable = true
            layoutParams = FrameLayout.LayoutParams(dp(48), dp(48))
            val shapeDrawable = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = if (square) dp(12).toFloat() else dp(24).toFloat() // vuông bo góc nhẹ vs tròn hẳn
            }
            if (filled) {
                setTextColor(0xFF111111.toInt())
                shapeDrawable.setColor(0xFFFFFFFF.toInt())
                shapeDrawable.setStroke(dp(2), 0xFF333333.toInt())
            } else {
                setTextColor(0xFFDDDDDD.toInt())
                shapeDrawable.setColor(0x00000000)
                shapeDrawable.setStroke(dp(1), 0xFF2A2A2A.toInt())
            }
            background = shapeDrawable
            setOnClickListener { onClick() }
            foreground = TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }
        wrapper.addView(btn)
        return wrapper
    }

    private fun setupDrag() {
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    barOffsetY = event.rawY - bar.y
                    isDragging = false

                    longPressHandler.postDelayed({
                        isDragging = true
                        bar.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                        bar.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start()
                    }, 2000)
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dist = Math.abs(event.rawY - downRawY)
                    if (!isDragging && dist > dp(10)) {
                        longPressHandler.removeCallbacksAndMessages(null)
                    }
                    if (isDragging) {
                        // Chỉ kéo theo trục dọc - thanh luôn giữ nguyên chạm đủ 2 cạnh trái/phải.
                        val newY = (event.rawY - barOffsetY)
                            .coerceIn(0f, (container.height - bar.height).toFloat())
                        bar.y = newY
                        true
                    } else false
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        savePosition(bar.y)
                        isDragging = false
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun savePosition(y: Float) {
        prefs.edit().putFloat("y_v2", y).apply()
    }

    private fun restorePosition() {
        bar.post {
            val defaultY = container.height.toFloat() - bar.height
            bar.x = 0f  // MATCH_PARENT nên x=0, weight tự chia đều 3 nút
            bar.y = prefs.getFloat("y_v2", defaultY)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
