package com.h.adblockbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Thanh đa nhiệm (Đa nhiệm / Home / Back) - đụng sát 2 cạnh trái-phải màn hình (full-width),
 *  3 nút chia đều khoảng cách bằng nhau (layout_weight), CÙNG kiểu nút tròn (oval) đồng nhất -
 *  Home dùng màu trắng nổi bật (nút chính), Đa nhiệm/Back dùng viền tối cùng kích thước để
 *  cả 3 nhìn "đều" với nhau, chỉ khác màu nhấn. Vẫn kéo được lên/xuống (giữ 2 giây), chỉ trên
 *  trục dọc - không kéo ngang nữa vì thanh đã cố định chạm 2 cạnh màn hình rồi. */
class FloatingNavBar(
    private val context: Context,
    private val onMultitask: () -> Unit,
    private val onHome: () -> Unit,
    private val onBack: () -> Unit
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floating_nav_prefs", 0)

    private lateinit var bar: LinearLayout
    private lateinit var container: FrameLayout

    private var isDragging = false
    private val longPressHandler = Handler(Looper.getMainLooper())
    private var downRawY = 0f
    private var barOffsetY = 0f

    fun attachTo(root: FrameLayout) {
        container = root
        bar = buildBar()
        root.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        restorePosition()
        setupDrag()
    }

    private fun buildBar(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(0xF5050505.toInt())
                setStroke(dp(1), 0xFF1A1A1A.toInt())
            }
            elevation = dp(12).toFloat()

            addView(buildCircleBtn("☰", "Đa nhiệm", filled = false) { if (!isDragging) onMultitask() }, weightParams())
            addView(buildCircleBtn("⬤", "Home", filled = true) { if (!isDragging) onHome() }, weightParams())
            addView(buildCircleBtn("‹", "Back", filled = false) { if (!isDragging) onBack() }, weightParams())
        }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
        it.gravity = Gravity.CENTER
    }

    /** 1 kiểu nút tròn DÙNG CHUNG cho cả 3 nút - cùng kích thước/padding/chữ, chỉ khác màu:
     *  Home (filled=true) tô trắng nổi bật vì là nút chính, 2 nút còn lại viền tối hoà cùng nền
     *  thanh - nhìn "đều" với nhau nhưng vẫn phân biệt được Home là nút quan trọng nhất. */
    private fun buildCircleBtn(icon: String, desc: String, filled: Boolean, onClick: () -> Unit): View {
        val wrapper = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(dp(48), dp(48))
        }
        val circle = TextView(context).apply {
            text = icon
            textSize = 20f
            gravity = Gravity.CENTER
            contentDescription = desc
            isClickable = true
            isFocusable = true
            layoutParams = FrameLayout.LayoutParams(dp(48), dp(48))
            if (filled) {
                setTextColor(0xFF111111.toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFFFFFFFF.toInt())
                    setStroke(dp(2), 0xFF333333.toInt())
                }
            } else {
                setTextColor(0xFFDDDDDD.toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0x00000000)
                    setStroke(dp(1), 0xFF2A2A2A.toInt())
                }
            }
            setOnClickListener { onClick() }
            foreground = TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }
        wrapper.addView(circle)
        return wrapper
    }

    private fun setupDrag() {
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    barOffsetY = event.rawY - bar.y
                    isDragging = false

                    longPressHandler.postDelayed({
                        isDragging = true
                        bar.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                        bar.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start()
                    }, 2000)
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dist = Math.abs(event.rawY - downRawY)
                    if (!isDragging && dist > dp(10)) {
                        longPressHandler.removeCallbacksAndMessages(null)
                    }
                    if (isDragging) {
                        // Chỉ kéo theo trục dọc - thanh luôn giữ nguyên chạm đủ 2 cạnh trái/phải.
                        val newY = (event.rawY - barOffsetY)
                            .coerceIn(0f, (container.height - bar.height).toFloat())
                        bar.y = newY
                        true
                    } else false
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        savePosition(bar.y)
                        isDragging = false
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun savePosition(y: Float) {
        prefs.edit().putFloat("y", y).apply()
    }

    private fun restorePosition() {
        bar.post {
            val screenH = container.height.toFloat()
            val defaultY = screenH - bar.height - dp(80)
            bar.x = 0f
            bar.y = prefs.getFloat("y", defaultY)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
