package com.h.adblockbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Thanh đa nhiệm (Đa nhiệm / Home / Back) - đụng sát 2 cạnh trái-phải màn hình (full-width),
 *  3 nút chia đều khoảng cách bằng nhau (layout_weight), KHÔNG còn nền đen bao quanh cả dãy nữa -
 *  chỉ 3 nút icon nổi trực tiếp trên hình nền/trang web. Home dùng CÙNG icon 3 gạch (☰) như nút
 *  Đa nhiệm nhưng khung hình VUÔNG (bo góc nhẹ) để phân biệt - thay vì hình tròn trơn như trước.
 *  Mặc định thanh nằm SÁT CẠNH DƯỚI màn hình. Vẫn kéo được lên/xuống (giữ 2 giây), chỉ trên trục
 *  dọc - không kéo ngang vì thanh đã cố định chạm 2 cạnh màn hình rồi. */
class FloatingNavBar(
    private val context: Context,
    private val onMultitask: () -> Unit,
    private val onHome: () -> Unit,
    private val onBack: () -> Unit
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floating_nav_prefs", 0)

    private lateinit var container: FrameLayout
    internal lateinit var bar: LinearLayout

    private var isDragging = false
    private val longPressHandler = Handler(Looper.getMainLooper())
    private var downRawY = 0f
    private var barOffsetY = 0f

    fun getBar(): LinearLayout? = if (::bar.isInitialized) bar else null

    fun attachTo(root: FrameLayout) {
        container = root
        bar = buildBar()
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(bar, lp)
        bar.translationZ = 100f   // đảm bảo bar luôn nằm TRÊN WebView trong Z-order
        bar.bringToFront()        // đưa lên top của parent view
        restorePosition()
        setupDrag()
    }

    private fun buildBar(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            // Dải nền mờ phía sau 3 nút - không để trong suốt hoàn toàn như trước nữa, vì trên
            // các trang nội dung dày đặc (Shopee...) nền web xuyên thẳng qua làm khó phân biệt
            // đâu là nút bấm của app. Dùng nền đen mờ + góc bo nhẹ, đủ mờ để không che trang web
            // phía dưới nhưng vẫn tạo 1 dải nền rõ ràng ngăn cách 3 nút với nội dung trang.
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(20).toFloat()
                setColor(0x66000000)
            }
            elevation = dp(4).toFloat()

            // 3 nút chia đều weight=1, mỗi nút 48×48dp căn giữa trong ô
            addView(buildIconBtn("☰", "Đa nhiệm", filled = true, square = false) { if (!isDragging) onMultitask() }, weightParams())
            addView(buildIconBtn("☰", "Home", filled = true, square = true) { if (!isDragging) onHome() }, weightParams())
            addView(buildIconBtn("<<<", "Back", filled = true, square = false, size = 13f) { if (!isDragging) onBack() }, weightParams())
        }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
        it.gravity = Gravity.CENTER
    }

    private fun buildIconBtn(icon: String, desc: String, filled: Boolean, square: Boolean, size: Float = 20f, onClick: () -> Unit): View {
        return TextView(context).apply {
            text = icon
            textSize = size
            gravity = Gravity.CENTER
            contentDescription = desc
            isClickable = true
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).also {
                it.gravity = Gravity.CENTER
            }
            val shapeDrawable = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = if (square) dp(12).toFloat() else dp(26).toFloat()
            }
            if (filled) {
                setTextColor(0xFF111111.toInt())
                shapeDrawable.setColor(0xFFFFFFFF.toInt())
                shapeDrawable.setStroke(dp(2), 0xFF333333.toInt())
            } else {
                setTextColor(0xFFDDDDDD.toInt())
                shapeDrawable.setColor(0x00000000)
                shapeDrawable.setStroke(dp(1), 0xFF2A2A2A.toInt())
            }
            background = shapeDrawable
            setOnClickListener { onClick() }
            foreground = TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
        }
    }

    private fun setupDrag() {
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    // Nếu chạm vào nút con → nhường cho nút xử lý click
                    if (isTouchOnAnyChild(event)) return@setOnTouchListener false

                    downRawY = event.rawY
                    barOffsetY = event.rawY - bar.y
                    isDragging = false
                    longPressHandler.postDelayed({
                        isDragging = true
                        bar.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                        bar.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start()
                    }, 2000)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dist = Math.abs(event.rawY - downRawY)
                    if (!isDragging && dist > dp(10)) longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.y = (event.rawY - barOffsetY).coerceIn(0f, (container.height - bar.height).toFloat())
                        true
                    } else false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        savePosition(bar.y)
                        isDragging = false
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    // Kiểm tra điểm chạm (tính theo toạ độ trong hệ của `bar`) có rơi đúng vào 1 trong 3 nút
    // con hay không, để quyết định có nên nhường quyền xử lý cho nút đó hay không.
    private fun isTouchOnAnyChild(event: MotionEvent): Boolean {
        val rect = android.graphics.Rect()
        for (i in 0 until bar.childCount) {
            val child = bar.getChildAt(i)
            child.getHitRect(rect)
            if (rect.contains(event.x.toInt(), event.y.toInt())) return true
        }
        return false
    }

    private fun savePosition(y: Float) {
        prefs.edit().putFloat("y_v2", y).apply()
    }

    private fun restorePosition() {
        bar.post {
            val defaultY = container.height.toFloat() - bar.height
            bar.x = 0f  // MATCH_PARENT nên x=0, weight tự chia đều 3 nút
            bar.y = prefs.getFloat("y_v2", defaultY)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
