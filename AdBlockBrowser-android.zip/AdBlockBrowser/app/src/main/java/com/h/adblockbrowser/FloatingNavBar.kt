package com.h.adblockbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/**
 * Thanh đa nhiệm nổi hình thước kẻ, kéo được đến mọi vị trí.
 * - Nhấn giữ 2 giây để bắt đầu kéo (rung nhẹ, icon thu nhỏ)
 * - Thả ra → lưu vị trí vào SharedPreferences
 * - 4 nút: Đa nhiệm | Mở app | Home | Back
 */
class FloatingNavBar(
    private val context: Context,
    private val onMultitask: () -> Unit,
    private val onApps: () -> Unit,
    private val onHome: () -> Unit,
    private val onBack: () -> Unit
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("floating_nav_prefs", 0)

    private lateinit var bar: LinearLayout
    private lateinit var container: FrameLayout  // root FrameLayout của activity

    private var isDragging = false
    private var longPressTriggered = false
    private val longPressHandler = Handler(Looper.getMainLooper())
    private var downRawX = 0f
    private var downRawY = 0f
    private var barOffsetX = 0f   // offset con trỏ so với góc trái bar khi bắt đầu kéo
    private var barOffsetY = 0f

    fun attachTo(root: FrameLayout) {
        container = root
        bar = buildBar()
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(bar, lp)
        restorePosition()
        setupDrag()
    }

    // ---------- Xây thanh ----------

    private fun buildBar(): LinearLayout {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(30).toFloat()
                setColor(0xE6111111.toInt())
                setStroke(dp(1), 0xFF333333.toInt())
            }
            elevation = dp(8).toFloat()
        }

        bar.addView(buildBtn("⚡", "Đa nhiệm") { if (!isDragging) onMultitask() })
        bar.addView(buildDivider())
        bar.addView(buildBtn("⊞", "Mở app") { if (!isDragging) onApps() })
        bar.addView(buildDivider())
        bar.addView(buildBtn("⌂", "Home") { if (!isDragging) onHome() })
        bar.addView(buildDivider())
        bar.addView(buildBtn("◀", "Back") { if (!isDragging) onBack() })

        return bar
    }

    private fun buildBtn(text: String, desc: String, onClick: () -> Unit): View {
        return android.widget.TextView(context).apply {
            this.text = text
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = desc
            setPadding(dp(14), dp(10), dp(14), dp(10))
            isClickable = true
            isFocusable = true
            background = TypedValue().let {
                context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
                context.getDrawable(it.resourceId)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildDivider(): View = View(context).apply {
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(24)).also {
            it.setMargins(dp(2), 0, dp(2), 0)
        }
        setBackgroundColor(0x44FFFFFF)
    }

    // ---------- Kéo thả ----------

    private fun setupDrag() {
        bar.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    barOffsetX = event.rawX - bar.x
                    barOffsetY = event.rawY - bar.y
                    longPressTriggered = false
                    isDragging = false

                    // Lên lịch long-press 2 giây
                    longPressHandler.postDelayed({
                        longPressTriggered = true
                        isDragging = true
                        // Phản hồi rung + thu nhỏ nhẹ
                        bar.performHapticFeedback(
                            android.view.HapticFeedbackConstants.LONG_PRESS
                        )
                        bar.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100).start()
                    }, 2000)
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    if (isDragging) {
                        val newX = (event.rawX - barOffsetX)
                            .coerceIn(0f, (container.width - bar.width).toFloat())
                        val newY = (event.rawY - barOffsetY)
                            .coerceIn(0f, (container.height - bar.height).toFloat())
                        bar.x = newX
                        bar.y = newY
                        true
                    } else {
                        // Huỷ long-press nếu ngón tay trượt quá 10dp
                        val dist = Math.hypot(
                            (event.rawX - downRawX).toDouble(),
                            (event.rawY - downRawY).toDouble()
                        )
                        if (dist > dp(10)) longPressHandler.removeCallbacksAndMessages(null)
                        false
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressHandler.removeCallbacksAndMessages(null)
                    if (isDragging) {
                        bar.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        savePosition(bar.x, bar.y)
                        isDragging = false
                        true   // tiêu thụ event -> không kích hoạt click
                    } else {
                        false
                    }
                }

                else -> false
            }
        }
    }

    // ---------- Lưu / phục hồi vị trí ----------

    private fun savePosition(x: Float, y: Float) {
        prefs.edit().putFloat("x", x).putFloat("y", y).apply()
    }

    private fun restorePosition() {
        // Đặt mặc định ở giữa dưới màn hình, chờ layout xong mới đọc kích thước
        bar.post {
            val screenW = container.width.toFloat()
            val screenH = container.height.toFloat()
            val defaultX = (screenW - bar.width) / 2f
            val defaultY = screenH - bar.height - dp(16)
            bar.x = prefs.getFloat("x", defaultX)
            bar.y = prefs.getFloat("y", defaultY)
        }
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
