package com.h.adblockbrowser

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Một "khối" nội dung trong tài liệu - hoặc là 1 đoạn văn bản, hoặc là 1 ảnh chèn vào giữa văn
 *  bản (giữ đúng thứ tự xuất hiện, giống Word). */
data class DocBlock(val type: String, val text: String? = null, val imagePath: String? = null)
data class DocMeta(val id: String, val title: String, val updatedAt: Long)

/** Lưu tài liệu/ghi chú xuống bộ nhớ trong của app (KHÔNG dùng MediaStore vì đây là dữ liệu riêng
 *  của app, không phải ảnh/video/nhạc). Dùng chung 1 định dạng cho cả "Soạn thảo văn bản" (bucket
 *  "docs") và "Ghi chú" (bucket "notes") - 2 danh sách tách biệt nhau qua tên bucket. */
object DocumentStore {

    private fun prefs(context: Context) = context.getSharedPreferences("documents_index", Context.MODE_PRIVATE)
    private fun docsDir(context: Context) = File(context.filesDir, "documents").apply { mkdirs() }
    private fun imagesDir(context: Context) = File(context.filesDir, "doc_images").apply { mkdirs() }

    fun newId(): String = System.currentTimeMillis().toString()

    fun list(context: Context, bucket: String): List<DocMeta> {
        val raw = prefs(context).getString("index_$bucket", null) ?: return emptyList()
        val result = ArrayList<DocMeta>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(DocMeta(o.getString("id"), o.getString("title"), o.getLong("updatedAt")))
            }
        } catch (e: Exception) { }
        return result.sortedByDescending { it.updatedAt }
    }

    fun loadBlocks(context: Context, id: String): List<DocBlock> {
        val file = File(docsDir(context), "$id.json")
        if (!file.exists()) return emptyList()
        val result = ArrayList<DocBlock>()
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(DocBlock(o.getString("type"), o.optString("text").ifEmpty { null }, o.optString("imagePath").ifEmpty { null }))
            }
        } catch (e: Exception) { }
        return result
    }

    fun save(context: Context, bucket: String, id: String, title: String, blocks: List<DocBlock>) {
        try {
            val file = File(docsDir(context), "$id.json")
            val arr = JSONArray()
            for (b in blocks) {
                val o = JSONObject()
                o.put("type", b.type)
                if (b.text != null) o.put("text", b.text)
                if (b.imagePath != null) o.put("imagePath", b.imagePath)
                arr.put(o)
            }
            file.writeText(arr.toString())

            val finalTitle = title.ifBlank { "Không tiêu đề" }
            val list = list(context, bucket).filter { it.id != id }.toMutableList()
            list.add(0, DocMeta(id, finalTitle, System.currentTimeMillis()))
            writeIndex(context, bucket, list)
        } catch (e: Exception) { }
    }

    fun delete(context: Context, bucket: String, id: String) {
        File(docsDir(context), "$id.json").delete()
        writeIndex(context, bucket, list(context, bucket).filter { it.id != id })
    }

    private fun writeIndex(context: Context, bucket: String, list: List<DocMeta>) {
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("id", m.id); o.put("title", m.title); o.put("updatedAt", m.updatedAt)
            arr.put(o)
        }
        prefs(context).edit().putString("index_$bucket", arr.toString()).apply()
    }

    /** Lưu 1 bản sao ảnh đã chèn vào thư mục riêng của app - trả về đường dẫn tệp để gắn vào
     *  DocBlock. Nén JPEG chất lượng 85 để tài liệu không quá nặng. */
    fun saveImage(context: Context, bitmap: Bitmap): String {
        val file = File(imagesDir(context), "img_${System.currentTimeMillis()}_${(0..999).random()}.jpg")
        FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out) }
        return file.absolutePath
    }
}
