package com.h.adblockbrowser

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** "Đa tab" - GIAO DIỆN giữ y hệt cũ (dãy tab ngang phía trên, thanh địa chỉ, "+ Tab" mở tab
 *  mới, "✕" đóng tab), NHƯNG BẢN CHẤT ĐÃ ĐỔI: trước đây là "1 web nhiều tab" (nhiều WebView
 *  dùng chung 1 tiến trình -> chung cookie), giờ MỖI TAB LÀ 1 "WEB" HOÀN TOÀN ĐỘC LẬP - chạy ở
 *  TIẾN TRÌNH RIÊNG (activity-alias MultiTabSlot0..7 trong Manifest, mỗi alias 1 process khác
 *  nhau), nên KHÔNG đồng bộ cookie/tài khoản đăng nhập giữa các tab - đúng như 8 app riêng biệt.
 *  Tối đa 8 tab (8 slot cố định). KHÔNG có tính năng đánh dấu sao. */
class MultiTabActivity : AppCompatActivity() {

    private var mySlot = 0
    private lateinit var webView: WebView
    private var programmaticLoad = false

    private lateinit var tabBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar

    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.getIntExtra("slot", -1) == mySlot) {
                MultiTabSlotsStore.clear(this@MultiTabActivity, mySlot)
                notifySlotsChanged()
                finish()
            }
        }
    }
    private val slotsChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { renderTabBar() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        insetsController.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        mySlot = intent.getIntExtra("slot", -1)
        if (mySlot !in 0 until MultiTabSlotsStore.MAX_SLOTS) {
            // Không rõ slot nào -> tìm slot trống, hết chỗ thì báo và đóng lại
            val free = MultiTabSlotsStore.findFreeSlot(this)
            if (free == null) {
                Toast.makeText(this, "Đã đạt tối đa 8 tab", Toast.LENGTH_SHORT).show()
                finish(); return
            }
            mySlot = free
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        tabScroll.addView(tabBar)
        root.addView(tabScroll)

        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        edtUrl = EditText(this).apply {
            hint = "Nhập địa chỉ web..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    loadFromInput(); true
                } else false
            }
        }
        urlRow.addView(edtUrl)
        root.addView(urlRow)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFC724FF.toInt())
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progressBar)

        webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webContainer)

        setContentView(root)

        setupWebView()
        val startUrl = intent.getStringExtra("initial_url")
            ?: MultiTabSlotsStore.loadAll(this)[mySlot].let { if (it.used && it.url.isNotBlank()) it.url else "https://www.google.com" }
        webView.loadUrl(startUrl)
        renderTabBar()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.userAgentString = UserAgentManager.MOBILE_UA
            settings.saveFormData = true
        }
        webContainer.addView(webView)
        setupLongPress(webView)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView?, title: String?) {
                MultiTabSlotsStore.update(this@MultiTabActivity, mySlot, view?.url ?: "", title?.take(14) ?: "Tab mới")
                notifySlotsChanged()
                renderTabBar()
            }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val host = request?.url?.host
                return if (AdBlocker.isAd(host)) AdBlocker.blockedResponse() else super.shouldInterceptRequest(view, request)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme != "http" && scheme != "https"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                edtUrl.setText(url)
                MultiTabSlotsStore.update(this@MultiTabActivity, mySlot, url ?: "", view?.title?.take(14) ?: "Tab mới")
                notifySlotsChanged()
                view?.evaluateJavascript(ZoomEnabler.JS, null)
                view?.evaluateJavascript(AdOverlayBlocker.JS, null)
                view?.evaluateJavascript(TranslateInjector.JS, null)
                if (YoutubeAdSkipper.isYoutube(url)) view?.evaluateJavascript(YoutubeAdSkipper.JS, null)
            }
        }
    }

    /** Nhấn giữ vào 1 link/ảnh trong trang -> hiện tuỳ chọn "Mở trong tab mới" */
    private fun setupLongPress(webView: WebView) {
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val targetUrl = when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                WebView.HitTestResult.IMAGE_TYPE -> result.extra
                else -> null
            }
            if (targetUrl != null) {
                AlertDialog.Builder(this)
                    .setTitle(targetUrl.take(60))
                    .setItems(arrayOf("Mở trong tab mới", "Huỷ")) { _, which ->
                        if (which == 0) openNewTab(targetUrl)
                    }
                    .show()
                true
            } else false
        }
    }

    private fun openNewTab(url: String) {
        val free = MultiTabSlotsStore.findFreeSlot(this)
        if (free == null) {
            Toast.makeText(this, "Đã đạt tối đa 8 tab", Toast.LENGTH_SHORT).show()
            return
        }
        launchSlot(free, url)
    }

    private fun launchSlot(slot: Int, url: String? = null) {
        val intent = Intent().apply {
            component = MultiTabSlotsStore.aliasComponent(this@MultiTabActivity, slot)
            putExtra("slot", slot)
            if (url != null) putExtra("initial_url", url)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        startActivity(intent)
    }

    private fun renderTabBar() {
        tabBar.removeAllViews()
        val slots = MultiTabSlotsStore.loadAll(this)
        for (slot in slots) {
            if (!slot.used) continue
            val isCurrent = slot.index == mySlot
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(if (isCurrent) 0xFF2A0033.toInt() else 0xFF141414.toInt())
                setPadding(dp(12), dp(8), dp(8), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.marginEnd = dp(6)
                layoutParams = lp
                isClickable = true
                setOnClickListener { if (!isCurrent) launchSlot(slot.index) }
            }
            cell.addView(TextView(this).apply {
                text = slot.title
                textSize = 12f
                setTextColor(if (isCurrent) 0xFFC724FF.toInt() else 0xFFAAAAAA.toInt())
            })
            cell.addView(TextView(this).apply {
                text = " ✕"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                isClickable = true
                setOnClickListener { closeSlot(slot.index) }
            })
            tabBar.addView(cell)
        }
        tabBar.addView(TextView(this).apply {
            text = "+ Tab"
            textSize = 13f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            isClickable = true
            setOnClickListener { openNewTab("https://www.google.com") }
        })
    }

    private fun closeSlot(slot: Int) {
        if (slot == mySlot) {
            MultiTabSlotsStore.clear(this, mySlot)
            notifySlotsChanged()
            finish()
        } else {
            // Tab đó đang chạy ở tiến trình khác -> gửi tín hiệu để tự đóng bên đó
            val i = Intent("com.h.adblockbrowser.MULTITAB_CLOSE_SLOT").apply {
                setPackage(packageName)
                putExtra("slot", slot)
            }
            sendBroadcast(i)
            // Phòng trường hợp tiến trình đó không còn sống để nhận broadcast -> tự xoá slot
            MultiTabSlotsStore.clear(this, slot)
            notifySlotsChanged()
            renderTabBar()
        }
    }

    private fun notifySlotsChanged() {
        val i = Intent("com.h.adblockbrowser.MULTITAB_SLOTS_CHANGED").apply { setPackage(packageName) }
        sendBroadcast(i)
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = if (input.contains(".") && !input.contains(" ")) "https://$input"
            else "https://www.google.com/search?q=" + Uri.encode(input)
        }
        programmaticLoad = true
        webView.loadUrl(input)
    }

    override fun onResume() {
        super.onResume()
        androidx.core.content.ContextCompat.registerReceiver(
            this, closeReceiver, IntentFilter("com.h.adblockbrowser.MULTITAB_CLOSE_SLOT"),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        androidx.core.content.ContextCompat.registerReceiver(
            this, slotsChangedReceiver, IntentFilter("com.h.adblockbrowser.MULTITAB_SLOTS_CHANGED"),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        renderTabBar()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(closeReceiver) } catch (e: Exception) {}
        try { unregisterReceiver(slotsChangedReceiver) } catch (e: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            programmaticLoad = true
            webView.goBack()
        } else {
            MultiTabSlotsStore.clear(this, mySlot)
            notifySlotsChanged()
            finish()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
