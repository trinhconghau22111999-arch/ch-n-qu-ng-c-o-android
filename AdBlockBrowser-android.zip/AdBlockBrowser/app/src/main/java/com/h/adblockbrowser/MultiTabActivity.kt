package com.h.adblockbrowser

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** "Đa tab" - duyệt web nhiều tab cùng lúc kiểu máy tính (dãy tab ngang phía trên, bấm "+" mở
 *  tab mới, bấm "×" trên từng tab để đóng, KHÔNG giới hạn số tab), NHƯNG KHÔNG PHẢI chế độ
 *  riêng tư: chạy chung tiến trình với trình duyệt chính nên DÙNG CHUNG cookie/phiên đăng nhập,
 *  KHÔNG tự xoá lịch sử hay dữ liệu khi đóng. Các tab (URL đang mở) được LƯU LẠI, thoát app vào
 *  lại vẫn còn nguyên (không phục hồi lại đúng vị trí cuộn/lịch sử điều hướng chi tiết, chỉ tải
 *  lại đúng URL từng tab - đơn giản, đủ dùng cho "tab cũ vẫn còn"). */
class MultiTabActivity : AppCompatActivity() {

    private data class Tab(val webView: WebView, var title: String = "Tab mới")

    private val tabs = ArrayList<Tab>()
    private var activeIndex = 0
    private var programmaticLoad = false

    private lateinit var tabBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var edtUrl: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnStar: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        insetsController.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        tabScroll.addView(tabBar)
        root.addView(tabScroll)

        val urlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(6))
        }
        edtUrl = EditText(this).apply {
            hint = "Nhập địa chỉ web..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A1A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                    loadFromInput(); true
                } else false
            }
        }
        urlRow.addView(edtUrl)

        btnStar = TextView(this).apply {
            text = "☆"
            textSize = 20f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(dp(10), dp(6), dp(4), dp(6))
            isClickable = true
            setOnClickListener { toggleStarCurrent() }
        }
        urlRow.addView(btnStar)

        urlRow.addView(TextView(this).apply {
            text = "★ Mở hết"
            textSize = 12f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(8), dp(6), dp(4), dp(6))
            isClickable = true
            setOnClickListener { openAllStarred() }
        })
        root.addView(urlRow)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFC724FF.toInt())
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progressBar)

        webContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webContainer)

        setContentView(root)

        val savedUrls = MultiTabSessionStore.load(this)
        val startUrl = intent.getStringExtra("initial_url")
        if (startUrl != null) {
            newTab(startUrl)
        } else if (savedUrls.isNotEmpty()) {
            savedUrls.forEach { newTab(it) }
        } else {
            newTab("https://www.google.com")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.userAgentString = UserAgentManager.MOBILE_UA
            settings.saveFormData = true
            visibility = View.GONE
        }
        val tab = Tab(webView)
        val index = tabs.size
        tabs.add(tab)
        webContainer.addView(webView)
        setupWebViewCallbacks(webView, index)
        setupLongPress(webView)
        switchTab(index)
        loadInTab(index, url)
        renderTabBar()
    }

    /** Nhấn giữ vào 1 link/ảnh trong trang -> hiện tuỳ chọn "Mở trong tab mới" */
    private fun setupLongPress(webView: WebView) {
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val targetUrl = when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                WebView.HitTestResult.IMAGE_TYPE -> result.extra
                else -> null
            }
            if (targetUrl != null) {
                AlertDialog.Builder(this)
                    .setTitle(targetUrl.take(60))
                    .setItems(arrayOf("Mở trong tab mới", "Huỷ")) { _, which ->
                        if (which == 0) newTab(targetUrl)
                    }
                    .show()
                true
            } else false
        }
    }

    private fun setupWebViewCallbacks(webView: WebView, index: Int) {
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tabs.getOrNull(activeIndex)?.webView === webView) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (index < tabs.size) {
                    tabs[index].title = title?.take(14) ?: "Tab mới"
                    renderTabBar()
                }
            }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val host = request?.url?.host
                return if (AdBlocker.isAd(host)) AdBlocker.blockedResponse() else super.shouldInterceptRequest(view, request)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme != "http" && scheme != "https"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (tabs.getOrNull(activeIndex)?.webView === webView) {
                    edtUrl.setText(url)
                    refreshStarIcon()
                }
                view?.evaluateJavascript(ZoomEnabler.JS, null)
                view?.evaluateJavascript(AdOverlayBlocker.JS, null)
                view?.evaluateJavascript(TranslateInjector.JS, null)
                if (YoutubeAdSkipper.isYoutube(url)) view?.evaluateJavascript(YoutubeAdSkipper.JS, null)
                saveSession()
            }
        }
    }

    private fun loadInTab(index: Int, url: String) {
        tabs.getOrNull(index)?.webView?.loadUrl(url)
    }

    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        activeIndex = index
        for ((i, t) in tabs.withIndex()) {
            t.webView.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        edtUrl.setText(tabs[index].webView.url ?: "")
        refreshStarIcon()
        renderTabBar()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        webContainer.removeView(tab.webView)
        tab.webView.destroy()
        if (tabs.isEmpty()) {
            saveSession()
            finish()
            return
        }
        val newActive = index.coerceAtMost(tabs.size - 1)
        switchTab(newActive)
        renderTabBar()
        saveSession()
    }

    private fun renderTabBar() {
        tabBar.removeAllViews()
        for ((i, tab) in tabs.withIndex()) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(if (i == activeIndex) 0xFF2A0033.toInt() else 0xFF141414.toInt())
                setPadding(dp(12), dp(8), dp(8), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.marginEnd = dp(6)
                layoutParams = lp
                isClickable = true
                setOnClickListener { switchTab(i) }
            }
            cell.addView(TextView(this).apply {
                text = tab.title
                textSize = 12f
                setTextColor(if (i == activeIndex) 0xFFC724FF.toInt() else 0xFFAAAAAA.toInt())
            })
            cell.addView(TextView(this).apply {
                text = " ✕"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                isClickable = true
                setOnClickListener { closeTab(i) }
            })
            tabBar.addView(cell)
        }
        // KHÔNG còn giới hạn số tab - nút "+ Tab" luôn hiện
        tabBar.addView(TextView(this).apply {
            text = "+ Tab"
            textSize = 13f
            setTextColor(0xFFC724FF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            isClickable = true
            setOnClickListener { newTab("https://www.google.com") }
        })
    }

    private fun refreshStarIcon() {
        val url = tabs.getOrNull(activeIndex)?.webView?.url ?: ""
        val starred = url.isNotBlank() && StarredPagesStore.isStarred(this, url)
        btnStar.text = if (starred) "★" else "☆"
        btnStar.setTextColor(if (starred) 0xFFFFD700.toInt() else 0xFFCCCCCC.toInt())
    }

    private fun toggleStarCurrent() {
        val url = tabs.getOrNull(activeIndex)?.webView?.url ?: return
        if (url.isBlank()) return
        val nowStarred = StarredPagesStore.toggle(this, url)
        refreshStarIcon()
        Toast.makeText(this, if (nowStarred) "Đã gắn dấu sao" else "Đã bỏ dấu sao", Toast.LENGTH_SHORT).show()
    }

    private fun openAllStarred() {
        val list = StarredPagesStore.getAll(this)
        if (list.isEmpty()) {
            Toast.makeText(this, "Chưa có trang nào gắn dấu sao", Toast.LENGTH_SHORT).show()
            return
        }
        list.forEach { newTab(it) }
    }

    private fun saveSession() {
        MultiTabSessionStore.save(this, tabs.mapNotNull { it.webView.url })
    }

    private fun loadFromInput() {
        var input = edtUrl.text.toString().trim()
        if (input.isEmpty()) return
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = if (input.contains(".") && !input.contains(" ")) "https://$input"
            else "https://www.google.com/search?q=" + Uri.encode(input)
        }
        programmaticLoad = true
        loadInTab(activeIndex, input)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onBackPressed() {
        val current = tabs.getOrNull(activeIndex)?.webView
        if (current != null && current.canGoBack()) {
            programmaticLoad = true
            current.goBack()
        } else {
            saveSession()
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        saveSession()
    }

    override fun onDestroy() {
        saveSession()
        for (t in tabs) t.webView.destroy()
        super.onDestroy()
    }
}
